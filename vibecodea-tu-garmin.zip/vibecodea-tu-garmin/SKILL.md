---
name: vibecodea-tu-garmin
description: Diseña, programa e instala esferas, widgets y apps propias en un reloj Garmin con el kit oficial Connect IQ (lenguaje Monkey C), sin tocar el firmware. Úsala siempre que alguien quiera personalizar, «vibecodear» o «tunear» su Garmin, hacerse una esfera a medida, añadirle deportes o métricas que su modelo no trae (pádel, HIIT, Tabata, comba, boxeo, escalada, energía tipo Body Battery, nota de sueño, recuperación, agua, pendientes) o pregunte qué más se le puede meter a su reloj, aunque no mencione Connect IQ. Also use it for any request to build a custom Garmin watch face, widget, data field or app, to work with Connect IQ or Monkey C, or to sideload a .prg onto a Garmin watch.
---

# Vibecodea tu Garmin

Con esta skill ayudas a alguien a sacarle el máximo partido a su Garmin: aprovechar lo que su modelo ya sabe hacer y darle lo que no trae, como una esfera a su gusto, deportes nuevos, widgets y métricas. Todo se hace con las herramientas oficiales de Garmin (Connect IQ) y se instala por cable, igual que lo haría cualquier desarrollador. El firmware no se toca.

Habla con la persona en su idioma y sin jerga. Casi nadie ha programado antes, y lo que más se agradece es entender qué se lleva en la muñeca: cada número que pongas en el reloj tiene que poder explicarse en una frase.

## Reglas que protegen a la persona

- **Nada de firmware modificado.** Un firmware tocado puede dejar el reloj inservible y no hay forma segura de hacerlo. Si te lo piden, explica por qué no y ofrece lo que sí se puede hacer.
- **Sus cuentas las maneja ella.** Los inicios de sesión (Garmin, SDK Manager, GitHub) los hace la persona. Tú no escribes contraseñas ni pegas claves en sus apps.
- **La clave de desarrollador es privada.** El archivo `developer_key.der` firma sus apps. Se queda en su ordenador, con copia de seguridad, y nunca se sube a un repositorio ni se pega en el chat.
- **Las métricas de salud son estimaciones.** La energía, el sueño o la recuperación que calcules sirven para ver tendencias; no son un diagnóstico. Dilo una vez, sin dramatizar.
- **Diseños propios.** No copies esferas de pago, logotipos de marcas ni personajes con derechos.
- **La nube es opcional.** Si algún dato sale del reloj, es porque la persona lo ha pedido y sabe adónde va.

## Paso 0. Mira dónde estás trabajando

Lo que puedes hacer depende de si tienes un terminal en el ordenador de la persona:

- **Modo completo:** puedes ejecutar comandos en su ordenador (Claude Code, o la app de escritorio de Claude con acceso a sus carpetas y a un terminal). Tú compilas, revisas e instalas.
- **Modo guiado:** solo tienes el chat, o un entorno en la nube sin acceso a su ordenador ni al reloj. Tú escribes el proyecto y se lo entregas en un .zip. La persona compila con VS Code y la extensión Monkey C, y copia el archivo al reloj siguiendo tus pasos.

Compruébalo de verdad (por ejemplo, con `java -version` en su máquina) en lugar de suponerlo. Si estás en modo guiado, díselo al principio y recomiéndale Claude Code o la app de escritorio con acceso al ordenador, porque así todo es mucho más fácil.

## Paso 1. Entrevista corta

Lee `references/entrevista.md`. En una o dos rondas de preguntas con opciones, averigua:

1. El modelo exacto del reloj, incluido el tamaño. También si tiene música, porque eso cambia cómo se instala.
2. Su ordenador: Mac, Windows o Linux.
3. A qué se dedica: deportes, rutinas, montaña, gimnasio…
4. Qué quiere ver y tener. Ofrécele una lista y explica cada dato en una línea: no des por hecho que sabe qué son los «minutos de intensidad».
5. Estilo: digital o analógica, colores y tamaño de letra.
6. Si quiere guardar sus datos fuera del reloj. Es opcional y avanzado.

Lo personal (su hora de dormir, su signo, sus colores) son parámetros que eliges con la persona, nunca valores por defecto copiados de otra.

## Paso 2. Investiga su reloj y haz su mapa de posibilidades

Este paso es el corazón de la skill: cada modelo da para cosas distintas, y un reloj con más sensores y un Connect IQ más moderno da para mucho más. Lee `references/investigar-el-reloj.md` (la ficha técnica y cómo se conecta) y `references/sacarle-partido.md` (qué permite cada versión de Connect IQ y qué ideas abre cada sensor). Después, investiga de verdad:

1. **Su ficha:** pantalla (resolución, forma, MIP o AMOLED, táctil), versión de Connect IQ, memoria, botones y sensores. Con el SDK instalado, `python3 scripts/info_reloj.py <id>` lo resume y dice qué funciones permite su versión. Si aún no lo está, sácalo del manual y de la página de dispositivos compatibles de Connect IQ, y confírmalo con la ficha después del paso 4.
2. **Lo que trae de serie:** busca el manual oficial de su modelo y apunta lo que ya hace de lo que ha pedido, y lo que hace y quizá no conoce. Muchos relojes ya estiman el VO2 máx., avisan de tormenta, guardan un sitio para volver o cuentan repeticiones, y los modernos tienen Body Battery o puntuación de sueño. Díselo: así nadie le dirá después que «eso ya se podía».
3. **Lo que Connect IQ le deja leer:** con su versión, mira qué datos de Garmin puede usar una esfera o una app. En un reloj moderno no se recalcula el Body Battery: se lee y se pone donde la persona lo quiera ver.

Con eso, enséñale su **mapa de posibilidades** (formato en `references/sacarle-partido.md`): unas pocas ideas para su reloj y su vida, cada una con si ya la trae, qué haríamos y lo difícil que es. Explica cada dato en una línea.

## Paso 3. Propón un plan y deja que elija

Del mapa, recomienda empezar con entre una y tres piezas (por ejemplo, una esfera y una app) y ampliar después. Espera a que elija.

| Tipo | Qué es | Cuándo encaja |
|---|---|---|
| Esfera (watch face) | La pantalla principal | Ver de un vistazo lo que le importa |
| Widget o glance | Pantallas que se pasan con los botones desde la esfera | Consultas rápidas: agua, pendientes, montaña |
| App (watch app) | Se abre desde la lista de actividades | Deportes con marcador, temporizadores, navegación |
| Campo de datos | Un dato dentro de una actividad de Garmin | Añadir un número a la carrera o a la bici |

## Paso 4. Prepara el ordenador

Lee `references/preparar-el-ordenador.md`. Hacen falta Java, el SDK Manager de Garmin (la persona inicia sesión y descarga el SDK y su reloj) y una clave de desarrollador. En modo guiado, también VS Code con la extensión Monkey C. Comprueba cada pieza antes de seguir.

## Paso 5. Construye

1. Parte del ejemplo más parecido de `ejemplos/fenix5/` (tabla al final) y de las fórmulas de `references/recetas.md`. Están probados en un fēnix 5 (240×240 píxeles, MIP, Connect IQ 3.1): adapta tamaños, colores y memoria a su modelo. Si su reloj ya calcula algo que el ejemplo estima (Body Battery, sueño, recuperación, el tiempo), léelo de Garmin con los patrones de «Datos de Garmin en relojes modernos» en `references/monkey-c.md`.
2. Antes de escribir código, lee `references/monkey-c.md`. Recoge los errores que de verdad salen al compilar y cómo evitarlos.
3. Para esferas, lee `references/esferas.md`; para apps y widgets, `references/apps-y-widgets.md`.
4. En cada proyecto nuevo, pon un id de aplicación nuevo en `manifest.xml` (32 caracteres hexadecimales, por ejemplo con `uuidgen | tr -d - | tr A-F a-f`) y añade su reloj a la lista de productos.
5. Compila con `scripts/compilar.sh` (Mac y Linux) o `scripts/compilar.ps1` (Windows). Si falla, la tabla de errores de `references/monkey-c.md` cubre los habituales.

Construye una pieza cada vez: compílala, revísala y pasa a la siguiente.

## Paso 6. Revisa antes de instalar

- Si tiene el simulador del SDK, abre la app en él y deja que la persona la vea.
- En las esferas, comprueba el peor caso (las 23:59, números largos, sin datos del móvil): nada debe salirse del círculo ni pisarse. `references/esferas.md` explica cómo hacerlo con una imagen de prueba.
- Repasa el gasto de batería: apaga los sensores al salir y usa el GPS solo cuando haga falta.

## Paso 7. Instala

Lee `references/instalar.md`. En resumen:

- Si el reloj aparece como unidad USB, se copia el `.prg` a `GARMIN/APPS`.
- Si usa MTP, en Windows se ve en el Explorador de archivos. En Mac hace falta OpenMTP (gratis) y tener Garmin Express cerrado del todo.

Al desenchufar el reloj, carga la app. Si algo falla, el registro de errores está en `GARMIN/APPS/LOGS/CIQ_LOG.YML`.

## Paso 8. (Opcional) Datos fuera del reloj

Hazlo solo si la persona quiere historial, un panel propio o métricas que su reloj no calcula, como la energía o la nota de sueño. Lee `references/nube-opcional.md`, que explica la arquitectura, la privacidad y un ejemplo completo con Supabase. Avisa de que es la parte más técnica.

## Paso 9. Entrega una chuleta

Al terminar, deja a la persona una guía corta de lo que tiene: dónde está cada cosa (esfera, widget o app), qué hace cada botón y qué significa cada número. Con tantas cosas nuevas la gente se pierde, y esta guía es lo que hace que de verdad las use. Usa este formato:

| Quiero… | Dónde | Cómo |
|---|---|---|
| Apuntar el agua | Widget «Agua» | START suma una botella; mantén ARRIBA para los ajustes |

Añade una segunda tabla, «Dato · qué significa · cuándo es bueno», con los números de la esfera.

## Ejemplos incluidos (`ejemplos/fenix5/`)

Probados en un fēnix 5. Úsalos como referencia, no como plantilla cerrada. `ejemplos/fenix5/LEEME.md` explica qué hay que cambiar en cada uno antes de usarlo.

| Carpeta | Qué es | Qué enseña |
|---|---|---|
| `esfera/` | Esfera digital con una línea que va rotando | Fuentes propias, servicio en segundo plano, tiempo a través del móvil, luna, sol |
| `analogica/` | Esfera analógica | Agujas, subesferas, segundero al levantar la muñeca |
| `vfc/` | VFC de 2 minutos al despertar | Intervalos entre latidos, rMSSD, autocomprobación de los datos |
| `gym/` | Gimnasio por series | Grabar una actividad, descanso con vibración |
| `padel/` | Marcador de pádel | Reglas (punto de oro, star point, súper tie-break), deshacer, estadísticas |
| `intervalos/` | HIIT, Tabata, EMOM, boxeo y comba | Temporizador por fases, contador de saltos |
| `escalada/` | Vías y bloques con su grado | Campos FIT propios, menús |
| `montana/` | Widget de montaña | Historial de sensores, gráficas, aviso de tormenta, sol y luna |
| `agua/` | Widget de agua | Guardar datos, menú de ajustes |
| `hoy/` | Lista de pendientes | Pedir datos a internet a través del móvil, cola sin conexión |
| `volver/` | Volver al coche | GPS, brújula, distancia y rumbo |
| `nube/` | Servidor de ejemplo en Supabase | Tablas, tareas programadas y una función |
| `herramientas/` | Vista previa y generador de recursos | Comprobar que nada se pisa, fuentes e iconos |
