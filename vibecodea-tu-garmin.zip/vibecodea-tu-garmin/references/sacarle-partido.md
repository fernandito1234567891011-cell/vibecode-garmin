# Sacarle el máximo partido a su reloj

Cada Garmin puede hacer cosas distintas. Un fēnix 5 de 2017 no se parece a un Forerunner 265 ni a un fēnix 8: tienen otros sensores, otra pantalla y otra versión de Connect IQ. Tu trabajo es averiguar qué tiene el reloj de esta persona y proponerle lo que más le aporte. Eso excluye lo que ya trae y lo que su reloj no puede hacer.

## 1. Tres fuentes, siempre contrastadas

1. **La ficha del SDK:** `python3 scripts/info_reloj.py <id>`. Da la pantalla, la memoria, los botones, la versión de Connect IQ, los historiales de sensores que tiene y qué funciones permite esa versión.
2. **El manual oficial del modelo**, que dice qué trae de serie. Búscalo en internet con algo como «manual <modelo> garmin webhelp». Repasa sobre todo:
   - salud: Body Battery, estrés, puntuación de sueño, HRV Status, pulsioximetría, hidratación;
   - entrenamiento: estado de entrenamiento, tiempo de recuperación, VO2 máx., predicción de carrera;
   - hardware: mapas, linterna, música, carga solar;
   - deportes: la lista de perfiles de actividad.
3. **La documentación de Connect IQ** (developer.garmin.com/connect-iq/api-docs/). Cada función indica desde qué versión existe (*Since: API Level*), y muchas páginas listan los relojes compatibles.

No prometas nada que no hayas visto en al menos una de las tres. Si no tienes cómo buscar en internet, pide a la persona el enlace al manual o que te diga qué ve en su reloj.

## 2. Qué puede leer una app según la versión de Connect IQ

La versión de Connect IQ del reloj marca qué funciones existen. Que exista una función no garantiza que ese reloj tenga el dato: en el código, compruébalo con `has` (por ejemplo, `Toybox has :Complications`) y trata siempre el caso `null`.

| Desde la versión | Qué se puede leer o hacer | Para qué sirve |
|---|---|---|
| 2.1.0 | Historial de pulso, altitud, presión y temperatura (`SensorHistory`). Minutos de intensidad del día y de la semana, y pisos subidos (`ActivityMonitor.Info`) | Gráficas de las últimas horas, tendencia de la presión, intensidad semanal |
| 3.0.0 | Un mapa con marcadores y líneas dentro de una app (`WatchUi.MapView`), solo en relojes con mapas | Ver el coche o un recorrido sobre el mapa |
| 3.2.0 | El tiempo que da Garmin (`Toybox.Weather`), el historial de pulsioximetría y el pulso en reposo medio de 7 días (`UserProfile`) | El tiempo sin servicios externos; saturación en altura |
| 3.3.0 | Historial de Body Battery y de estrés; respiración y horas de recuperación (`ActivityMonitor.Info`); VO2 máx. de carrera y de bici (`UserProfile`) | Poner en la esfera sus números de Garmin en lugar de estimarlos |
| 4.2.0 | Complicaciones (`Toybox.Complications`): la esfera lee datos de Garmin como Body Battery, estrés, tiempo de recuperación, estado de entrenamiento, VO2 máx., predicción de carrera, pulsioximetría, respiración, carga solar, puntuación de sueño, el tiempo o los eventos del calendario | Juntar en una pantalla lo que Garmin reparte en varios widgets |
| 5.0.0 | Nivel de estrés del momento (`ActivityMonitor.Info.stressScore`) | Estrés en tiempo real |

Algunos tipos de complicación se añadieron después que otros, y no todos los relojes los ofrecen. HRV Status no aparece entre las complicaciones. La VFC se puede medir con una app propia que lea los intervalos entre latidos, como `ejemplos/fenix5/vfc/`.

## 3. De su hardware a las ideas

| Si su reloj tiene… | Se puede añadir… | Ejemplo |
|---|---|---|
| Barómetro | Aviso de tormenta en la esfera, tendencia de la presión, altitud y desnivel de las últimas horas | `montana/` |
| GPS y brújula | Flecha para volver a un sitio guardado, con la distancia | `volver/` |
| Mapas | El sitio guardado o el recorrido sobre el mapa | `MapView` (3.0.0) |
| Pulso en la muñeca | Esfuerzo del día, pulso de la noche frente a su normal, descansos que vibran | `recetas.md`, `gym/` |
| Lectura de intervalos entre latidos | Una medición de VFC al despertar | `vfc/` |
| Pulsioxímetro | Saturación junto a la altitud, para la montaña | Historial de pulsioximetría (3.2.0) |
| Panel solar | Cuánta carga solar recibe ahora | Complicación de carga solar |
| Pantalla táctil | Menús y botones que se tocan, además de los físicos | `apps-y-widgets.md` |
| AMOLED | Más color y detalle; protección de pantalla en el modo siempre encendido | `esferas.md` |
| Acelerómetro | Contar saltos de comba o repeticiones | `intervalos/`, `gym/` |

## 4. Reloj antiguo o reloj moderno

- **Antiguo (Connect IQ 3.1 o menos, como el fēnix 5).** No tiene Body Battery, ni puntuación de sueño, ni el tiempo de Garmin al alcance de una app. Aquí aporta mucho calcular estimaciones propias (`recetas.md`, y la nube si quiere historial) y traer el tiempo por el móvil.
- **Moderno (Connect IQ 4.2 o más).** Ya calcula casi todo. No lo rehagas: lee sus números con complicaciones y júntalos en una esfera a su gusto. Donde más aporta algo propio es en lo que Garmin no hace: deportes sin perfil, rutinas a medida, widgets de su día a día y un diseño personal.

| | fēnix 5 (Connect IQ 3.1) | Forerunner 265 (Connect IQ 5.2) |
|---|---|---|
| Energía del día | Estimación propia, con la nube | Su Body Battery, leído desde la esfera |
| El tiempo | Por el móvil, desde un servicio gratuito (Open-Meteo) | `Toybox.Weather`, sin nada más |
| VO2 máx. en la esfera | Connect IQ no lo da en esa versión | Sí: `UserProfile` (3.3.0) o complicación |
| Pantalla | MIP de 64 colores, solo botones | AMOLED táctil: más color, con protección de pantalla |

## 5. Lo que Connect IQ no permite

- Tocar el firmware o cambiar las funciones y actividades de Garmin.
- Leer la señal cruda de los sensores.
- Trabajar en segundo plano sin parar: como mucho, una tarea cada 5 minutos.
- Configurar desde el móvil una app instalada por cable.

Si la persona pide algo de esto, díselo claro y ofrece lo más parecido que sí se puede hacer.

## 6. El mapa de posibilidades

Con lo anterior, enséñale una tabla corta antes de proponer el plan. Ordénala por lo que más le aporta según lo que te contó en la entrevista:

| Idea | ¿La trae ya? | Qué haríamos | Dificultad |
|---|---|---|---|
| Ver de un vistazo Body Battery, sueño y recuperación | Sí, pero en tres widgets | Una esfera que los junte, con colores | Baja |
| Marcador de pádel | No | App propia con sus reglas | Media |
| Saber si hoy toca entrenar fuerte | En parte (estado de entrenamiento) | Una frase en la esfera con su recuperación | Baja |

Cada fila se apoya en lo que has visto en la ficha, el manual o la documentación. Si una idea depende de algo que no has podido confirmar, dilo en la misma fila.
