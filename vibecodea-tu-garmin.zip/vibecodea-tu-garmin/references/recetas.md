# Recetas: fórmulas y reglas que ya funcionan

Son las de los ejemplos, explicadas para poder adaptarlas. Las métricas de salud son estimaciones propias, no las de Garmin ni las de Whoop: sirven para ver tendencias, no son un diagnóstico.

## Contenido

1. Pulso de la noche frente a lo normal
2. VFC de la mañana (rMSSD)
3. Energía tipo Body Battery
4. Nota de sueño y deuda de sueño
5. Esfuerzo (0-21)
6. Recuperación y consejo del día
7. Aviso de tormenta
8. Luna, signo y sol
9. Distancia y rumbo para volver a un punto
10. Pádel: reglas del marcador
11. Intervalos: modos
12. Escalada y gimnasio: descansos

## 1. Pulso de la noche frente a lo normal (en el reloj)

- Con `SensorHistory` o el historial de pulso de `ActivityMonitor`, calcula la **media de 30 minutos más baja** entre las 22:00 y las 11:00. Es la misma idea que usa Garmin para el pulso en reposo.
- Guarda un valor por noche (las últimas 14) y compara con la **mediana** de las noches anteriores.
- Diferencia de +1 o menos: «fresco». De +2 a +4: «cargado». +5 o más: «muy cargado».
- Mientras no haya 3 noches guardadas, enseña «BASE n/3» en lugar de opinar.

## 2. VFC de la mañana (rMSSD)

- Al despertar, tumbado y quieto, 2 minutos registrando los intervalos entre latidos (`heartBeatIntervals`).
- Descarta los intervalos fuera de 300-2000 ms y los saltos de más del 25 % respecto al último latido bueno. Con menos de 30 latidos limpios, no hay medida.
- rMSSD = raíz cuadrada de la media de los cuadrados de las diferencias entre intervalos seguidos. Puntuación legible: `ln(rMSSD) × 20`.
- Compara con la media de las últimas 7 mañanas: normal, baja («hoy suave») o alta.
- **Comprobación de calidad:** cuenta qué parte de los intervalos seguidos se diferencian en 3 ms o menos. Con latidos reales en reposo esa parte es baja; si pasa del 50 %, el reloj está dando intervalos calculados a partir del pulso, y esa medida no se usa.

## 3. Energía tipo Body Battery (en el servidor, con datos de Garmin)

Escala de 5 a 100:

- Base: `30 + 70 × min(1, horas de sueño / 8)`. Sin sueño registrado, 50.
- -8 si el sueño profundo es menos del 12 % del total.
- Si el pulso en reposo supera la media de 7 días: `-3 × diferencia` (máximo -20).
- Estrés del día, en minutos: alto ×0,25, medio ×0,12, bajo ×0,04 y de actividad ×0,10, restados; descanso ×0,02, sumado.

## 4. Nota de sueño y deuda de sueño

Nota de 0 a 100:

- Duración, 60 puntos: `60 × (horas − 4) / 4`, entre 0 y 60.
- Profundo y REM, 15 cada uno: proporción frente a un 18 % de profundo y un 20 % de REM. Si no hay REM, 30 puntos para el profundo.
- Poco tiempo despierto, 10 puntos: `10 × (1 − minutos despierto / 60)`.

Deuda: lo que falta en las 3 últimas noches para llegar a 8 horas por noche.

## 5. Esfuerzo (0-21)

Con el pulso de todo el día:

- Reserva de pulso: `(pulso − reposo) / (máximo − reposo)`. Solo cuenta por encima de 0,3.
- TRIMP: suma de `minutos × reserva × 0,64 × e^(1,92 × reserva)`.
- Esfuerzo: `21 × (1 − e^(−TRIMP / 120))`.

Lectura: menos de 8, día tranquilo; de 8 a 13, movido; de 14 a 17, duro; 18 o más, muy duro. Usa el pulso máximo de la persona si lo conoce; si no, 190 o una estimación por edad.

## 6. Recuperación y consejo del día

Recuperación de 1 a 99 (sin sueño registrado, no se calcula):

- Base 55.
- `+5 × (media de pulso en reposo de 7 días − pulso en reposo de hoy)`, entre -30 y +25.
- `+0,6 × (nota de sueño − 70)`.
- `−2 × (esfuerzo de ayer − 12)`, si el de ayer pasó de 12.

Consejo: 67 o más, «DALE CAÑA»; de 34 a 66, «SIN PASARTE»; menos, «SUAVE». Si la deuda de sueño llega a 3 horas, «ACUÉSTATE ANTES».

## 7. Aviso de tormenta

Con el historial de presión: si baja 4 hPa o más en 3 horas, aviso. En montaña, descuenta lo que cambia la presión por subir o bajar (o usa la presión al nivel del mar si el modelo la da).

## 8. Luna, signo y sol

- Fase de la luna: días desde una luna nueva de referencia, módulo 29,53.
- Signo por el que pasa la luna: longitud eclíptica aproximada de la luna dividida en 12 tramos de 30°.
- Salida y puesta del sol: el algoritmo de NOAA con la última posición conocida.
- El código está en `ejemplos/fenix5/esfera/source/F5Astro.mc` y en `ejemplos/fenix5/montana/source/CumbreAstro.mc`.

## 9. Distancia y rumbo para volver a un punto

- Distancia (haversine): `d = 2R · asin(√(sin²(Δlat/2) + cos lat1 · cos lat2 · sin²(Δlon/2)))`, con R = 6 371 000 m.
- Rumbo: `atan2(sin Δlon · cos lat2, cos lat1 · sin lat2 − sin lat1 · cos lat2 · cos Δlon)`.
- La flecha apunta a `rumbo − orientación de la brújula`. Parado, usa la brújula; en marcha, el rumbo del GPS.
- Vibra al quedar a menos de 15 m.

## 10. Pádel: reglas del marcador

- Puntos 0, 15, 30, 40. En 40 iguales, según el modo:
  - **Ventaja:** hay que ganar dos puntos seguidos.
  - **Punto de oro:** el siguiente punto gana el juego.
  - **Star point:** ventaja en los dos primeros iguales y punto decisivo en el tercero.
- Sets a 6 juegos con dos de diferencia; en 6-6, tie-break a 7. Mejor de 3 sets.
- Tercer set: normal o súper tie-break a 10.
- Cambio de lado en los juegos impares; en el tie-break, cada 6 puntos.
- Estadísticas útiles: puntos ganados con el saque propio y al resto, puntos de oro ganados y mejor racha.
- El motor está en Python con pruebas en `ejemplos/fenix5/herramientas/` y en Monkey C en `ejemplos/fenix5/padel/source/PadelScore.mc`.

## 11. Intervalos: modos

| Modo | Trabajo | Descanso | Rondas |
|---|---|---|---|
| Tabata | 20 s | 10 s | 8 |
| HIIT 40/20 | 40 s | 20 s | 10 |
| EMOM | 60 s (lo que sobra del minuto es descanso) | — | 10 |
| Boxeo | 3 min | 1 min | 12 |
| Comba | 60 s | 30 s | 10 |

Antes de empezar, 10 segundos de preparación. En comba, los saltos se cuentan con el acelerómetro.

## 12. Escalada y gimnasio: descansos

- Escalada: aviso a los 3 minutos de descanso entre vías y a los 2 entre bloques.
- Gimnasio: descanso por defecto de 90 segundos, ajustable, con vibración al terminar.
