# Apps y widgets

## Qué tipo de pieza elegir

- **Widget:** una pantalla que se consulta desde la esfera con ARRIBA y ABAJO (en relojes modernos se ve como un *glance* en una lista y se abre con START). Para consultas rápidas: agua, pendientes, montaña.
- **App (watch-app):** se abre desde la lista de actividades con START. Para lo que dura un rato y graba: un partido, una sesión de gimnasio, intervalos, navegación.
- **Campo de datos:** un número dentro de una actividad de Garmin (carrera, bici). Tiene muy poca memoria y no maneja botones.

## Patrones de los ejemplos

| Ejemplo | Idea que se puede reutilizar |
|---|---|
| `agua/` | Un contador diario en `Application.Storage` que se pone a cero solo al cambiar de día, más un `Menu2` para los ajustes (tamaño de botella y objetivo) |
| `hoy/` | Lista que se baja de internet al abrirla, se guarda para verla sin móvil y deja tachar cosas; lo tachado sin conexión espera en una cola |
| `volver/` | Guardar un punto con GPS y guiar con una flecha: distancia (haversine) y rumbo, con la brújula; vibra al llegar |
| `gym/` | Una serie por pulsación, descanso con cuenta atrás y vibración, corrección de repeticiones con las flechas, sesión grabada como fuerza |
| `padel/` | Motor de marcador separado de la vista, con deshacer (guarda una copia del estado antes de cada punto) y estadísticas; reglas elegibles antes de empezar |
| `intervalos/` | Máquina de fases (preparación, trabajo, descanso) con temporizador, pitidos y vibración; modos guardados con sus valores |
| `escalada/` | Registro por intentos (vía o bloque, grado, resultado) con campos FIT propios y avisos de descanso |
| `montana/` | Historial de presión, altitud y temperatura con `SensorHistory`, gráficas pequeñas y cálculo de sol y luna en el propio reloj |
| `vfc/` | Medida guiada de 2 minutos con intervalos entre latidos, cálculo de rMSSD y una comprobación de si los latidos son reales o calculados |

## Buenas costumbres

- **Separa la lógica de la vista.** Los marcadores y las cuentas en una clase sin dibujo; así se pueden probar en Python antes (como `ejemplos/fenix5/herramientas/padel_motor.py` con sus pruebas).
- **Todo se puede deshacer.** En un partido o una serie, un toque mal dado no debe arruinar el resultado.
- **Confirma lo que no tiene vuelta atrás.** Descartar una sesión, borrar el historial.
- **Pantallas con instrucciones.** En la parte de abajo, una línea pequeña: «START: EMPEZAR», «ATRÁS: MENÚ». Los botones no se recuerdan si no se usan a diario.
- **Vibración con significado.** Corta para un punto, doble para cambio de fase, larga para el final. Mucha gente no oye los pitidos con ruido o lleva el sonido apagado.
- **Guardar a prueba de cortes.** Guarda el estado en `Storage` a menudo: si la app se cierra, que se pueda seguir.

## Deportes que el reloj no tiene

Graba con el deporte más parecido (`SPORT_TENNIS` para pádel, `SPORT_TRAINING` con `SUB_SPORT_CARDIO_TRAINING` para HIIT) y pon el nombre real en `:name`. Explica a la persona que Garmin Connect puede enseñar el tipo genérico en modelos antiguos.
