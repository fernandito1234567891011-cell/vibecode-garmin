# Monkey C: lo que de verdad da problemas

Monkey C se parece a Java y a JavaScript, pero tiene manías. Este archivo recoge lo que ha fallado en proyectos reales y los patrones que funcionan. Los ejemplos de `ejemplos/fenix5/` los usan todos.

## Contenido

1. Estructura de un proyecto
2. Compilar
3. Errores habituales y su arreglo
4. Tipos y el comprobador de tipos
5. Patrones que funcionan (segundo plano, internet, sensores, GPS, vibración, grabar actividad, botones)
6. Memoria y batería

## 1. Estructura de un proyecto

```
mi-app/
├── manifest.xml        id, tipo (watchface, widget, watch-app, datafield), relojes, permisos
├── monkey.jungle       normalmente una línea: project.manifest = manifest.xml
├── resources/          strings, drawables (iconos), fonts, settings, fit (campos FIT)
└── source/             archivos .mc
```

En `manifest.xml`:

- `id`: 32 caracteres hexadecimales. **Uno nuevo por app**: dos apps con el mismo id se pisan en el reloj.
- `type`: `watchface`, `widget`, `watch-app` o `datafield`.
- `<iq:products>`: un `<iq:product id="…"/>` por cada reloj. Si falta el de la persona, no compila para él.
- `minApiLevel`: la versión mínima de Connect IQ que usas.
- Permisos según lo que uses: `Background`, `Communications`, `Positioning`, `Sensor`, `SensorHistory`, `FitContributor`, `UserProfile`.

## 2. Compilar

```
java -Xms1g -Dfile.encoding=UTF-8 -jar "$SDK/bin/monkeybrains.jar" \
  -o salida/mi-app.prg -f mi-app/monkey.jungle -y ~/.garmin/developer_key.der -d <id> -r -w
```

- `-d` es el id del reloj, `-y` la clave y `-r` compila en modo «release», más pequeño.
- `-w` enseña los avisos. Léelos: muchos anuncian un fallo en el reloj.
- Con un SDK reciente, `-O 2` optimiza y reduce memoria.
- `scripts/compilar.sh` y `scripts/compilar.ps1` buscan el SDK y la clave por ti.

## 3. Errores habituales y su arreglo

| Mensaje | Causa | Arreglo |
|---|---|---|
| `Cannot find symbol ':X'` al leer `MiClase.X` | Las `const` de una clase no se pueden leer así desde otra | Léela desde la instancia (`m.X`), o pásala a un `enum` o a una `const` de módulo |
| `Invalid Method` o «parameter N» en `makeWebRequest` | El comprobador de tipos no acepta `method(:callback)` con esa firma | Pon `(:typecheck(false))` en la función que hace la petición o declara la firma exacta |
| `Invalid '…Method(data as Any) as Any' passed as parameter 1 of type '…Method(data as …SensorData) as Void'` | Un callback sin tipos (sensores, `Timer.start`) | Declara la firma (`function onData(data as Sensor.SensorData) as Void`, `function onTick() as Void`) o pon `(:typecheck(false))` en la función que lo registra |
| `Cannot perform operation 'div' on types 'Null' and …` | Usas una variable que puede ser `null` en una cuenta | Compruébala antes en un `if` aparte, o `(:typecheck(false))` en esa función |
| Error de tipos en un callback de sensor o GPS | La firma no coincide | Usa exactamente las firmas de la sección 5 |
| Aviso: `ActivityRecording.SPORT_… is deprecated` | Los SDK nuevos prefieren `Activity.SPORT_…` | En relojes antiguos se puede ignorar; en los modernos usa `Activity.SPORT_…` |
| Aviso: `chartTitle … longer than the allowed length of '30'` | Un título de campo FIT demasiado largo | Acórtalo a 30 caracteres |
| `Unable to load private key` | Ruta mala o formato que no es DER | Ruta completa al `.der`; si hace falta, créala de nuevo con `scripts/nueva_clave.sh` |
| El reloj no está entre los dispositivos | Falta en el SDK Manager o en `manifest.xml` | Descárgalo y añade `<iq:product id="…"/>` |
| La app sale con un triángulo o no abre | Error en el reloj | Lee `GARMIN/APPS/LOGS/CIQ_LOG.YML`: dice el archivo y la línea |
| `Symbol Not Found` en el registro del reloj | Usas una API que ese modelo no tiene | Protégela con `has` (sección 5) |
| `Out Of Memory` en el registro | Demasiadas fuentes, imágenes o datos | Quita glifos de las fuentes, reduce imágenes, guarda menos historial |
| Letras con tilde o «ñ» que no salen | La fuente propia no incluye ese carácter | Regenera la fuente con esos caracteres |

## 4. Tipos y el comprobador de tipos

Los SDK modernos comprueban tipos al compilar. Dos formas de convivir con ello:

- Declarar tipos: `function onPosition(info as Position.Info) as Void`.
- Desactivarlo en una función concreta con `(:typecheck(false))`, justo encima de la función. Es lo práctico en funciones que leen diccionarios JSON o pasan callbacks a `makeWebRequest`.

Comprueba siempre `null`: casi todo lo que viene de sensores, del historial o de internet puede llegar vacío.

## 5. Patrones que funcionan

### Comprobar si el modelo tiene una API

```monkeyc
if (Toybox has :SensorHistory && SensorHistory has :getPressureHistory) { … }
if (Attention has :vibrate) { … }
if (Sensor has :registerSensorDataListener) { … }
```

### Datos de Garmin en relojes modernos

En un reloj que ya calcula Body Battery, sueño o recuperación, léelos en lugar de estimarlos. Estos patrones siguen la documentación oficial, pero los ejemplos del kit son de un fēnix 5 y no los usan: compílalos y pruébalos en el simulador antes de instalar.

Complicaciones (Connect IQ 4.2.0 o más). Registra primero el aviso de cambios y luego suscríbete a cada dato:

```monkeyc
var valores = {};   // tipo de complicación -> último valor

(:typecheck(false))
function suscribir() {
    if (!(Toybox has :Complications)) { return; }
    Complications.registerComplicationChangeCallback(method(:alCambiar));
    var tipos = [Complications.COMPLICATION_TYPE_BODY_BATTERY,
                 Complications.COMPLICATION_TYPE_SLEEP_SCORE,
                 Complications.COMPLICATION_TYPE_RECOVERY_TIME];
    for (var i = 0; i < tipos.size(); i++) {
        try {
            Complications.subscribeToUpdates(new Complications.Id(tipos[i]));
        } catch (e) {
            // Este reloj no ofrece ese dato: la esfera sigue sin él.
        }
    }
}

(:typecheck(false))
function alCambiar(id) {
    try {
        var c = Complications.getComplication(id);
        valores.put(c.getType(), c.value);   // value puede ser null
    } catch (e) { }
    WatchUi.requestUpdate();
}
```

El tiempo de Garmin (Connect IQ 3.2.0 o más), sin servicios externos. Las temperaturas vienen en grados Celsius:

```monkeyc
if (Toybox has :Weather) {
    var w = Weather.getCurrentConditions();   // puede ser null
    if (w != null && w.temperature != null) {
        // w.temperature, w.highTemperature, w.lowTemperature, w.precipitationChance, w.condition
    }
}
```

Historial de Body Battery o de estrés (Connect IQ 3.3.0 o más), igual que el de presión del ejemplo `esfera/`:

```monkeyc
if (Toybox has :SensorHistory && SensorHistory has :getBodyBatteryHistory) {
    var muestra = SensorHistory.getBodyBatteryHistory({:period => 1}).next();
    if (muestra != null && muestra.data != null) { … }
}
```

### Proceso en segundo plano (la esfera pide datos cada 30 minutos)

```monkeyc
(:background)
class MiApp extends Application.AppBase {
    function getInitialView() {
        Background.registerForTemporalEvent(new Time.Duration(30 * 60)); // mínimo 5 min
        return [new MiVista()];
    }
    function getServiceDelegate() { return [new MiServicio()]; }

    (:typecheck(false))
    function onBackgroundData(data) {
        Application.Storage.setValue("wx", data);   // guárdalo y repinta
        WatchUi.requestUpdate();
    }
}

(:background)
class MiServicio extends System.ServiceDelegate {
    function initialize() { ServiceDelegate.initialize(); }
    function onTemporalEvent() { /* pide datos y al acabar: Background.exit(resultado); */ }
}
```

- Todo lo que se usa en segundo plano lleva `(:background)`. Ese proceso tiene muy poca memoria (unos 32 KB en relojes antiguos).
- Pasa solo lo necesario con `Background.exit(...)`: listas y diccionarios pequeños.

### Pedir datos a internet (normalmente a través del móvil)

```monkeyc
(:typecheck(false))
function pedir() {
    Communications.makeWebRequest("https://api.open-meteo.com/v1/forecast",
        {"latitude" => "40.42", "longitude" => "-3.70", "current" => "temperature_2m"},
        {:method => Communications.HTTP_REQUEST_METHOD_GET,
         :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON},
        method(:alRecibir));
}

(:typecheck(false))
function alRecibir(code, data) {
    if (code == 200 && data != null) { … }   // -104: no hay móvil; -400 y similares: respuesta no válida
}
```

Para mandar datos: `:method => Communications.HTTP_REQUEST_METHOD_POST` y `:headers => {"Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON}`. Si el móvil no está, guarda lo pendiente en `Application.Storage` y reintenta más tarde (lo hace el ejemplo `hoy/`).

### Sensores

```monkeyc
// Pulso y brújula
Sensor.setEnabledSensors([Sensor.SENSOR_HEARTRATE]);
Sensor.enableSensorEvents(method(:onSensor));
function onSensor(info as Sensor.Info) as Void { /* info.heartRate, info.heading */ }

// Intervalos entre latidos (VFC) o acelerómetro (saltos de comba)
Sensor.registerSensorDataListener(method(:onSensorData), {
    :period => 1,
    :heartBeatIntervals => {:enabled => true}
});
function onSensorData(data as Sensor.SensorData) as Void { /* data.heartRateData.heartBeatIntervals */ }
```

Apágalos al salir: `Sensor.enableSensorEvents(null)` y `Sensor.unregisterSensorDataListener()`.

### GPS

```monkeyc
Position.enableLocationEvents(Position.LOCATION_CONTINUOUS, method(:onPosition));
function onPosition(info as Position.Info) as Void {
    // info.position.toDegrees() -> [lat, lon]; info.accuracy (QUALITY_POOR, QUALITY_USABLE, QUALITY_GOOD)
}
// Al salir:
Position.enableLocationEvents(Position.LOCATION_DISABLE, null);
```

### Vibrar

```monkeyc
if (Attention has :vibrate) {
    Attention.vibrate([new Attention.VibeProfile(80, 300)]);   // intensidad 0-100, milisegundos
}
```

### Grabar una actividad (sale en Garmin Connect)

```monkeyc
var s = ActivityRecording.createSession({
    :name => "Pádel",
    :sport => ActivityRecording.SPORT_TENNIS,
    :subSport => ActivityRecording.SUB_SPORT_GENERIC
});
s.start();   // … s.stop(); s.save();  o  s.discard();
```

Si el modelo no tiene el deporte, usa el más parecido y pon el nombre bien. Los campos FIT propios se definen en `resources/fit/` y se crean con `s.createField(...)`; con apps instaladas por cable puede que no salgan en Garmin Connect.

### Botones (relojes de cinco botones)

En una clase que herede de `WatchUi.BehaviorDelegate`:

| Botón | Función |
|---|---|
| START (arriba a la derecha) | `onSelect()` |
| ATRÁS (abajo a la derecha) | `onBack()` |
| ARRIBA | `onPreviousPage()` |
| ABAJO | `onNextPage()` |
| Mantener ARRIBA | `onMenu()` |

En relojes táctiles, `onTap` y `onSwipe` también llegan. Para menús, `WatchUi.Menu2` con un `Menu2InputDelegate`.

### Guardar datos

- `Application.Storage.setValue("clave", valor)` y `getValue("clave")`: datos de la app (historial, configuración elegida en el reloj).
- `Application.Properties`: ajustes definidos en `resources/settings`. En apps instaladas por cable no se pueden cambiar desde el móvil.

## 6. Memoria y batería

- Las fuentes propias son lo que más memoria gasta: incluye solo los caracteres que vas a usar.
- Guarda historiales cortos (por ejemplo, 14 o 21 días) en listas pequeñas.
- La esfera se repinta una vez por minuto. Si quieres segundos, píntalos solo con la muñeca levantada (`onExitSleep` y `onEnterSleep`) o con `onPartialUpdate`, que tiene un presupuesto de tiempo muy justo.
- Apaga el GPS y los sensores en cuanto dejen de hacer falta.
- En el simulador, «File > View Memory» enseña lo que usa cada app.
