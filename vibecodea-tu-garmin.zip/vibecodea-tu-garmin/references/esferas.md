# Esferas que se leen bien

Una esfera se mira cien veces al día durante un segundo. Lo que importa es que se lea de un vistazo, que no se pise nada y que no gaste batería.

## Diseño

- **Pocas cosas y grandes.** La hora manda; después, de 6 a 10 datos elegidos por la persona. Si quiere más, usa una línea que vaya rotando (una frase distinta cada minuto, o cada pocos segundos al levantar la muñeca), como en `ejemplos/fenix5/esfera/`.
- **Mensajes con prioridad.** En la línea que rota, lo urgente se queda fijo: un pendiente a punto de empezar, un aviso de tormenta, la hora de dormir. Lo demás va rotando.
- **Colores con sentido.** Verde es bien, amarillo es regular y rojo pide atención, igual en todas las piezas. En MIP hay pocos colores: usa los puros (blanco, negro, rojo, verde, azul, amarillo, naranja, gris) y nada de degradados.
- **Contraste.** Fondo negro y texto claro. El gris oscuro solo para datos que no están disponibles (por ejemplo, sin móvil).
- **Todo relativo al tamaño.** Calcula las posiciones como fracción del ancho y el alto (`dc.getWidth()`, `dc.getHeight()`). Un diseño de 240×240 no sirve tal cual en 416×416.

## La zona segura

En un reloj redondo, lo que está cerca del borde se corta. Define un radio seguro (por ejemplo, el radio menos un 10 %) y comprueba que **cada texto e icono** cabe entero dentro. Comprueba también que entre dos elementos quedan al menos 2 píxeles.

Hazlo con el peor caso, no con datos bonitos: las 23:59, 88.888 pasos, -12°, una batería del 100 %, el texto más largo que pueda salir en la línea que rota y, también, el reloj sin datos del móvil.

## Comprobar sin el reloj

Si no hay simulador a mano, dibuja la esfera en una imagen con Python (Pillow) usando las mismas coordenadas y fuentes, y calcula las cajas de cada elemento. `ejemplos/fenix5/herramientas/vista_previa.py` lo hace para la esfera del ejemplo: lee las fuentes BMFont, pinta cada caso y marca en rojo lo que se sale del círculo o se pisa. Adáptalo a tu diseño y enséñale las imágenes a la persona antes de instalar.

## Fuentes

- Las fuentes del sistema (`Graphics.FONT_NUMBER_HOT`, `FONT_MEDIUM`, `FONT_XTINY`…) funcionan en todos los modelos, pero cambian de tamaño de uno a otro.
- Las fuentes propias se ven igual en todas partes y se leen mejor, a cambio de memoria. `scripts/generar_fuente.py` crea una a partir de un archivo TTF u OTF libre (DejaVu, Inter, Roboto…), con solo los caracteres que necesitas. En MIP, genérala sin suavizado (es la opción por defecto); en AMOLED, con `--suavizado`.
- Incluye tildes, «ñ», «°», «·» y los signos que uses, o saldrán huecos.

## Segundos y muñeca levantada

- `onUpdate` se llama una vez por minuto en reposo.
- Al levantar la muñeca llega `onExitSleep`: durante unos segundos se puede pintar cada segundo. Con `onEnterSleep` se vuelve al ritmo de un minuto.
- `onPartialUpdate` permite pintar segundos siempre, pero con un límite de tiempo por llamada muy estricto: solo una zona pequeña, con `dc.setClip`.

## AMOLED

- En el modo siempre encendido, la pantalla se puede marcar si se dejan píxeles fijos. Comprueba `System.getDeviceSettings().requiresBurnInProtection` y, en ese modo, pinta poco (hora y poco más), con pocos píxeles encendidos, y mueve ligeramente la posición cada minuto.
- Fuera de ese modo hay color de sobra, pero el negro sigue siendo lo que menos gasta.

## Datos que llegan de fuera

- **El tiempo** se pide a través del móvil desde segundo plano, por ejemplo a Open-Meteo, que es gratis y no necesita clave (`ejemplos/fenix5/esfera/source/F5Service.mc`). Guárdalo con la hora a la que llegó y no lo enseñes si tiene más de 3 horas.
- **La posición** para el tiempo y para el sol: guarda la última conocida (`Position.getInfo()` o la de la última actividad) en lugar de encender el GPS desde la esfera.
- **Métricas calculadas fuera** (energía, sueño): igual que el tiempo, con su caducidad. Ver `nube-opcional.md`.

## Explicar la esfera

Cuando termines, entrega la tabla «dónde · qué ves · qué significa», y otra con cada frase que pueda salir en la línea que rota. Sin eso, la persona no sabrá qué es «INTENSIDAD 120 MIN» ni por qué un número sale en amarillo.
