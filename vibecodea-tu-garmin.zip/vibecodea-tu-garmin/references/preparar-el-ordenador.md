# Preparar el ordenador

Comprueba cada paso antes de pasar al siguiente. Lo que necesita una cuenta o aceptar una licencia lo hace la persona.

## 1. Java

El compilador de Connect IQ es un programa en Java.

- Comprueba si está: `java -version`.
- Si no está, instala un JDK reciente. Temurin es gratis (adoptium.net). En Mac con Homebrew: `brew install --cask temurin`.

## 2. El SDK de Connect IQ

1. La persona descarga el **SDK Manager** desde la web de Garmin para desarrolladores (developer.garmin.com/connect-iq/sdk/) y lo abre.
2. Inicia sesión con su cuenta de Garmin y acepta la licencia. Esto lo hace ella.
3. En la pestaña de SDK descarga la versión más reciente, y en la de dispositivos descarga **su reloj**.

Dónde queda todo:

- macOS: `~/Library/Application Support/Garmin/ConnectIQ/` (carpetas `Sdks/` y `Devices/`)
- Windows: `%APPDATA%\Garmin\ConnectIQ\`
- Linux: `~/.Garmin/ConnectIQ/`

El compilador es `Sdks/<versión>/bin/monkeybrains.jar`; en la misma carpeta están el script `monkeyc` y el simulador (`connectiq` y `monkeydo`).

## 3. La clave de desarrollador

Sirve para firmar las apps y se crea una sola vez. Hay dos formas:

- Con `scripts/nueva_clave.sh`, que usa openssl y la deja en `~/.garmin/developer_key.der`.
- En VS Code: paleta de comandos y «Monkey C: Generate a Developer Key».

Guárdala fuera de cualquier repositorio y haz una copia de seguridad: si se pierde, no se puede recuperar. Nunca la subas a internet ni la pegues en un chat.

## 4. VS Code y la extensión Monkey C

Es imprescindible en modo guiado y opcional en modo completo.

- Instala VS Code y la extensión «Monkey C» de Garmin.
- En la paleta de comandos, «Monkey C: Verify Installation».
- Para compilar: paleta de comandos, «Monkey C: Build for Device», y elegir el reloj. Que guarde el `.prg` en una carpeta fácil de encontrar.

## 5. Si compilas desde una máquina virtual o un contenedor

A veces tu terminal es un Linux distinto del ordenador de la persona (por ejemplo, el de una app de escritorio que comparte carpetas). En ese caso necesitas allí:

- Java.
- La carpeta del SDK. `monkeybrains.jar` es Java y funciona en cualquier sistema, así que vale la del Mac o la de Windows. Pide a la persona que comparta la carpeta donde lo tiene.
- La carpeta del reloj dentro de `~/.Garmin/ConnectIQ/Devices/<id>`. Si el compilador no encuentra el dispositivo, revisa esta ruta.
- La clave de desarrollador, en una carpeta compartida que no sea un repositorio.

Para instalar, la unidad del reloj (si es USB) tiene que estar también entre las carpetas compartidas.
