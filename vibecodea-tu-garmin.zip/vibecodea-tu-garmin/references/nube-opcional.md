# Datos fuera del reloj (opcional)

Esta parte es para quien quiere más de lo que el reloj puede hacer solo: guardar su historial, verlo en un panel o calcular métricas con datos que la API del reloj no da (sueño, estrés, Body Battery en modelos antiguos…). Es la parte más técnica. Propónla solo si la persona la pide o si lo que quiere no se puede hacer de otra forma.

## Cómo viajan los datos

```
Reloj --(Bluetooth)--> app Garmin Connect del móvil --(internet)--> tu servidor
Garmin Connect (la nube de Garmin) --(API, si la persona tiene acceso)--> tu servidor
Tu servidor --(lo pide el reloj cada 30 min a través del móvil)--> la esfera
```

- El reloj no tiene internet propio: todo pasa por el móvil, y desde segundo plano como mucho cada 5 minutos.
- Lo que el reloj no puede leer de sí mismo (la puntuación de sueño de Garmin, el estrés de todo el día en modelos antiguos) se puede bajar de Garmin Connect si la persona tiene una forma de acceso a sus propios datos. Compruébalo en la documentación actual de Garmin para desarrolladores; cambia con el tiempo.

## Ejemplo completo con Supabase (`ejemplos/fenix5/nube/`)

| Archivo | Qué hace |
|---|---|
| `01_tablas.sql` | Tablas: datos del día que manda el reloj, eventos (gimnasio, pádel…), resumen diario de Garmin y ajustes |
| `02_cron.sql` | Tarea programada que llama a la función cada 3 horas para bajar los datos de Garmin |
| `03_metricas.sql` | Columnas de métricas (nota de sueño, recuperación, esfuerzo…), tabla semanal y un glosario con la explicación de cada dato |
| `04_pendientes.sql` | Tabla de pendientes para el widget `hoy/` |
| `reloj/index.ts` | La función (Edge Function de Supabase): recibe lo que manda el reloj, calcula las métricas y responde a la esfera |

Para usarlo:

1. La persona crea un proyecto en Supabase con su cuenta.
2. Ejecutas los SQL en orden, cambiando `TU-PROYECTO` por la referencia de su proyecto.
3. Generas un token aleatorio largo (`openssl rand -hex 24`) y lo guardas en la tabla `ajustes`. El reloj lo manda en la cabecera `x-reloj-token` para que nadie más pueda escribir.
4. Despliegas `reloj/index.ts` como función llamada `reloj`, sin verificación JWT (la protege el token).
5. Si hay acceso a la API de Garmin, su clave va en los secretos de la función (`GARMIN_API_KEY`), nunca en el código. La pega la persona.
6. En las apps del reloj, pones la dirección de la función y el token en las constantes `URL` y `TOKEN`.

## Privacidad y seguridad

- Son datos de salud: la base de datos es privada, con las políticas de seguridad (RLS) activadas y sin acceso público.
- El token va dentro de las apps del reloj. Si el código se publica, **antes se quita el token**. En los ejemplos de esta skill está sustituido por `CAMBIA-ESTE-TOKEN`.
- Cambia la zona horaria del ejemplo (`Europe/Madrid`) por la de la persona.
- Las métricas calculadas son estimaciones de bienestar. Explícalo en la chuleta.

## Atajo de iPhone para mandar cosas al reloj

Con la función del ejemplo, un atajo de Siri puede apuntar pendientes que luego salen en el widget `hoy/`: «Oye Siri, añadir al reloj».

Acciones, en orden, en la app Atajos:

1. **Solicitar entrada** (texto), con la pregunta «¿Qué apunto en el reloj?».
2. **Codificar con URL** la entrada.
3. **Texto**: aquí va el token. **Lo pega la persona**, no lo escribas tú en su móvil.
4. **URL**: `https://TU-PROYECTO.supabase.co/functions/v1/reloj/apuntar?q=` + la variable «Texto codificado con URL» + `&t=` + la variable «Texto».
5. **Obtener contenido de URL**.
6. **Mostrar contenido**. Siri lee la respuesta en voz alta.

La función entiende frases como «llamar a mamá a las 6 y media» o «mañana a las 11:30 dentista».
