# Investigar el reloj

Antes de proponer nada, averigua qué puede hacer su modelo. Si te inventas una resolución o una API, la app no compilará o se verá mal.

## 1. El identificador del modelo

Connect IQ nombra cada reloj con un id corto, que es el que se pasa al compilador con `-d`: `fenix5`, `fr265`, `venu3`, `fenix7pro`, `instinct2`…

- Con el SDK instalado: son los nombres de las carpetas de `Devices`, o la salida de `python3 scripts/info_reloj.py --lista`.
- Sin el SDK: la página de dispositivos compatibles de Garmin (developer.garmin.com/connect-iq/compatible-devices/).

Un mismo nombre comercial puede tener varios ids según el tamaño (42, 47 o 51 mm), la versión (Solar, Pro) o la pantalla (AMOLED). Confirma con la persona cuál es el suyo.

Dónde está la carpeta `Devices`:

- macOS: `~/Library/Application Support/Garmin/ConnectIQ/Devices`
- Windows: `%APPDATA%\Garmin\ConnectIQ\Devices`
- Linux: `~/.Garmin/ConnectIQ/Devices`

## 2. Ficha técnica

`python3 scripts/info_reloj.py <id>` lee `compiler.json` y `simulator.json` del modelo y resume la resolución y la forma, los colores, el tipo de pantalla, si es táctil, la versión de Connect IQ, la memoria de cada tipo de app y los botones. Si falta algún campo, abre el JSON y búscalo: el formato cambia entre versiones del SDK.

Para qué sirve cada dato:

- **Resolución y forma.** Todo el diseño se escala a partir de aquí. No copies coordenadas del ejemplo de 240×240: calcula posiciones relativas al ancho y al alto.
- **MIP o AMOLED.** Las pantallas MIP (fēnix, Instinct, Forerunner antiguos) tienen pocos colores y se leen muy bien al sol. Las AMOLED (Venu, Epix, Forerunner 265/965, fēnix 8 AMOLED…) tienen millones de colores, pero en el modo siempre encendido hay que proteger la pantalla (ver `esferas.md`).
- **Versión de Connect IQ.** Decide qué APIs existen. Por ejemplo, el historial de Body Battery y de estrés existe desde la 3.3.0, y las complicaciones (Body Battery, recuperación, estado de entrenamiento, puntuación de sueño…) desde la 4.2.0. La tabla completa está en `sacarle-partido.md`. Compruébalo en el código con `has` (ver `monkey-c.md`).
- **Memoria.** Hay un límite para cada tipo: esfera, widget, app y proceso en segundo plano. Las fuentes propias y las imágenes son lo que más gasta.

## 3. Qué trae ya de serie

Busca el manual del modelo en garmin.com (las páginas «webhelp») y anota lo que ya hace de lo que la persona ha pedido. Conviene comprobar especialmente:

- VO2 máx. (casi todos lo estiman al correr al aire libre con pulso).
- Alerta de tormenta en el barómetro.
- Guardar una ubicación y volver a ella, o «Volver al inicio» y TracBack durante una actividad.
- Actividad de fuerza con recuento de repeticiones.
- Entrenamientos por intervalos.
- Body Battery, puntuación de sueño, HRV Status, hidratación.
- Perfiles de HIIT, boxeo, comba, escalada o bloque.

Cuéntaselo con honestidad. Lo que trae de serie suele ser más fiable y gastar menos batería; lo que hagas tú aporta lo que falta, o lo junta de una forma más cómoda.

## 4. Cómo se conecta al ordenador

- **Unidad USB:** los modelos antiguos y los que no tienen música (fēnix 5, Forerunner 935, Instinct de primera generación…). Aparece una unidad llamada GARMIN.
- **MTP:** los modelos con música (casi todos los actuales) y algunos Edge recientes. En Mac no aparecen en el Finder.

Si dudas, que lo enchufe y mire si aparece una unidad GARMIN.

## 5. Límites que conviene saber desde el principio

- Las apps instaladas por cable no se pueden configurar desde la app del móvil. Los ajustes se cambian en el código y se reinstala.
- Los campos FIT propios pueden no aparecer en Garmin Connect cuando la app se instala por cable.
- Los datos de internet llegan normalmente a través del móvil, y desde segundo plano como mucho cada 5 minutos.
- En los modelos antiguos, un deporte nuevo se graba como el más parecido (el pádel como tenis), y Garmin Connect enseña ese tipo.
- No hay acceso a la señal cruda de los sensores ni al firmware.
