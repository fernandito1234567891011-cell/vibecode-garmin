# Entrevista: qué quiere la persona

El objetivo es saber lo justo para proponer un plan, en una o dos rondas. Pregunta con opciones (si tienes una herramienta para hacer preguntas, úsala) y deja siempre la posibilidad de escribir otra cosa.

## Ronda 1 (siempre)

1. **¿Qué reloj tienes?** Pide el modelo exacto, con el tamaño: «Forerunner 265S», «fēnix 7 Pro Solar 47 mm», «Venu 3S». Si no lo sabe, lo encuentra en el reloj (Ajustes > Sistema > Acerca de) o en la app Garmin Connect.
2. **¿Qué ordenador usas?** Mac, Windows o Linux. Lo necesitas para instalar.
3. **¿Qué te gustaría añadir?** Ofrece ideas según lo que haga:
   - Una esfera a su gusto.
   - Un deporte que su reloj no trae: pádel, HIIT, Tabata, EMOM, comba, boxeo, escalada…
   - Widgets: agua, pendientes, montaña, volver al coche.
   - Ver juntas sus métricas de salud y entrenamiento (energía, sueño, recuperación). Si su reloj ya las calcula, se leen tal cual; si no, se estiman con la parte de nube, que es opcional y más técnica.
4. **¿Qué haces normalmente?** Deportes, horarios, si va a la montaña, si entrena con el móvil encima.

## Ronda 2 (si quiere una esfera)

Enséñale este menú y que elija entre 6 y 10 datos. Explica cada uno en una línea y con palabras normales:

| Dato | Qué es | Necesita |
|---|---|---|
| Hora y fecha | — | — |
| Pulso | Pulsaciones por minuto en este momento | Sensor de pulso |
| Pasos y objetivo | Pasos de hoy y su meta diaria | — |
| Calorías | Gastadas hoy, en reposo y moviéndose | — |
| Minutos de intensidad | Minutos de ejercicio moderado o intenso en la semana; los intensos cuentan doble. La OMS recomienda 150 a la semana | Pulso, para contar los intensos |
| Pisos subidos | Plantas subidas hoy | Barómetro |
| Batería | Porcentaje que le queda | — |
| Notificaciones | Mensajes sin leer del móvil | Móvil conectado |
| Tiempo | Temperatura, cielo y probabilidad de lluvia | Móvil conectado; se actualiza cada 30 minutos |
| Salida y puesta del sol | — | Una posición GPS reciente |
| Altitud | Metros sobre el nivel del mar | Barómetro; solo tiene sentido en la montaña |
| Presión y tormenta | Aviso si la presión cae deprisa | Barómetro |
| Fase de la luna | — | — |
| Segundos | Solo al levantar la muñeca, para ahorrar batería | — |
| Cuenta atrás para dormir | Cuánto falta para su hora de dormir | Su hora de dormir |
| Body Battery, estrés, sueño, recuperación, estado de entrenamiento, VO2 máx. | Los números que ya calcula su Garmin, juntos en la esfera | Un reloj que los tenga y un Connect IQ moderno (ver `sacarle-partido.md`) |
| Energía, sueño, recuperación (estimados) | Estimaciones propias, para relojes que no los traen | La parte de nube |

Adapta el menú a su reloj: quita lo que no puede tener y añade lo que su modelo ofrece de más según el mapa de posibilidades.

Pregunta también:

- Si la quiere digital o analógica.
- Qué colores le gustan. En pantallas MIP hay pocos colores: avísalo.
- Si ve bien de cerca o prefiere letra grande.
- Su hora de dormir y de levantarse, si quiere la cuenta atrás.

## Cómo preguntar

- Pocas preguntas y con opciones; nunca un formulario de quince campos.
- Si algo tiene un coste (memoria, batería, complejidad), dilo en la misma opción.
- No metas datos que no ha elegido solo porque caben. Una esfera con lo justo se lee mejor.
- Si pide algo que su reloj no puede hacer, dilo y ofrece lo más parecido.

## Ejemplo de primer mensaje

> Vamos a ello. Para proponerte algo que funcione en tu reloj necesito tres cosas: el modelo exacto (con el tamaño), si usas Mac o Windows, y qué te gustaría añadir: ¿una esfera propia, algún deporte que no trae (pádel, HIIT, comba…), widgets como agua o pendientes, o métricas de energía y sueño?
