# Instalar en el reloj

Instalar es copiar el archivo `.prg` en la carpeta `GARMIN/APPS` del reloj. Lo que cambia es cómo se llega a esa carpeta.

## 1. ¿Unidad USB o MTP?

Que la persona enchufe el reloj con su cable:

- Si aparece una unidad llamada **GARMIN** (en el Finder, el Explorador o `/Volumes/GARMIN`), es una unidad USB.
- Si no aparece en el Mac, o en Windows sale como un dispositivo con «Almacenamiento interno», es **MTP**. Pasa en los modelos con música y en algunos Edge recientes.

## 2. Unidad USB (modelos antiguos o sin música)

1. Copia el `.prg` a `GARMIN/APPS/`.
2. En Mac, el sistema crea archivos ocultos `._NOMBRE.PRG` al copiar. Bórralos (`rm /Volumes/GARMIN/GARMIN/APPS/._*`) para que el reloj no intente cargarlos.
3. Expulsa la unidad y desenchufa el reloj.

## 3. MTP

Antes de nada, **cierra Garmin Express del todo**, también el icono de la barra de menús (Mac) o de la bandeja del sistema (Windows). Si está abierto, se queda con el reloj y no deja copiar.

- **Windows:** en el Explorador de archivos, el reloj sale como dispositivo. Entra en «Almacenamiento interno» > `GARMIN` > `APPS` y pega el `.prg`.
- **Mac:** el Finder no ve los dispositivos MTP. La persona instala **OpenMTP** (gratis, openmtp.ganeshrvel.com), abre el reloj y arrastra el `.prg` a `GARMIN/APPS`.
- **Linux:** se monta con `gio mount` (en GNOME aparece solo) o con `jmtpfs`.

En modo completo puedes preparar el archivo y el comando, pero la copia por MTP en Mac suele tener que hacerla la persona con OpenMTP. Explícale exactamente dónde soltar el archivo.

## 4. Después de desenchufar

El reloj carga la app al desconectarlo del ordenador. Dónde buscarla:

- **Esfera:** en la lista de esferas (normalmente manteniendo ARRIBA o en Ajustes > Esfera del reloj).
- **Widget:** en la lista de widgets o glances, pulsando ARRIBA o ABAJO desde la esfera. Si no sale, se añade desde los ajustes de widgets o glances.
- **App:** en la lista de actividades y apps al pulsar START. Se puede añadir a favoritas.

## 5. Si algo falla

- **El registro de errores** está en `GARMIN/APPS/LOGS/CIQ_LOG.YML`: indica la app, el archivo y la línea. Vuelve a enchufar el reloj y léelo.
- **Mensajes propios:** si creas un archivo de texto vacío en `GARMIN/APPS/LOGS/` con el mismo nombre que el `.prg` (por ejemplo `MIAPP.TXT`), lo que la app escriba con `System.println` se guarda ahí.
- **La app no aparece:** comprueba que el `.prg` se compiló para su reloj exacto (`-d`), que está en `GARMIN/APPS` y que el reloj se ha desenchufado.
- **Para desinstalar:** borra el `.prg` de `GARMIN/APPS` o quita la app desde el propio reloj.

## 6. Ajustes y actualizaciones

- Las apps instaladas por cable no se configuran desde Garmin Connect ni desde la app Connect IQ. Si la persona quiere cambiar algo (su hora de dormir, sus colores), se cambia en el código y se vuelve a instalar.
- Para actualizar, se compila de nuevo y se copia encima el `.prg` con el mismo nombre.
- Hay otra vía, subir la app a la tienda Connect IQ como «beta», que solo ve su autor; permite usar los ajustes desde el móvil. Necesita una cuenta de desarrollador y hoy en día instalar las betas es engorroso: déjalo como último recurso.
