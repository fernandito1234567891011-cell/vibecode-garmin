// GENERADO por gym_preview.py: no editar a mano.
module GymLayout {
    const EX_Y = 34;
    const SET_Y = 52;
    const BIG_Y = 58;
    const LBL_Y = 120;
    const ROW_Y = 140;
    const ROW_ICON_Y = 145;
    const TIMER_X = 82;
    const HR_X = 140;
    const HINT_Y = 166;
    const TOT_Y = 186;
    const REST_TITLE_Y = 34;
    const REST_LAST_Y = 120;
    const REST_EDIT_Y = 140;
    const REST_ROW_Y = 158;
    const REST_ICON_Y = 163;
    const REST_HINT_Y = 186;
    const RING_R = 113;
    const RING_PEN = 6;
}
