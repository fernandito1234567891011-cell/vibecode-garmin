using Toybox.Graphics;
using Toybox.WatchUi;

// Pantallas de «Gimnasio F5». Posiciones: GymLayout (revisadas con gym_preview.py).
class GymView extends WatchUi.View {

    const C_GOLD = 0xFFAA00;
    const C_GREEN = 0x55FF55;
    const C_GRAY = 0xAAAAAA;
    const C_WHITE = 0xFFFFFF;

    hidden var m;
    hidden var fTime, fMed, fSmall, fXs, iHeart;

    function initialize(model) {
        View.initialize();
        m = model;
    }

    function onLayout(dc) {
        fTime = WatchUi.loadResource(Rez.Fonts.Time);
        fMed = WatchUi.loadResource(Rez.Fonts.Med);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
        iHeart = WatchUi.loadResource(Rez.Drawables.Heart);
    }

    function text(dc, x, y, font, s, color) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, Graphics.TEXT_JUSTIFY_CENTER);
    }

    function mmss(secs) {
        return (secs / 60).toString() + ":" + (secs % 60).format("%02d");
    }

    function onUpdate(dc) {
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        if (m.state == GymModel.ST_READY) {
            drawReady(dc);
        } else if (m.state == GymModel.ST_SET) {
            drawSet(dc);
        } else if (m.state == GymModel.ST_REST) {
            drawRest(dc);
        } else {
            drawDone(dc);
        }
    }

    function drawReady(dc) {
        text(dc, 120, 40, fSmall, "GIMNASIO", C_GOLD);
        text(dc, 120, 72, fSmall, m.exName(), C_WHITE);
        text(dc, 120, 98, fXs, "DESCANSO " + m.restSecs.toString() + " S", C_GRAY);
        text(dc, 120, 132, fSmall, "START: EMPEZAR", C_GREEN);
        text(dc, 120, 160, fXs, "ATRÁS: EJERCICIO", C_GRAY);
        text(dc, 120, 180, fXs, "Y DESCANSO", C_GRAY);
    }

    function hrRow(dc, yText, yIcon, timer) {
        var hr = m.heartRate();
        var x;
        if (timer != null) {
            text(dc, GymLayout.TIMER_X, yText, fMed, timer, C_WHITE);
            x = GymLayout.HR_X;
        } else {
            x = 120 - (16 + dc.getTextWidthInPixels(hr, fMed)) / 2;
        }
        dc.drawBitmap(x, yIcon, iHeart);
        dc.setColor(C_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x + 16, yText, fMed, hr, Graphics.TEXT_JUSTIFY_LEFT);
    }

    function drawSet(dc) {
        text(dc, 120, GymLayout.EX_Y, fSmall, m.exName(), C_GOLD);
        text(dc, 120, GymLayout.SET_Y, fSmall, "SERIE " + m.setNum.toString(), C_WHITE);
        text(dc, 120, GymLayout.BIG_Y, fTime, m.counter.reps.toString(), C_WHITE);
        text(dc, 120, GymLayout.LBL_Y, fXs, m.accelOk ? "REPES" : "REPES (A MANO)", C_GRAY);
        hrRow(dc, GymLayout.ROW_Y, GymLayout.ROW_ICON_Y, mmss(m.setSeconds()));
        text(dc, 120, GymLayout.HINT_Y, fXs, "START: FIN DE SERIE", C_GRAY);
        text(dc, 120, GymLayout.TOT_Y, fXs, "TOTAL " + m.totalReps.toString() + " REPES", C_GRAY);
    }

    function drawRest(dc) {
        // Anillo que se vacía con el descanso
        var deg = (360 * m.restLeft / m.restSecs).toNumber();
        if (deg >= 2) {
            dc.setPenWidth(GymLayout.RING_PEN);
            dc.setColor(0x00FF55, Graphics.COLOR_TRANSPARENT);
            if (deg >= 360) {
                dc.drawCircle(120, 120, GymLayout.RING_R);
            } else {
                dc.drawArc(120, 120, GymLayout.RING_R, Graphics.ARC_CLOCKWISE, 90, (90 - deg + 360) % 360);
            }
            dc.setPenWidth(1);
        }
        text(dc, 120, GymLayout.REST_TITLE_Y, fSmall, "DESCANSO", C_GREEN);
        text(dc, 120, GymLayout.BIG_Y, fTime, mmss(m.restLeft < 0 ? 0 : m.restLeft), C_WHITE);
        text(dc, 120, GymLayout.REST_LAST_Y, fSmall,
            "SERIE " + m.setNum.toString() + ": " + m.lastReps.toString() + " REPES", C_WHITE);
        text(dc, 120, GymLayout.REST_EDIT_Y, fXs, "FLECHAS: CORRIGE", C_GRAY);
        hrRow(dc, GymLayout.REST_ROW_Y, GymLayout.REST_ICON_Y, null);
        text(dc, 120, GymLayout.REST_HINT_Y, fXs, "START: EMPEZAR", C_GRAY);
    }

    function drawDone(dc) {
        text(dc, 120, 40, fSmall, "GUARDADO", C_GREEN);
        text(dc, 120, 58, fTime, m.totalReps.toString(), C_WHITE);
        text(dc, 120, 122, fXs, "REPES", C_GRAY);
        text(dc, 120, 146, fSmall, m.totalSets.toString() + " SERIES · " + m.minutes().toString() + " MIN", C_WHITE);
        text(dc, 120, 180, fXs, "ATRÁS: SALIR", C_GRAY);
    }
}
