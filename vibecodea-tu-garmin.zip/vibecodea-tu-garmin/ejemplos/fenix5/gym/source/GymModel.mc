using Toybox.Activity;
using Toybox.ActivityRecording;
using Toybox.Application;
using Toybox.Attention;
using Toybox.Communications;
using Toybox.FitContributor;
using Toybox.Lang;
using Toybox.Sensor;
using Toybox.System;
using Toybox.Time;
using Toybox.Timer;
using Toybox.WatchUi;

// Lógica de «Gimnasio F5»: series, descansos, repeticiones y grabación.
//
// Un solo botón por serie: START al terminar la serie. El descanso corre solo, vibra a falta de
// 10 s y al acabar empieza la siguiente serie sin tocar nada (START la empieza antes).
// Cada vuelta (lap) del archivo = una serie y su descanso, y se escribe al final del descanso,
// así las repeticiones corregidas con las flechas quedan bien guardadas.
class GymModel {

    enum {
        ST_READY,
        ST_SET,
        ST_REST,
        ST_DONE
    }

    var EXERCISES = ["EJERCICIO", "PRESS BANCA", "PRESS INCLIN.", "SENTADILLA", "PESO MUERTO", "PRENSA",
                     "REMO", "JALÓN", "DOMINADAS", "PRESS MILITAR", "ELEV. LATERAL", "CURL BÍCEPS",
                     "TRÍCEPS", "FONDOS", "ZANCADAS", "HIP THRUST", "ABDOMINALES", "PECHO MÁQ.",
                     "FEMORAL", "CUÁDRICEPS", "GEMELOS", "OTRO"];
    var REST_OPTIONS = [45, 60, 90, 120, 150, 180];

    // Nube opcional: tu Supabase (función «reloj»).
    const URL = "https://TU-PROYECTO.supabase.co/functions/v1/reloj";
    const TOKEN = "CAMBIA-ESTE-TOKEN";

    var state = ST_READY;
    var curEx = 0;
    var nextEx = -1;
    var exNum = 1;
    var setNum = 0;
    var totalSets = 0;
    var totalReps = 0;
    var lastReps = 0;
    var lastSetSecs = 0;
    var restSecs = 90;
    var restLeft = 0;
    var setStartMs = 0;
    var startedAt = 0;
    var accelOk = false;
    var counter;

    hidden var mSession = null;
    hidden var mTimer = null;
    hidden var mLog = [];
    hidden var fReps, fSet, fEx, fSetTime, fTotReps, fTotSets;

    function initialize() {
        counter = new RepCounter();
        var r = Application.Storage.getValue("rest");
        if (r instanceof Lang.Number && r >= 15 && r <= 600) {
            restSecs = r;
        }
        var e = Application.Storage.getValue("lastEx");
        if (e instanceof Lang.Number && e >= 0 && e < EXERCISES.size()) {
            curEx = e;
        }
        mTimer = new Timer.Timer();
        mTimer.start(method(:onTick), 1000, true);
        sendPending();
    }

    function exName() {
        if (curEx == 0) {
            return "EJERCICIO " + exNum.toString();
        }
        return EXERCISES[curEx];
    }

    function heartRate() {
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.currentHeartRate != null) {
            return ai.currentHeartRate.toString();
        }
        return "--";
    }

    function setSeconds() {
        return (System.getTimer() - setStartMs) / 1000;
    }

    // ------------------------------------------------------------ botones

    function onStart() {
        if (state == ST_READY) {
            startSession();
        } else if (state == ST_SET) {
            endSet();
        } else if (state == ST_REST) {
            commitSet();
            beginSet();
        }
    }

    // Flechas: corrigen las repeticiones (las de la serie en curso o las de la que acaba de terminar).
    function adjust(delta) {
        if (state == ST_SET) {
            counter.reps += delta;
            if (counter.reps < 0) {
                counter.reps = 0;
            }
        } else if (state == ST_REST) {
            lastReps += delta;
            if (lastReps < 0) {
                lastReps = 0;
            }
        }
    }

    function chooseExercise(idx) {
        Application.Storage.setValue("lastEx", idx);
        if (state == ST_READY || (state == ST_SET && setNum == 1 && counter.reps == 0)) {
            curEx = idx;
            nextEx = -1;
        } else {
            nextEx = idx;
        }
    }

    function chooseRest(secs) {
        restSecs = secs;
        Application.Storage.setValue("rest", secs);
        if (state == ST_REST && restLeft > secs) {
            restLeft = secs;
        }
    }

    // ------------------------------------------------------------ sesión

    function startSession() {
        mSession = ActivityRecording.createSession({
            :name => "Gimnasio",
            :sport => ActivityRecording.SPORT_TRAINING,
            :subSport => ActivityRecording.SUB_SPORT_STRENGTH_TRAINING
        });
        fReps = mSession.createField("repes", 0, FitContributor.DATA_TYPE_UINT16,
            {:mesgType => FitContributor.MESG_TYPE_LAP, :units => "repes"});
        fSet = mSession.createField("serie", 1, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_LAP});
        fEx = mSession.createField("ejercicio", 2, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_LAP});
        fSetTime = mSession.createField("tiempo_serie", 3, FitContributor.DATA_TYPE_UINT16,
            {:mesgType => FitContributor.MESG_TYPE_LAP, :units => "s"});
        fTotReps = mSession.createField("repes_totales", 4, FitContributor.DATA_TYPE_UINT16,
            {:mesgType => FitContributor.MESG_TYPE_SESSION, :units => "repes"});
        fTotSets = mSession.createField("series_totales", 5, FitContributor.DATA_TYPE_UINT16,
            {:mesgType => FitContributor.MESG_TYPE_SESSION});
        mSession.start();
        startedAt = Time.now().value();
        startAccel();
        beginSet();
    }

    function beginSet() {
        if (nextEx >= 0) {
            curEx = nextEx;
            nextEx = -1;
            exNum += 1;
            setNum = 0;
        }
        setNum += 1;
        counter.reset();
        setStartMs = System.getTimer();
        state = ST_SET;
    }

    function endSet() {
        lastReps = counter.reps;
        lastSetSecs = setSeconds();
        restLeft = restSecs;
        state = ST_REST;
        vibe(1);
    }

    // Guarda la serie terminada (con sus repeticiones ya corregidas) como una vuelta del archivo.
    function commitSet() {
        totalSets += 1;
        totalReps += lastReps;
        mLog.add([curEx, exNum, setNum, lastReps, lastSetSecs]);
        if (mSession != null) {
            fReps.setData(lastReps);
            fSet.setData(setNum);
            fEx.setData(curEx);
            fSetTime.setData(lastSetSecs);
            mSession.addLap();
        }
    }

    function onTick() as Void {
        if (state == ST_REST) {
            restLeft -= 1;
            if (restLeft == 10) {
                vibe(0);
            }
            if (restLeft <= 0) {
                commitSet();
                beginSet();
                vibe(2);
            }
        }
        WatchUi.requestUpdate();
    }

    // Termina la sesión. save = true la guarda en el reloj (y sube a Garmin Connect al sincronizar).
    function finish(save) {
        if (state == ST_SET && counter.reps > 0) {
            lastReps = counter.reps;
            lastSetSecs = setSeconds();
            commitSet();
        } else if (state == ST_REST) {
            commitSet();
        }
        stopAccel();
        if (mSession != null) {
            fReps.setData(0);
            fSet.setData(0);
            fEx.setData(0);
            fSetTime.setData(0);
            if (save) {
                fTotReps.setData(totalReps);
                fTotSets.setData(totalSets);
                mSession.stop();
                mSession.save();
                storeLog();
            } else {
                mSession.stop();
                mSession.discard();
            }
            mSession = null;
        }
        state = ST_DONE;
    }

    // Al cerrar la app: si quedaba algo grabándose, se guarda (mejor que perder el entreno).
    function shutdown() {
        if (mSession != null) {
            finish(true);
        }
        stopAccel();
        if (mTimer != null) {
            mTimer.stop();
            mTimer = null;
        }
    }

    // Historial en el reloj: las últimas 30 sesiones y el detalle de la última (para la nube).
    (:typecheck(false))
    function storeLog() {
        var minutes = (Time.now().value() - startedAt) / 60;
        var hist = Application.Storage.getValue("gymLog");
        if (!(hist instanceof Lang.Array)) {
            hist = [];
        }
        hist.add([startedAt, minutes, totalSets, totalReps]);
        while (hist.size() > 30) {
            hist = hist.slice(1, null);
        }
        Application.Storage.setValue("gymLog", hist);
        Application.Storage.setValue("gymLast", {"t" => startedAt, "min" => minutes, "sets" => mLog});
        var detalle = [];
        for (var i = 0; i < mLog.size(); i++) {
            var r = mLog[i];
            detalle.add({"ejercicio" => EXERCISES[r[0]], "n_ejercicio" => r[1], "serie" => r[2],
                         "repes" => r[3], "segundos" => r[4]});
        }
        var p = Application.Storage.getValue("gymPending");
        if (!(p instanceof Lang.Array)) {
            p = [];
        }
        p.add({"tipo" => "gym", "inicio" => startedAt, "min" => minutes, "series" => totalSets,
               "repes" => totalReps, "detalle" => detalle});
        while (p.size() > 5) {
            p = p.slice(1, null);
        }
        Application.Storage.setValue("gymPending", p);
        sendPending();
    }

    // Sube a la nube la sesión más antigua pendiente; si el móvil no está, se queda para la próxima.
    (:typecheck(false))
    function sendPending() {
        var p = Application.Storage.getValue("gymPending");
        if (!(p instanceof Lang.Array) || p.size() == 0) {
            return;
        }
        if (!System.getDeviceSettings().phoneConnected) {
            return;
        }
        Communications.makeWebRequest(URL, p[0],
            {
                :method => Communications.HTTP_REQUEST_METHOD_POST,
                :headers => {
                    "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                    "x-reloj-token" => TOKEN
                },
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onSent));
    }

    (:typecheck(false))
    function onSent(code, data) {
        if (code != 200) {
            return;
        }
        var p = Application.Storage.getValue("gymPending");
        if (p instanceof Lang.Array && p.size() > 0) {
            p = p.slice(1, null);
            Application.Storage.setValue("gymPending", p);
            if (p.size() > 0) {
                sendPending();
            }
        }
    }

    function minutes() {
        if (startedAt == 0) {
            return 0;
        }
        return (Time.now().value() - startedAt) / 60;
    }

    // ------------------------------------------------------------ sensores y avisos

    function startAccel() {
        accelOk = false;
        if (Sensor has :registerSensorDataListener) {
            try {
                Sensor.registerSensorDataListener(method(:onSensorData),
                    {:period => 1, :accelerometer => {:enabled => true, :sampleRate => 25}});
                accelOk = true;
            } catch (e) {
                accelOk = false;
            }
        }
    }

    function stopAccel() {
        if (accelOk && (Sensor has :unregisterSensorDataListener)) {
            Sensor.unregisterSensorDataListener();
        }
        accelOk = false;
    }

    function onSensorData(data as Sensor.SensorData) as Void {
        if (state != ST_SET) {
            return;
        }
        var a = data.accelerometerData;
        if (a != null) {
            counter.addSamples(a.x, a.y, a.z);
        }
    }

    // 0 = aviso corto (quedan 10 s), 1 = fin de serie, 2 = ¡a por la siguiente!
    function vibe(kind) {
        if (Attention has :vibrate) {
            var p;
            if (kind == 0) {
                p = [new Attention.VibeProfile(60, 200)];
            } else if (kind == 1) {
                p = [new Attention.VibeProfile(80, 250)];
            } else {
                p = [new Attention.VibeProfile(100, 500), new Attention.VibeProfile(0, 200),
                     new Attention.VibeProfile(100, 500)];
            }
            Attention.vibrate(p);
        }
        if (kind == 2 && (Attention has :playTone)) {
            Attention.playTone(Attention.TONE_LOUD_BEEP);
        }
    }
}
