using Toybox.Lang;
using Toybox.Math;

// Cuenta repeticiones con el acelerómetro de la muñeca (25 muestras por segundo, en mili-g).
//
// 1. Estima la gravedad con una media lenta (unos 2 s) y la resta: queda la aceleración del brazo.
// 2. Proyecta esa aceleración sobre la vertical (dirección de la gravedad): en casi todos los
//    ejercicios la muñeca sube y baja una vez por repetición.
// 3. La suaviza y cuenta un ciclo completo (pico arriba y luego pico abajo) como una repetición,
//    con umbral que se adapta a la amplitud de la serie y un mínimo de 0,8 s entre repeticiones.
// En ejercicios donde la mano casi no se mueve (prensa, máquinas de pierna) contará de menos:
// para eso están las flechas.
class RepCounter {

    var reps = 0;

    hidden var mGx = 0.0;
    hidden var mGy = 0.0;
    hidden var mGz = 0.0;
    hidden var mInit = false;
    hidden var mSm = 0.0;
    hidden var mAmp = 60.0;
    hidden var mUp = false;
    hidden var mT = 0;
    hidden var mLastRep = -100;

    function initialize() {
    }

    function reset() {
        reps = 0;
        mSm = 0.0;
        mAmp = 60.0;
        mUp = false;
        mLastRep = mT - 100;
    }

    (:typecheck(false))
    function addSamples(xs, ys, zs) {
        if (xs == null || ys == null || zs == null) {
            return;
        }
        var n = xs.size();
        if (ys.size() < n) {
            n = ys.size();
        }
        if (zs.size() < n) {
            n = zs.size();
        }
        for (var i = 0; i < n; i++) {
            step(xs[i].toFloat(), ys[i].toFloat(), zs[i].toFloat());
        }
    }

    function step(x, y, z) {
        if (!mInit) {
            mGx = x;
            mGy = y;
            mGz = z;
            mInit = true;
        }
        mGx += 0.02 * (x - mGx);
        mGy += 0.02 * (y - mGy);
        mGz += 0.02 * (z - mGz);
        mT += 1;
        var g = Math.sqrt(mGx * mGx + mGy * mGy + mGz * mGz);
        if (g < 200) {
            return;
        }
        var v = ((x - mGx) * mGx + (y - mGy) * mGy + (z - mGz) * mGz) / g;
        mSm += 0.25 * (v - mSm);
        var a = mSm < 0 ? -mSm : mSm;
        mAmp = mAmp * 0.998;
        if (a > mAmp) {
            mAmp = a;
        }
        var th = 0.4 * mAmp;
        if (th < 30) {
            th = 30;
        }
        if (!mUp && mSm > th) {
            mUp = true;
        } else if (mUp && mSm < -th) {
            mUp = false;
            if (mT - mLastRep >= 20) {
                reps += 1;
                mLastRep = mT;
            }
        }
    }
}
