using Toybox.Application;
using Toybox.WatchUi;

// «Gimnasio F5»: series con un solo botón, descanso automático y repeticiones por acelerómetro.
class GymApp extends Application.AppBase {

    hidden var mModel = null;

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        mModel = new GymModel();
        return [new GymView(mModel), new GymDelegate(mModel)];
    }

    function onStop(state) {
        if (mModel != null) {
            mModel.shutdown();
        }
    }
}
