using Toybox.Lang;
using Toybox.WatchUi;

// Botones: START = fin de serie / empezar ya. ARRIBA y ABAJO = corregir repeticiones.
// ATRÁS (o mantener ARRIBA) = menú: ejercicio, descanso, terminar.
class GymDelegate extends WatchUi.BehaviorDelegate {

    hidden var m;

    function initialize(model) {
        BehaviorDelegate.initialize();
        m = model;
    }

    function onSelect() {
        m.onStart();
        WatchUi.requestUpdate();
        return true;
    }

    function onPreviousPage() {
        m.adjust(1);
        WatchUi.requestUpdate();
        return true;
    }

    function onNextPage() {
        m.adjust(-1);
        WatchUi.requestUpdate();
        return true;
    }

    function onBack() {
        if (m.state == GymModel.ST_DONE) {
            return false;
        }
        openMenu();
        return true;
    }

    function onMenu() {
        if (m.state != GymModel.ST_DONE) {
            openMenu();
        }
        return true;
    }

    function openMenu() {
        var menu = new WatchUi.Menu2({:title => "Gimnasio"});
        if (m.state == GymModel.ST_READY) {
            menu.addItem(new WatchUi.MenuItem("Empezar", null, :start, {}));
        } else {
            menu.addItem(new WatchUi.MenuItem("Seguir", null, :resume, {}));
        }
        menu.addItem(new WatchUi.MenuItem("Ejercicio", m.EXERCISES[m.nextEx >= 0 ? m.nextEx : m.curEx], :exercise, {}));
        menu.addItem(new WatchUi.MenuItem("Descanso", m.restSecs.toString() + " s", :rest, {}));
        if (m.state == GymModel.ST_READY) {
            menu.addItem(new WatchUi.MenuItem("Salir", null, :quit, {}));
        } else {
            menu.addItem(new WatchUi.MenuItem("Terminar y guardar", null, :save, {}));
            menu.addItem(new WatchUi.MenuItem("Descartar", null, :discard, {}));
        }
        WatchUi.pushView(menu, new GymMenuDelegate(m), WatchUi.SLIDE_UP);
    }
}

class GymMenuDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        if (id == :start) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.onStart();
        } else if (id == :resume) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
        } else if (id == :exercise) {
            var menu = new WatchUi.Menu2({:title => "Ejercicio"});
            for (var i = 0; i < m.EXERCISES.size(); i++) {
                menu.addItem(new WatchUi.MenuItem(m.EXERCISES[i], null, i, {}));
            }
            WatchUi.pushView(menu, new GymPickDelegate(m, true), WatchUi.SLIDE_LEFT);
        } else if (id == :rest) {
            var menu = new WatchUi.Menu2({:title => "Descanso"});
            for (var i = 0; i < m.REST_OPTIONS.size(); i++) {
                menu.addItem(new WatchUi.MenuItem(m.REST_OPTIONS[i].toString() + " s", null, m.REST_OPTIONS[i], {}));
            }
            WatchUi.pushView(menu, new GymPickDelegate(m, false), WatchUi.SLIDE_LEFT);
        } else if (id == :save) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.finish(true);
        } else if (id == :discard) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.finish(false);
        } else if (id == :quit) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.state = GymModel.ST_DONE;
            WatchUi.popView(WatchUi.SLIDE_DOWN);
        }
        WatchUi.requestUpdate();
    }
}

// Lista de ejercicios (exercise = true) o de descansos: al elegir, vuelve a la pantalla principal.
class GymPickDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;
    hidden var mExercise;

    function initialize(model, exercise) {
        Menu2InputDelegate.initialize();
        m = model;
        mExercise = exercise;
    }

    (:typecheck(false))
    function onSelect(item) {
        var v = item.getId();
        if (mExercise) {
            m.chooseExercise(v);
        } else {
            m.chooseRest(v);
        }
        WatchUi.popView(WatchUi.SLIDE_RIGHT);
        WatchUi.popView(WatchUi.SLIDE_DOWN);
        WatchUi.requestUpdate();
    }
}
