using Toybox.Graphics;
using Toybox.Lang;
using Toybox.Math;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.Timer;
using Toybox.WatchUi;

// «Montaña F5». Página 0: resumen (la que se ve en la lista de widgets). START abre el detalle:
// 1 presión, 2 altitud, 3 temperatura, 4 sol y luna (ARRIBA/ABAJO para pasar).
// Posiciones: CumbreLayout (revisadas con cumbre_preview.py).
class CumbreView extends WatchUi.View {

    const C_GOLD = 0xFFAA00;
    const C_WHITE = 0xFFFFFF;
    const C_GRAY = 0xAAAAAA;
    const C_DARK = 0x555555;
    const C_BLUE = 0x55AAFF;
    const C_GREEN = 0x55FF55;
    const C_YELLOW = 0xFFFF55;
    const C_RED = 0xFF5555;
    const C_ORANGE = 0xFF5500;
    const N_POINTS = 42;

    var page;
    hidden var fAlt, fMed, fSmall, fXs;
    hidden var mTimer = null;
    hidden var mAt = -1;
    hidden var mErr = false;

    // resumen
    hidden var sAlt = "--", sClimb = "", sPres = "", sPresCol = 0xAAAAAA, sSun = "", sSunCol = 0xFFAA00, sMoon = "";
    // gráficos
    hidden var gTitle = "", gTitleCol = 0xFFAA00, gVal = "--", gVals = null, gLo = 0.0, gHi = 1.0;
    hidden var gLine = 0xFFFFFF, gFill = 0x555555, gL1 = "", gL2 = "", gL2Col = 0xAAAAAA;
    // sol y luna
    hidden var uTitle = "", uRows = null, uLeft = "", uLeftCol = 0xFFAA00, uMoon = "", uNext = "";

    function initialize(p) {
        View.initialize();
        page = p;
    }

    function onLayout(dc) {
        fAlt = WatchUi.loadResource(Rez.Fonts.Alt);
        fMed = WatchUi.loadResource(Rez.Fonts.Med);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
    }

    function onShow() {
        mAt = -1;
        if (mTimer == null) {
            mTimer = new Timer.Timer();
        }
        mTimer.start(method(:onTick), 60000, true);
    }

    function onHide() {
        if (mTimer != null) {
            mTimer.stop();
        }
    }

    function onTick() as Void {
        mAt = -1;
        WatchUi.requestUpdate();
    }

    function setPage(p) {
        page = p;
        mAt = -1;
        WatchUi.requestUpdate();
    }

    // ------------------------------------------------------------ formato

    function hm(m) {
        m = ((m % 1440) + 1440) % 1440;
        return (m / 60).toString() + ":" + (m % 60).format("%02d");
    }

    function dur(m) {
        if (m < 0) {
            m = 0;
        }
        return (m / 60).toString() + ":" + (m % 60).format("%02d");
    }

    function dec1(x, sign) {
        var r = Math.round(CumbreData.absn(x) * 10).toNumber();
        var s = (r / 10).toString() + "," + (r % 10).toString();
        if (sign) {
            return (x < 0 ? "-" : "+") + s;
        }
        return (x < 0 && r > 0) ? "-" + s : s;
    }

    function rnd(x) {
        return Math.round(x).toNumber();
    }

    // [texto, color] según lo que ha cambiado la presión en 3 horas
    function trend(d3) {
        if (d3 == null) {
            return ["", C_BLUE];
        }
        if (d3 <= -4) {
            return ["TORMENTA", C_RED];
        }
        if (d3 <= -2) {
            return ["BAJA " + dec1(-d3, false), C_YELLOW];
        }
        if (d3 <= -0.8) {
            return ["BAJA", C_BLUE];
        }
        if (d3 >= 0.8) {
            return ["SUBE", C_GREEN];
        }
        return ["ESTABLE", C_BLUE];
    }

    // ------------------------------------------------------------ cálculos

    (:typecheck(false))
    function compute() {
        if (page == 0) {
            computeSummary();
        } else if (page == 1) {
            computePressure();
        } else if (page == 2) {
            computeAltitude();
        } else if (page == 3) {
            computeTemperature();
        } else {
            computeSun();
        }
    }

    (:typecheck(false))
    function computeSummary() {
        var e = CumbreData.series(0);
        var p = CumbreData.series(1);
        var alt = CumbreData.last(e);
        sAlt = alt == null ? "--" : rnd(alt).toString();
        if (e == null || e[0].size() < 2) {
            sClimb = "SIN HISTORIAL TODAVÍA";
        } else {
            var c = CumbreData.climb(e);
            sClimb = "+" + c[0] + " M · -" + c[1] + " M EN 4 H";
        }
        var pNow = CumbreData.last(p);
        if (pNow == null) {
            sPres = "SIN DATOS DE PRESIÓN";
            sPresCol = C_GRAY;
        } else {
            var slp = (alt != null && CumbreData.isStation(pNow, alt)) ? CumbreData.seaLevel(pNow, alt) : pNow;
            var d3 = CumbreData.pressureDelta(p, e, 3 * 3600);
            var t = trend(d3);
            if (d3 != null && d3 <= -4) {
                sPres = "¡TORMENTA! " + rnd(d3).toString() + " HPA/3 H";
            } else {
                sPres = rnd(slp).toString() + " HPA" + (t[0].length() > 0 ? " · " + t[0] : "");
            }
            sPresCol = t[1];
        }
        e = null;
        p = null;
        var temp = CumbreData.last(CumbreData.series(2));
        var moon = "LUNA " + CumbreAstro.moonIllum(CumbreAstro.moonPhase(Time.now().value())) + " %";
        sMoon = (temp != null && !CumbreData.onWrist()) ? rnd(temp).toString() + "° AIRE · " + moon : moon;
        // Sol: lo que más importa ahora mismo
        var now = nowMin();
        var s = sunTimes(0);
        sSunCol = C_GOLD;
        if (s == null) {
            sSun = "";
        } else if (now < s[0]) {
            sSun = "AMANECE " + hm(s[1]) + " · EN " + dur(s[1] - now);
            sSunCol = C_BLUE;
        } else if (now < s[1]) {
            sSun = "SALE EL SOL EN " + dur(s[1] - now);
        } else if (now < s[2]) {
            sSun = "PUESTA " + hm(s[2]) + " · EN " + dur(s[2] - now);
            if (s[2] - now < 60) {
                sSunCol = C_ORANGE;
            }
        } else if (now < s[3]) {
            sSun = "ÚLTIMA LUZ EN " + dur(s[3] - now);
            sSunCol = C_ORANGE;
        } else {
            var t2 = sunTimes(1);
            sSun = t2 == null ? "" : "AMANECE " + hm(t2[1]) + " · EN " + dur(t2[1] + 1440 - now);
            sSunCol = C_BLUE;
        }
    }

    (:typecheck(false))
    function setGraph(vals, minRange) {
        if (vals == null || vals.size() < 2) {
            gVals = null;
            return;
        }
        var lo = vals[0];
        var hi = vals[0];
        for (var i = 1; i < vals.size(); i++) {
            if (vals[i] < lo) {
                lo = vals[i];
            }
            if (vals[i] > hi) {
                hi = vals[i];
            }
        }
        if (hi - lo < minRange) {
            var mid = (hi + lo) / 2.0;
            lo = mid - minRange / 2.0;
            hi = mid + minRange / 2.0;
        }
        gLo = lo.toFloat();
        gHi = hi.toFloat();
        gVals = CumbreData.downsample(vals, N_POINTS);
    }

    (:typecheck(false))
    function minMax(vals) {
        var lo = vals[0];
        var hi = vals[0];
        for (var i = 1; i < vals.size(); i++) {
            if (vals[i] < lo) {
                lo = vals[i];
            }
            if (vals[i] > hi) {
                hi = vals[i];
            }
        }
        return [lo, hi];
    }

    function noData(title) {
        gTitle = title;
        gTitleCol = C_GOLD;
        gVal = "--";
        gVals = null;
        gL1 = "EL RELOJ GUARDA 4 H";
        gL2 = "ESPERA UN POCO";
        gL2Col = C_GRAY;
    }

    (:typecheck(false))
    function computePressure() {
        var p = CumbreData.series(1);
        if (p == null) {
            noData("PRESIÓN");
            return;
        }
        var e = CumbreData.series(0);
        var d3 = CumbreData.pressureDelta(p, e, 3 * 3600);
        var slp = CumbreData.seaLevelSeries(p, e);
        e = null;
        p = null;
        var t = trend(d3);
        gTitle = (d3 != null && d3 <= -4) ? "¡TORMENTA!" : "PRESIÓN";
        gTitleCol = (d3 != null && d3 <= -4) ? C_RED : C_GOLD;
        gVal = rnd(slp[slp.size() - 1]).toString() + " HPA";
        var mm = minMax(slp);
        gL1 = "MÍN " + rnd(mm[0]) + " · MÁX " + rnd(mm[1]);
        gL2 = d3 == null ? "SIN DATOS DE 3 H" : dec1(d3, true) + " HPA EN 3 H";
        gL2Col = d3 == null ? C_GRAY : t[1];
        gLine = C_BLUE;
        gFill = 0x0055AA;
        setGraph(slp, 4);
    }

    (:typecheck(false))
    function computeAltitude() {
        var e = CumbreData.series(0);
        if (e == null) {
            noData("ALTITUD");
            return;
        }
        gTitle = "ALTITUD";
        gTitleCol = C_GOLD;
        gVal = rnd(CumbreData.last(e)).toString() + " M";
        var c = CumbreData.climb(e);
        gL1 = "+" + c[0] + " M · -" + c[1] + " M";
        var before = CumbreData.ago(e, 600);
        if (before == null) {
            gL2 = "";
        } else {
            var v = rnd((CumbreData.last(e) - before) * 6 / 10.0) * 10;
            if (v >= 50) {
                gL2 = "SUBES " + v + " M/H";
                gL2Col = C_GREEN;
            } else if (v <= -50) {
                gL2 = "BAJAS " + (-v) + " M/H";
                gL2Col = C_BLUE;
            } else {
                gL2 = "SIN DESNIVEL";
                gL2Col = C_GRAY;
            }
        }
        gLine = C_WHITE;
        gFill = C_DARK;
        setGraph(e[0], 20);
    }

    (:typecheck(false))
    function computeTemperature() {
        var t = CumbreData.series(2);
        if (t == null) {
            noData("TEMPERATURA");
            return;
        }
        gTitle = "TEMPERATURA";
        gTitleCol = C_GOLD;
        gVal = dec1(CumbreData.last(t), false) + "°";
        if (CumbreData.onWrist()) {
            gL1 = "QUÍTATELO 20 MIN";
            gL2 = "MIDE TU MUÑECA";
            gL2Col = C_YELLOW;
        } else {
            var mm = minMax(t[0]);
            gL1 = "MÍN " + rnd(mm[0]) + "° · MÁX " + rnd(mm[1]) + "°";
            gL2 = "MIDE EL AIRE";
            gL2Col = C_GREEN;
        }
        gLine = 0xFFAA55;
        gFill = 0xAA5500;
        setGraph(t[0], 3);
    }

    (:typecheck(false))
    function computeSun() {
        var now = nowMin();
        var s = sunTimes(0);
        var tomorrow = s != null && now >= s[3];
        if (tomorrow) {
            s = sunTimes(1);
        }
        uTitle = tomorrow ? "SOL MAÑANA" : "SOL HOY";
        if (s == null) {
            uRows = null;
            uLeft = "SIN DATOS DE SOL";
            uLeftCol = C_GRAY;
        } else {
            uRows = [["PRIMERA LUZ", hm(s[0])], ["SALIDA", hm(s[1])], ["PUESTA", hm(s[2])], ["ÚLTIMA LUZ", hm(s[3])]];
            uLeftCol = C_GOLD;
            if (tomorrow) {
                uLeft = "AMANECE EN " + dur(s[1] + 1440 - now);
                uLeftCol = C_BLUE;
            } else if (now < s[0]) {
                uLeft = "AMANECE EN " + dur(s[1] - now);
                uLeftCol = C_BLUE;
            } else if (now < s[1]) {
                uLeft = "SALE EL SOL EN " + dur(s[1] - now);
            } else if (now < s[2]) {
                uLeft = "QUEDAN " + dur(s[2] - now) + " DE SOL";
                if (s[2] - now < 60) {
                    uLeftCol = C_ORANGE;
                }
            } else {
                uLeft = "ÚLTIMA LUZ EN " + dur(s[3] - now);
                uLeftCol = C_ORANGE;
            }
        }
        var ph = CumbreAstro.moonPhase(Time.now().value());
        uMoon = "LUNA " + CumbreAstro.moonIllum(ph) + " % · " + (ph < 0.5 ? "CRECIENTE" : "MENGUANTE");
        var toFull = 0.5 - ph;
        if (toFull < 0) {
            toFull += 1.0;
        }
        var toNew = 1.0 - ph;
        var full = toFull <= toNew;
        var n = rnd((full ? toFull : toNew) * 29.530588853);
        uNext = (full ? "LLENA" : "NUEVA") + (n == 0 ? " HOY" : (n == 1 ? " MAÑANA" : " EN " + n + " DÍAS"));
    }

    function nowMin() {
        var c = System.getClockTime();
        return c.hour * 60 + c.min;
    }

    // [primera luz, salida, puesta, última luz] en minutos locales, o null (sol de medianoche, noche polar).
    (:typecheck(false))
    function sunTimes(plusDays) {
        var loc = CumbreData.location();
        var g = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        var doy = CumbreAstro.dayOfYear(g.year, g.month, g.day) + plusDays;
        var off = CumbreData.offsetMinutes();
        var r = [
            CumbreAstro.sunEvent(loc[0], loc[1], doy, true, off, 96.0),
            CumbreAstro.sunEvent(loc[0], loc[1], doy, true, off, 90.833),
            CumbreAstro.sunEvent(loc[0], loc[1], doy, false, off, 90.833),
            CumbreAstro.sunEvent(loc[0], loc[1], doy, false, off, 96.0)
        ];
        for (var i = 0; i < 4; i++) {
            if (r[i] == null) {
                return null;
            }
        }
        return r;
    }

    // ------------------------------------------------------------ dibujo

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    function onUpdate(dc) {
        var t = System.getTimer();
        if (mAt < 0 || t - mAt > 55000) {
            try {
                compute();
                mErr = false;
            } catch (ex) {
                mErr = true;
            }
            mAt = t;
        }
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        if (mErr) {
            text(dc, 120, 100, fSmall, "NO PUEDO LEER", C_GRAY, c);
            text(dc, 120, 122, fSmall, "LOS SENSORES", C_GRAY, c);
            return;
        }
        if (page == 0) {
            drawSummary(dc);
        } else if (page <= 3) {
            drawGraphPage(dc);
        } else {
            drawSun(dc);
        }
        if (page > 0) {
            drawDots(dc);
        }
    }

    function drawSummary(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        var l = Graphics.TEXT_JUSTIFY_LEFT;
        text(dc, 120, CumbreLayout.ALT_LBL_Y, fXs, "ALTITUD", C_GRAY, c);
        var wa = dc.getTextWidthInPixels(sAlt, fAlt);
        var wm = dc.getTextWidthInPixels("M", fMed);
        var left = 120 - (wa + CumbreLayout.ALT_M_GAP + wm) / 2;
        text(dc, left, CumbreLayout.ALT_Y, fAlt, sAlt, C_WHITE, l);
        text(dc, left + wa + CumbreLayout.ALT_M_GAP, CumbreLayout.ALT_Y + CumbreLayout.ALT_M_DY, fMed, "M", C_WHITE, l);
        text(dc, 120, CumbreLayout.CLIMB_Y, fXs, sClimb, C_GRAY, c);
        text(dc, 120, CumbreLayout.PRES_Y, fSmall, sPres, sPresCol, c);
        text(dc, 120, CumbreLayout.SUN_Y, fXs, sSun, sSunCol, c);
        text(dc, 120, CumbreLayout.MOON_Y, fXs, sMoon, C_WHITE, c);
        text(dc, 120, CumbreLayout.HINT_Y, fXs, "START: MÁS", C_GRAY, c);
    }

    (:typecheck(false))
    function drawGraphPage(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        text(dc, 120, CumbreLayout.G_TITLE_Y, fXs, gTitle, gTitleCol, c);
        text(dc, 120, CumbreLayout.G_VAL_Y, fMed, gVal, C_WHITE, c);
        if (gVals != null && gVals.size() >= 2) {
            var x0 = CumbreLayout.G_X0;
            var x1 = CumbreLayout.G_X1;
            var top = CumbreLayout.G_TOP;
            var bot = CumbreLayout.G_BOT;
            var n = gVals.size();
            var pts = new [n + 2];
            for (var i = 0; i < n; i++) {
                var y = bot - ((gVals[i] - gLo) * (bot - top) / (gHi - gLo)).toNumber();
                pts[i] = [x0 + i * (x1 - x0) / (n - 1), y];
            }
            pts[n] = [x1, bot];
            pts[n + 1] = [x0, bot];
            dc.setColor(gFill, Graphics.COLOR_TRANSPARENT);
            dc.fillPolygon(pts);
            dc.setColor(gLine, Graphics.COLOR_TRANSPARENT);
            dc.setPenWidth(2);
            for (var i = 1; i < n; i++) {
                dc.drawLine(pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1]);
            }
            dc.setPenWidth(1);
            dc.fillCircle(pts[n - 1][0], pts[n - 1][1], 3);
            dc.setColor(C_DARK, Graphics.COLOR_TRANSPARENT);
            dc.drawLine(x0, bot, x1, bot);
            text(dc, x0, CumbreLayout.G_AXIS_Y, fXs, "-4 H", C_GRAY, Graphics.TEXT_JUSTIFY_LEFT);
            text(dc, x1, CumbreLayout.G_AXIS_Y, fXs, "AHORA", C_GRAY, Graphics.TEXT_JUSTIFY_RIGHT);
        } else {
            text(dc, 120, (CumbreLayout.G_TOP + CumbreLayout.G_BOT) / 2 - 8, fXs, "SIN DATOS TODAVÍA", C_GRAY, c);
        }
        text(dc, 120, CumbreLayout.G_L1_Y, fXs, gL1, C_WHITE, c);
        text(dc, 120, CumbreLayout.G_L2_Y, fSmall, gL2, gL2Col, c);
    }

    (:typecheck(false))
    function drawSun(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        text(dc, 120, CumbreLayout.S_TITLE_Y, fXs, uTitle, C_GOLD, c);
        if (uRows != null) {
            for (var i = 0; i < uRows.size(); i++) {
                var y = CumbreLayout.S_ROW_Y + i * CumbreLayout.S_ROW_DY;
                text(dc, CumbreLayout.S_LX, y, fXs, uRows[i][0], C_GRAY, Graphics.TEXT_JUSTIFY_LEFT);
                text(dc, CumbreLayout.S_RX, y, fXs, uRows[i][1], C_WHITE, Graphics.TEXT_JUSTIFY_RIGHT);
            }
        }
        text(dc, 120, CumbreLayout.S_LEFT_Y, fSmall, uLeft, uLeftCol, c);
        text(dc, 120, CumbreLayout.S_MOON_Y, fXs, uMoon, C_WHITE, c);
        text(dc, 120, CumbreLayout.S_NEXT_Y, fXs, uNext, C_GRAY, c);
    }

    function drawDots(dc) {
        for (var i = 0; i < 5; i++) {
            var x = 120 + (i - 2) * CumbreLayout.DOTS_DX;
            dc.setColor(i == page ? C_WHITE : C_DARK, Graphics.COLOR_TRANSPARENT);
            dc.fillCircle(x, CumbreLayout.DOTS_Y, i == page ? 3 : 2);
        }
    }
}
