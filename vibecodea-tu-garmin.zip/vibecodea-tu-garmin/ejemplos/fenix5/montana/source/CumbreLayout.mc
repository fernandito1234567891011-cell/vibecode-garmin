// GENERADO por cumbre_preview.py: no editar a mano.
module CumbreLayout {
    const ALT_LBL_Y = 22;
    const ALT_Y = 34;
    const ALT_M_DY = 33;
    const ALT_M_GAP = 4;
    const CLIMB_Y = 94;
    const PRES_Y = 114;
    const SUN_Y = 136;
    const MOON_Y = 156;
    const HINT_Y = 184;
    const G_TITLE_Y = 28;
    const G_VAL_Y = 44;
    const G_X0 = 38;
    const G_X1 = 202;
    const G_TOP = 72;
    const G_BOT = 124;
    const G_AXIS_Y = 127;
    const G_L1_Y = 147;
    const G_L2_Y = 167;
    const S_TITLE_Y = 28;
    const S_ROW_Y = 46;
    const S_ROW_DY = 18;
    const S_LX = 46;
    const S_RX = 194;
    const S_LEFT_Y = 122;
    const S_MOON_Y = 144;
    const S_NEXT_Y = 163;
    const DOTS_Y = 205;
    const DOTS_DX = 10;
}
