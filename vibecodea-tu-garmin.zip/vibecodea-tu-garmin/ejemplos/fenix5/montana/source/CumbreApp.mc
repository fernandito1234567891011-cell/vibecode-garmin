using Toybox.Application;
using Toybox.WatchUi;

// «Montaña F5»: altitud, presión sin el efecto de subir, aviso de tormenta, temperatura, sol y luna.
class CumbreApp extends Application.AppBase {

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        return [new CumbreView(0), new CumbreLoopDelegate()];
    }
}

// En la lista de widgets: START abre el detalle; ARRIBA/ABAJO siguen pasando widgets.
class CumbreLoopDelegate extends WatchUi.BehaviorDelegate {

    function initialize() {
        BehaviorDelegate.initialize();
    }

    function onSelect() {
        var v = new CumbreView(1);
        WatchUi.pushView(v, new CumbreDetailDelegate(v), WatchUi.SLIDE_LEFT);
        return true;
    }
}

// Detalle: ARRIBA/ABAJO o START cambian de página; ATRÁS vuelve a la lista.
class CumbreDetailDelegate extends WatchUi.BehaviorDelegate {

    hidden var mView;

    function initialize(v) {
        BehaviorDelegate.initialize();
        mView = v;
    }

    function onNextPage() {
        mView.setPage((mView.page + 1) % 5);
        return true;
    }

    function onPreviousPage() {
        mView.setPage((mView.page + 4) % 5);
        return true;
    }

    function onSelect() {
        return onNextPage();
    }

    function onBack() {
        WatchUi.popView(WatchUi.SLIDE_RIGHT);
        return true;
    }
}
