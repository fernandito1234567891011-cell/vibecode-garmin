using Toybox.Lang;
using Toybox.Math;

// Sol (salida, puesta y fin del crepúsculo) y luna, calculados en el reloj.
module CumbreAstro {

    function sinD(a) { return Math.sin(Math.toRadians(a)); }
    function cosD(a) { return Math.cos(Math.toRadians(a)); }
    function norm(a, m) { return a - Math.floor(a / m) * m; }

    // Minutos locales. zenith 90.833 = salida/puesta; 96 = fin/inicio del crepúsculo civil.
    function sunEvent(lat, lon, dayOfYear, rising, offsetMin, zenith) {
        var lngHour = lon / 15.0;
        var t = dayOfYear + ((rising ? 6.0 : 18.0) - lngHour) / 24.0;
        var m = 0.9856 * t - 3.289;
        var l = norm(m + 1.916 * sinD(m) + 0.020 * sinD(2 * m) + 282.634, 360.0);
        var ra = norm(Math.toDegrees(Math.atan(0.91764 * Math.tan(Math.toRadians(l)))), 360.0);
        ra = (ra + (Math.floor(l / 90.0) * 90.0 - Math.floor(ra / 90.0) * 90.0)) / 15.0;
        var sinDec = 0.39782 * sinD(l);
        var cosDec = Math.cos(Math.asin(sinDec));
        var cosH = (cosD(zenith) - sinDec * sinD(lat)) / (cosDec * cosD(lat));
        if (cosH > 1 || cosH < -1) {
            return null;
        }
        var h = Math.toDegrees(Math.acos(cosH));
        if (rising) {
            h = 360 - h;
        }
        var tt = h / 15.0 + ra - 0.06571 * t - 6.622;
        var ut = norm(tt - lngHour, 24.0);
        var mins = Math.round(ut * 60 + offsetMin).toNumber();
        return ((mins % 1440) + 1440) % 1440;
    }

    function dayOfYear(year, month, day) {
        var cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        var n = cum[month - 1] + day;
        if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && month > 2) {
            n += 1;
        }
        return n;
    }

    function moonPhase(nowSecs) {
        var syn = 29.530588853;
        var days = (nowSecs - 947182440) / 86400.0;
        return (days - Math.floor(days / syn) * syn) / syn;
    }

    function moonIllum(phase) {
        return Math.round((1 - Math.cos(2 * Math.PI * phase)) * 50).toNumber();
    }
}
