using Toybox.Activity;
using Toybox.Application;
using Toybox.Lang;
using Toybox.Math;
using Toybox.Position;
using Toybox.SensorHistory;
using Toybox.System;
using Toybox.Time;

// Lecturas del barómetro, el altímetro y el termómetro (las últimas 4 horas que guarda el reloj)
// y cálculos de montaña: desnivel, velocidad vertical y tendencia de la presión sin el efecto de subir o bajar.
module CumbreData {

    function absn(x) {
        return x < 0 ? -x : x;
    }

    // [valores, tiempos] del más antiguo al más reciente, o null. kind: 0 altitud, 1 presión (hPa), 2 temperatura.
    (:typecheck(false))
    function series(kind) {
        if (!(Toybox has :SensorHistory)) {
            return null;
        }
        var it = null;
        var opts = {:period => new Time.Duration(4 * 3600), :order => SensorHistory.ORDER_OLDEST_FIRST};
        if (kind == 0 && (SensorHistory has :getElevationHistory)) {
            it = SensorHistory.getElevationHistory(opts);
        } else if (kind == 1 && (SensorHistory has :getPressureHistory)) {
            it = SensorHistory.getPressureHistory(opts);
        } else if (kind == 2 && (SensorHistory has :getTemperatureHistory)) {
            it = SensorHistory.getTemperatureHistory(opts);
        }
        if (it == null) {
            return null;
        }
        var v = [];
        var t = [];
        var s = it.next();
        while (s != null) {
            if (s.data != null && s.when != null) {
                v.add(kind == 1 ? s.data / 100.0 : s.data.toFloat());
                t.add(s.when.value());
            }
            s = it.next();
        }
        if (v.size() == 0) {
            return null;
        }
        return [v, t];
    }

    (:typecheck(false))
    function last(ser) {
        if (ser == null) {
            return null;
        }
        return ser[0][ser[0].size() - 1];
    }

    // Valor de hace «secs» segundos (la muestra más cercana), o null si el historial no llega tan atrás.
    (:typecheck(false))
    function ago(ser, secs) {
        if (ser == null) {
            return null;
        }
        var v = ser[0];
        var t = ser[1];
        var target = t[t.size() - 1] - secs;
        if (t[0] > target + 300) {
            return null;
        }
        var best = 0;
        for (var i = 1; i < t.size(); i++) {
            if (absn(t[i] - target) < absn(t[best] - target)) {
                best = i;
            }
        }
        return v[best];
    }

    // Presión al nivel del mar a partir de la de la estación y la altitud (atmósfera estándar).
    function seaLevel(hpa, alt) {
        if (alt == null || alt < -500 || alt > 9000) {
            return hpa;
        }
        return hpa * Math.pow(1 - 0.0000225577 * alt, -5.25588);
    }

    // El historial puede venir en presión de la estación o ya corregida al nivel del mar:
    // se mira a cuál de las dos se parece más el dato actual.
    function isStation(hpa, alt) {
        if (alt == null || alt < -500 || alt > 9000) {
            return false;
        }
        var std = 1013.25 * Math.pow(1 - 0.0000225577 * alt, 5.25588);
        return absn(hpa - std) < absn(hpa - 1013.25);
    }

    // Presión al nivel del mar de cada muestra, usando la altitud del mismo momento.
    // Así, subir un puerto no parece una tormenta: solo cuenta lo que cambia el tiempo.
    (:typecheck(false))
    function seaLevelSeries(p, e) {
        if (p == null) {
            return null;
        }
        var pv = p[0];
        var pt = p[1];
        if (e == null || !isStation(pv[pv.size() - 1], last(e))) {
            return pv;
        }
        var ev = e[0];
        var et = e[1];
        var out = new [pv.size()];
        var j = 0;
        for (var i = 0; i < pv.size(); i++) {
            while (j + 1 < et.size() && absn(et[j + 1] - pt[i]) <= absn(et[j] - pt[i])) {
                j++;
            }
            out[i] = seaLevel(pv[i], ev[j]);
        }
        return out;
    }

    // Cambio de presión (nivel del mar) en las últimas «secs», o null.
    (:typecheck(false))
    function pressureDelta(p, e, secs) {
        var now = last(p);
        var then = ago(p, secs);
        if (now == null || then == null) {
            return null;
        }
        var hNow = last(e);
        if (hNow != null && isStation(now, hNow)) {
            var hThen = ago(e, secs);
            if (hThen == null) {
                hThen = hNow;
            }
            return seaLevel(now, hNow) - seaLevel(then, hThen);
        }
        return now - then;
    }

    // [subido, bajado] en metros, con 3 m de margen para no sumar ruido.
    (:typecheck(false))
    function climb(ser) {
        if (ser == null) {
            return [0, 0];
        }
        var v = ser[0];
        var up = 0.0;
        var down = 0.0;
        var ref = v[0];
        for (var i = 1; i < v.size(); i++) {
            var d = v[i] - ref;
            if (d >= 3) {
                up += d;
                ref = v[i];
            } else if (d <= -3) {
                down -= d;
                ref = v[i];
            }
        }
        return [up.toNumber(), down.toNumber()];
    }

    // n puntos promediando tramos iguales, para dibujar el gráfico.
    (:typecheck(false))
    function downsample(vals, n) {
        if (vals == null) {
            return null;
        }
        var size = vals.size();
        if (size <= n) {
            return vals;
        }
        var out = new [n];
        for (var k = 0; k < n; k++) {
            var i0 = k * size / n;
            var i1 = (k + 1) * size / n;
            var sum = 0.0;
            for (var i = i0; i < i1; i++) {
                sum += vals[i];
            }
            out[k] = sum / (i1 - i0);
        }
        return out;
    }

    // ¿Lleva el reloj puesto? Si no hay pulso, el termómetro mide el aire.
    (:typecheck(false))
    function onWrist() {
        var ai = Activity.getActivityInfo();
        return ai != null && ai.currentHeartRate != null && ai.currentHeartRate > 0;
    }

    (:typecheck(false))
    function goodLoc(d) {
        return d != null && d[0] < 90 && d[0] > -90 && d[1] <= 180 && d[1] >= -180
            && !(d[0] > -0.01 && d[0] < 0.01 && d[1] > -0.01 && d[1] < 0.01);
    }

    // Última posición conocida (de una actividad con GPS); si no hay, la guardada; si no, Madrid.
    (:typecheck(false))
    function location() {
        var d = null;
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.currentLocation != null) {
            d = ai.currentLocation.toDegrees();
        }
        if (!goodLoc(d) && (Toybox has :Position)) {
            var pi = Position.getInfo();
            if (pi != null && pi.position != null && pi.accuracy != Position.QUALITY_NOT_AVAILABLE) {
                d = pi.position.toDegrees();
            }
        }
        if (goodLoc(d)) {
            var loc = [d[0].toFloat(), d[1].toFloat()];
            var old = Application.Storage.getValue("loc");
            if (!(old instanceof Lang.Array) || absn(old[0] - loc[0]) > 0.01 || absn(old[1] - loc[1]) > 0.01) {
                Application.Storage.setValue("loc", loc);
            }
            return loc;
        }
        var saved = Application.Storage.getValue("loc");
        if (saved instanceof Lang.Array && saved.size() == 2) {
            return saved;
        }
        return [40.4168, -3.7038];
    }

    function offsetMinutes() {
        return System.getClockTime().timeZoneOffset / 60;
    }
}
