using Toybox.Graphics;
using Toybox.WatchUi;

class VfcView extends WatchUi.View {

    hidden var mM;
    var showHistory = false;

    function initialize(measure) {
        View.initialize();
        mM = measure;
    }

    function onUpdate(dc) {
        var w = dc.getWidth();
        var h = dc.getHeight();
        var cx = w / 2;
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        if (showHistory) {
            drawHistory(dc, cx, h);
        } else if (mM.state == 0) {
            drawReady(dc, cx, h);
        } else if (mM.state == 1) {
            drawMeasuring(dc, cx, h);
        } else {
            drawResult(dc, cx, h);
        }
    }

    function text(dc, x, y, font, s, color) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, Graphics.TEXT_JUSTIFY_CENTER);
    }

    function drawReady(dc, cx, h) {
        text(dc, cx, h * 0.18, Graphics.FONT_SMALL, "VFC DE LA MAÑANA", Graphics.COLOR_WHITE);
        text(dc, cx, h * 0.36, Graphics.FONT_XTINY, "Nada más despertar,", Graphics.COLOR_LT_GRAY);
        text(dc, cx, h * 0.45, Graphics.FONT_XTINY, "tumbado y quieto.", Graphics.COLOR_LT_GRAY);
        text(dc, cx, h * 0.54, Graphics.FONT_XTINY, "Reloj ajustado.", Graphics.COLOR_LT_GRAY);
        text(dc, cx, h * 0.70, Graphics.FONT_TINY, "START: medir 2 min", Graphics.COLOR_GREEN);
        text(dc, cx, h * 0.82, Graphics.FONT_XTINY, "ABAJO: historial", Graphics.COLOR_DK_GRAY);
    }

    function drawMeasuring(dc, cx, h) {
        var s = mM.secsLeft;
        text(dc, cx, h * 0.18, Graphics.FONT_TINY, "RESPIRA NORMAL", Graphics.COLOR_LT_GRAY);
        text(dc, cx, h * 0.32, Graphics.FONT_NUMBER_MEDIUM,
            (s / 60).toString() + ":" + (s % 60).format("%02d"), Graphics.COLOR_WHITE);
        var hrTxt = mM.hr == null ? "--" : mM.hr.toString();
        text(dc, cx, h * 0.62, Graphics.FONT_SMALL, "PULSO " + hrTxt, Graphics.COLOR_RED);
        text(dc, cx, h * 0.76, Graphics.FONT_XTINY, mM.rr.size().toString() + " latidos", Graphics.COLOR_LT_GRAY);
    }

    function drawResult(dc, cx, h) {
        var r = mM.result;
        if (r == null) {
            text(dc, cx, h * 0.35, Graphics.FONT_SMALL, "POCOS LATIDOS", Graphics.COLOR_RED);
            text(dc, cx, h * 0.50, Graphics.FONT_XTINY, "Aprieta la correa", Graphics.COLOR_LT_GRAY);
            text(dc, cx, h * 0.59, Graphics.FONT_XTINY, "y repite (START)", Graphics.COLOR_LT_GRAY);
            return;
        }
        var v = VfcCalc.verdict(r);
        var color = v[1] == 2 ? Graphics.COLOR_RED : (v[1] == 1 ? Graphics.COLOR_GREEN : Graphics.COLOR_LT_GRAY);
        text(dc, cx, h * 0.14, Graphics.FONT_XTINY, "VFC (rMSSD)", Graphics.COLOR_LT_GRAY);
        text(dc, cx, h * 0.22, Graphics.FONT_NUMBER_MEDIUM, r["rmssd"].toString(), Graphics.COLOR_WHITE);
        text(dc, cx, h * 0.47, Graphics.FONT_XTINY, "ms   puntos " + r["score"], Graphics.COLOR_LT_GRAY);
        text(dc, cx, h * 0.58, Graphics.FONT_TINY, v[0], color);
        text(dc, cx, h * 0.70, Graphics.FONT_XTINY, "pulso " + r["hr"] + "  latidos " + r["n"], Graphics.COLOR_DK_GRAY);
        text(dc, cx, h * 0.78, Graphics.FONT_XTINY, "planos " + r["synth"] + "%  fuera " + r["rej"], Graphics.COLOR_DK_GRAY);
    }

    function drawHistory(dc, cx, h) {
        var hist = VfcCalc.history();
        text(dc, cx, h * 0.10, Graphics.FONT_TINY, "ÚLTIMAS MEDIDAS", Graphics.COLOR_WHITE);
        if (hist.size() == 0) {
            text(dc, cx, h * 0.45, Graphics.FONT_XTINY, "Aún no hay ninguna", Graphics.COLOR_LT_GRAY);
            return;
        }
        var y = h * 0.24;
        for (var i = hist.size() - 1; i >= 0 && i >= hist.size() - 7; i--) {
            var e = hist[i];
            var k = e["k"];
            var day = (k % 100).format("%02d") + "/" + ((k / 100) % 100).format("%02d");
            var color = e["synth"] >= 50 ? Graphics.COLOR_DK_GRAY : Graphics.COLOR_WHITE;
            text(dc, cx, y, Graphics.FONT_XTINY, day + "   " + e["rmssd"] + " ms   " + e["hr"] + " lpm", color);
            y += h * 0.09;
        }
    }
}
