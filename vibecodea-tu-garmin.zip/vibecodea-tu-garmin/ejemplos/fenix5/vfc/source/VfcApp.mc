using Toybox.Application;
using Toybox.WatchUi;

// «VFC de la mañana»: medida de 2 minutos de la variabilidad del pulso (VFC/HRV) con el
// sensor de la muñeca, al despertar. Es lo que en los relojes nuevos se llama «HRV Status».
// La primera semana sirve también de prueba: comprueba si el fenix 5 da latidos reales
// o intervalos calculados a partir del pulso (ver VfcCalc.synthPct).
class VfcApp extends Application.AppBase {

    hidden var mMeasure;

    function initialize() {
        AppBase.initialize();
        mMeasure = new VfcMeasure();
    }

    function onStop(state) {
        mMeasure.stop();
    }

    function getInitialView() {
        var view = new VfcView(mMeasure);
        return [view, new VfcDelegate(view, mMeasure)];
    }
}
