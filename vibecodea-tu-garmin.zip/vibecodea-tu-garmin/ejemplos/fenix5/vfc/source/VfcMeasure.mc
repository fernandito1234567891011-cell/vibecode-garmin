using Toybox.Sensor;
using Toybox.Timer;
using Toybox.WatchUi;

// Medida de 2 minutos: recoge los intervalos entre latidos que da el sensor de la muñeca.
class VfcMeasure {

    const DURATION = 120;
    const MAX_RR = 400;

    var state = 0;      // 0 = listo, 1 = midiendo, 2 = resultado
    var secsLeft = 120;
    var hr = null;
    var rr = [];
    var result = null;
    hidden var mTimer = null;

    function initialize() {
    }

    (:typecheck(false))
    function start() {
        rr = [];
        result = null;
        hr = null;
        secsLeft = DURATION;
        state = 1;
        Sensor.setEnabledSensors([Sensor.SENSOR_HEARTRATE]);
        Sensor.registerSensorDataListener(method(:onData), {
            :period => 1,
            :heartBeatIntervals => {:enabled => true}
        });
        mTimer = new Timer.Timer();
        mTimer.start(method(:onTick), 1000, true);
    }

    function stop() {
        if (mTimer != null) {
            mTimer.stop();
            mTimer = null;
        }
        Sensor.unregisterSensorDataListener();
        if (state == 1) {
            state = 0;
        }
    }

    function onData(data) {
        if (data == null || !(data has :heartRateData) || data.heartRateData == null) {
            return;
        }
        var ivs = data.heartRateData.heartBeatIntervals;
        if (ivs == null) {
            return;
        }
        for (var i = 0; i < ivs.size() && rr.size() < MAX_RR; i++) {
            rr.add(ivs[i]);
        }
    }

    function onTick() {
        var info = Sensor.getInfo();
        if (info != null && info.heartRate != null) {
            hr = info.heartRate;
        }
        secsLeft -= 1;
        if (secsLeft <= 0) {
            finish();
        }
        WatchUi.requestUpdate();
    }

    function finish() {
        if (mTimer != null) {
            mTimer.stop();
            mTimer = null;
        }
        Sensor.unregisterSensorDataListener();
        result = VfcCalc.analyse(rr);
        if (result != null) {
            VfcCalc.save(result);
        }
        state = 2;
    }
}
