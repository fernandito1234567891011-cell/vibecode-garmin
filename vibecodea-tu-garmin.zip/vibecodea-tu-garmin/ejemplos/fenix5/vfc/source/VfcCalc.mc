using Toybox.Application;
using Toybox.Math;
using Toybox.Time;
using Toybox.Time.Gregorian;

// Cálculo de la VFC (rMSSD) y comparación con su propia base de 7 días.
module VfcCalc {

    const KEEP = 30;

    function dayKey() {
        var i = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        return i.year * 10000 + i.month * 100 + i.day;
    }

    // rr: intervalos en milisegundos. Devuelve un diccionario o null si hay pocos latidos.
    (:typecheck(false))
    function analyse(rr) {
        var clean = [];
        var rejected = 0;
        var last = null;
        for (var i = 0; i < rr.size(); i++) {
            var x = rr[i];
            if (x < 300 || x > 2000) {
                rejected++;
                continue;
            }
            // Fuera los saltos de más del 25 % respecto al último latido bueno (artefactos).
            var jump = last == null ? 0 : x - last;
            if (jump < 0) {
                jump = -jump;
            }
            if (last != null && jump > last / 4) {
                rejected++;
                continue;
            }
            clean.add(x);
            last = x;
        }
        var n = clean.size();
        if (n < 30) {
            return null;
        }
        var sumSq = 0.0;
        var sum = 0.0;
        var flat = 0;
        for (var i = 0; i < n; i++) {
            sum += clean[i];
            if (i > 0) {
                var d = clean[i] - clean[i - 1];
                sumSq += d * d;
                if (d >= -3 && d <= 3) {
                    flat++;
                }
            }
        }
        var rmssd = Math.sqrt(sumSq / (n - 1));
        var score = rmssd > 1 ? Math.ln(rmssd) * 20 : 0;
        return {
            "k" => dayKey(),
            "rmssd" => Math.round(rmssd).toNumber(),
            "score" => Math.round(score).toNumber(),
            "hr" => Math.round(60000.0 / (sum / n)).toNumber(),
            "n" => n,
            "rej" => rejected,
            // % de latidos seguidos casi idénticos. Con latidos reales en reposo suele ser bajo;
            // si pasa del 50 %, el reloj está dando intervalos calculados y la VFC no vale.
            "synth" => (flat * 100) / (n - 1)
        };
    }

    function history() {
        var h = Application.Storage.getValue("vfc");
        return h == null ? [] : h;
    }

    function save(r) {
        var h = history();
        var out = [];
        for (var i = 0; i < h.size(); i++) {
            if (h[i]["k"] != r["k"]) {
                out.add(h[i]);
            }
        }
        out.add(r);
        if (out.size() > KEEP) {
            out = out.slice(out.size() - KEEP, null);
        }
        Application.Storage.setValue("vfc", out);
    }

    // [media, desviación, n] de las últimas 7 medidas válidas anteriores a hoy.
    function baseline() {
        var h = history();
        var today = dayKey();
        var vals = [];
        for (var i = h.size() - 1; i >= 0 && vals.size() < 7; i--) {
            if (h[i]["k"] != today && h[i]["synth"] < 50) {
                vals.add(h[i]["score"]);
            }
        }
        var n = vals.size();
        if (n == 0) {
            return [0, 0, 0];
        }
        var sum = 0.0;
        for (var i = 0; i < n; i++) {
            sum += vals[i];
        }
        var mean = sum / n;
        var sq = 0.0;
        for (var i = 0; i < n; i++) {
            sq += (vals[i] - mean) * (vals[i] - mean);
        }
        var sd = n > 1 ? Math.sqrt(sq / (n - 1)) : 0;
        return [mean, sd, n];
    }

    // Texto y color del resultado de hoy frente a su base.
    function verdict(r) {
        if (r["synth"] >= 50) {
            return ["SENSOR NO VALE PARA VFC", 2];
        }
        var b = baseline();
        if (b[2] < 3) {
            return ["CREANDO TU BASE " + b[2] + "/3", 0];
        }
        var sd = b[1] < 2 ? 2 : b[1];
        var z = (r["score"] - b[0]) / sd;
        if (z < -1) {
            return ["BAJA: HOY SUAVE", 2];
        } else if (z > 1) {
            return ["ALTA: BIEN RECUPERADO", 1];
        }
        return ["NORMAL", 1];
    }
}
