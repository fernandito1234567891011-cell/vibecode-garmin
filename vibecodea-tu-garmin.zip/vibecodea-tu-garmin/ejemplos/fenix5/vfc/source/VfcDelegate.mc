using Toybox.WatchUi;

class VfcDelegate extends WatchUi.BehaviorDelegate {

    hidden var mView;
    hidden var mM;

    function initialize(view, measure) {
        BehaviorDelegate.initialize();
        mView = view;
        mM = measure;
    }

    // START: empezar (o repetir) la medida.
    function onSelect() {
        if (mView.showHistory) {
            mView.showHistory = false;
        } else if (mM.state != 1) {
            mM.start();
        }
        WatchUi.requestUpdate();
        return true;
    }

    // ABAJO: historial.
    function onNextPage() {
        if (mM.state != 1) {
            mView.showHistory = !mView.showHistory;
            WatchUi.requestUpdate();
        }
        return true;
    }

    // ATRÁS: si está midiendo, cancela; si no, sale.
    function onBack() {
        if (mM.state == 1) {
            mM.stop();
            WatchUi.requestUpdate();
            return true;
        }
        if (mView.showHistory) {
            mView.showHistory = false;
            WatchUi.requestUpdate();
            return true;
        }
        return false;
    }
}
