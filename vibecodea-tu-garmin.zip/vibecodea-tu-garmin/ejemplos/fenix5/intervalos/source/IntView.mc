using Toybox.Graphics;
using Toybox.WatchUi;

// Pantalla de «Intervalos F5». Posiciones: IntLayout (revisadas con intervalos_preview.py).
class IntView extends WatchUi.View {

    const C_GOLD = 0xFFAA00;
    const C_WHITE = 0xFFFFFF;
    const C_GRAY = 0xAAAAAA;
    const C_DARK = 0x555555;
    const C_GREEN = 0x55FF55;
    const C_BLUE = 0x55AAFF;
    const C_YELLOW = 0xFFFF55;

    hidden var m;
    hidden var fTime, fSmall, fXs, iHeart;

    function initialize(model) {
        View.initialize();
        m = model;
    }

    function onLayout(dc) {
        fTime = WatchUi.loadResource(Rez.Fonts.Time);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
        iHeart = WatchUi.loadResource(Rez.Drawables.Heart);
    }

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    // 0:20, 3:00, 1:02:30
    function clock(secs) {
        var h = secs / 3600;
        var mm = (secs % 3600) / 60;
        var ss = secs % 60;
        if (h > 0) {
            return h.toString() + ":" + mm.format("%02d") + ":" + ss.format("%02d");
        }
        return mm.toString() + ":" + ss.format("%02d");
    }

    // 20 S, 3:00
    function span(secs) {
        return secs < 60 ? secs.toString() + " S" : clock(secs);
    }

    function thousands(n) {
        var s = n.toString();
        if (n >= 1000) {
            s = (n / 1000).toString() + "." + (n % 1000).format("%03d");
        }
        return s;
    }

    function onUpdate(dc) {
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        if (m.state == IntModel.ST_READY) {
            drawReady(dc);
        } else if (m.state == IntModel.ST_DONE) {
            drawDone(dc);
        } else {
            drawRun(dc);
        }
    }

    function drawReady(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        text(dc, 120, IntLayout.R_TITLE_Y, fXs, "INTERVALOS", C_GOLD, c);
        text(dc, 120, IntLayout.R_MODE_Y, fSmall, m.NAMES[m.mode], C_WHITE, c);
        var desc;
        if (m.rest() == 0) {
            desc = m.rounds().toString() + " RONDAS DE " + span(m.work());
        } else {
            desc = m.rounds().toString() + " RONDAS · " + span(m.work()) + " / " + span(m.rest());
        }
        text(dc, 120, IntLayout.R_DESC_Y, fXs, desc, C_WHITE, c);
        text(dc, 120, IntLayout.R_TOTAL_Y, fXs, clock(m.totalPlanned()) + " EN TOTAL", C_GRAY, c);
        text(dc, 120, IntLayout.R_HINT1_Y, fXs, "ARRIBA/ABAJO: MODO", C_GRAY, c);
        text(dc, 120, IntLayout.R_START_Y, fSmall, "START: EMPEZAR", C_GREEN, c);
        text(dc, 120, IntLayout.R_HINT2_Y, fXs, "ATRÁS: AJUSTES", C_GRAY, c);
        var n = m.NAMES.size();
        for (var i = 0; i < n; i++) {
            var x = 120 + ((2 * i - (n - 1)) * IntLayout.DOTS_DX) / 2;
            dc.setColor(i == m.mode ? C_WHITE : C_DARK, Graphics.COLOR_TRANSPARENT);
            dc.fillCircle(x, IntLayout.DOTS_Y, i == m.mode ? 3 : 2);
        }
    }

    function drawDone(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        text(dc, 120, IntLayout.D_TITLE_Y, fSmall, m.finishedAll ? "¡HECHO!" : "TERMINADO",
            m.finishedAll ? C_GREEN : C_WHITE, c);
        text(dc, 120, IntLayout.D_ROUNDS_Y, fSmall, m.done.toString() + " DE " + m.rounds().toString() + " RONDAS", C_WHITE, c);
        text(dc, 120, IntLayout.D_TIME_Y, fXs, clock(m.totalSecs) + " EN TOTAL", C_GRAY, c);
        if (m.mode == m.MODE_COMBA) {
            text(dc, 120, IntLayout.D_EXTRA_Y, fXs, thousands(m.jumps) + " SALTOS", C_WHITE, c);
        }
        text(dc, 120, IntLayout.D_SAVED_Y, fSmall, m.saved ? "GUARDADO" : "DESCARTADO", m.saved ? C_GREEN : C_GRAY, c);
        text(dc, 120, IntLayout.D_HINT_Y, fXs, "ATRÁS: SALIR", C_GRAY, c);
    }

    function drawRun(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        var ph = m.phase;
        var col;
        var label;
        if (m.paused) {
            col = C_WHITE;
            label = "PAUSA";
        } else if (ph == IntModel.PH_PREP) {
            col = C_YELLOW;
            label = "PREPÁRATE";
        } else if (ph == IntModel.PH_REST) {
            col = C_BLUE;
            label = "DESCANSO";
        } else {
            col = C_GREEN;
            label = m.isEmom() ? "MINUTO " + m.round.toString() : "TRABAJO";
        }
        // Anillo: lo que queda de la fase
        var len = m.phaseLen * 1000;
        var left = len > 0 ? m.remainingMs().toFloat() / len : 0.0;
        dc.setPenWidth(IntLayout.RING_PEN);
        dc.setColor(C_DARK, Graphics.COLOR_TRANSPARENT);
        dc.drawCircle(120, 120, IntLayout.RING_R);
        dc.setColor(col, Graphics.COLOR_TRANSPARENT);
        if (left >= 0.997) {
            dc.drawCircle(120, 120, IntLayout.RING_R);
        } else if (left > 0.003) {
            dc.drawArc(120, 120, IntLayout.RING_R, Graphics.ARC_CLOCKWISE, 90, 90 - (360 * left).toNumber());
        }
        dc.setPenWidth(1);

        text(dc, 120, IntLayout.MODE_Y, fXs, m.NAMES[m.mode], C_GOLD, c);
        text(dc, 120, IntLayout.PHASE_Y, fSmall, label, col, c);
        text(dc, 120, IntLayout.TIME_Y, fTime, clock(m.remainingSecs()), C_WHITE, c);
        text(dc, 120, IntLayout.ROUND_Y, fSmall, "RONDA " + m.round.toString() + " DE " + m.rounds().toString(), C_WHITE, c);

        var next;
        var nextCol = C_GRAY;
        if (m.paused) {
            next = "START: SEGUIR";
        } else if (ph == IntModel.PH_PREP || ph == IntModel.PH_REST) {
            next = "LUEGO TRABAJO " + clock(m.work());
        } else if (m.round >= m.rounds()) {
            next = "ÚLTIMA RONDA";
            nextCol = C_GOLD;
        } else if (m.rest() > 0) {
            next = "LUEGO DESCANSO " + clock(m.rest());
        } else {
            next = (m.isEmom() ? "LUEGO MINUTO " : "LUEGO RONDA ") + (m.round + 1).toString();
        }
        text(dc, 120, IntLayout.NEXT_Y, fXs, next, nextCol, c);
        if (m.paused) {
            text(dc, 120, IntLayout.EXTRA_Y, fXs, "ATRÁS: MENÚ", C_GRAY, c);
        } else if (m.mode == m.MODE_COMBA) {
            text(dc, 120, IntLayout.EXTRA_Y, fXs, thousands(m.jumps) + " SALTOS", C_WHITE, c);
        }

        var tot = clock(m.elapsedSecs());
        var hr = m.heartRate();
        var w = dc.getTextWidthInPixels(tot, fXs) + 10 + 16 + dc.getTextWidthInPixels(hr, fXs);
        var x = 120 - w / 2;
        text(dc, x, IntLayout.FOOT_Y, fXs, tot, C_GRAY, Graphics.TEXT_JUSTIFY_LEFT);
        var hx = x + dc.getTextWidthInPixels(tot, fXs) + 10;
        dc.drawBitmap(hx, IntLayout.FOOT_ICON_Y, iHeart);
        text(dc, hx + 16, IntLayout.FOOT_Y, fXs, hr, C_WHITE, Graphics.TEXT_JUSTIFY_LEFT);
    }
}
