// GENERADO por intervalos_preview.py: no editar a mano.
module IntLayout {
    const RING_R = 113;
    const RING_PEN = 6;
    const MODE_Y = 28;
    const PHASE_Y = 46;
    const TIME_Y = 60;
    const ROUND_Y = 128;
    const NEXT_Y = 150;
    const EXTRA_Y = 168;
    const FOOT_Y = 187;
    const FOOT_ICON_Y = 191;
    const R_TITLE_Y = 28;
    const R_MODE_Y = 48;
    const R_DESC_Y = 72;
    const R_TOTAL_Y = 92;
    const R_HINT1_Y = 120;
    const R_START_Y = 142;
    const R_HINT2_Y = 166;
    const DOTS_Y = 205;
    const DOTS_DX = 10;
    const D_TITLE_Y = 40;
    const D_ROUNDS_Y = 64;
    const D_TIME_Y = 88;
    const D_EXTRA_Y = 108;
    const D_SAVED_Y = 136;
    const D_HINT_Y = 166;
}
