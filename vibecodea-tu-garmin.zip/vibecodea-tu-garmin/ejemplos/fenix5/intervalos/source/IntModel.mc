using Toybox.Activity;
using Toybox.ActivityRecording;
using Toybox.Application;
using Toybox.Attention;
using Toybox.Communications;
using Toybox.FitContributor;
using Toybox.Lang;
using Toybox.Sensor;
using Toybox.System;
using Toybox.Time;
using Toybox.Timer;
using Toybox.WatchUi;

// Intervalos: Tabata, HIIT, EMOM, boxeo, comba (con saltos) y una rutina propia.
// Cada modo guarda su trabajo, descanso y rondas. Graba con pulso, una vuelta por fase, y sube a la nube.
class IntModel {

    enum {
        ST_READY,
        ST_RUN,
        ST_DONE
    }

    enum {
        PH_PREP,
        PH_WORK,
        PH_REST
    }

    const URL = "https://TU-PROYECTO.supabase.co/functions/v1/reloj";
    const TOKEN = "CAMBIA-ESTE-TOKEN";
    const PREP = 10;
    const MODE_EMOM = 2;
    const MODE_COMBA = 4;

    var NAMES = ["TABATA", "HIIT 40/20", "EMOM", "BOXEO", "COMBA", "MI RUTINA"];
    var TITLES = ["Tabata", "HIIT", "EMOM", "Boxeo", "Comba", "Intervalos"];
    var DEFAULTS = [[20, 10, 8], [40, 20, 10], [60, 0, 10], [180, 60, 12], [60, 30, 10], [45, 15, 12]];
    var WORK_OPTS = [10, 15, 20, 30, 40, 45, 60, 90, 120, 180, 240, 300];
    var REST_OPTS = [0, 5, 10, 15, 20, 30, 45, 60, 90, 120];
    var ROUND_OPTS = [3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50];

    var state = ST_READY;
    var mode = 0;
    var cfg = null;
    var beeps = true;

    var phase = PH_PREP;
    var round = 1;
    var done = 0;
    var phaseLen = PREP;
    var phaseStart = 0;
    var paused = false;
    var pauseAt = 0;
    var startMs = 0;
    var pausedTotal = 0;
    var startedAt = 0;
    var jumps = 0;
    var saved = false;
    var finishedAll = false;
    var totalSecs = 0;

    hidden var mLastSec = -1;
    hidden var mSession = null;
    hidden var mTimer = null;
    hidden var mSensorOn = false;
    hidden var fPhase, fRound, fRounds, fJumps;
    hidden var mArmed = true;
    hidden var mIdx = 0;
    hidden var mLastJump = -100;

    (:typecheck(false))
    function initialize() {
        cfg = [];
        for (var i = 0; i < DEFAULTS.size(); i++) {
            cfg.add([DEFAULTS[i][0], DEFAULTS[i][1], DEFAULTS[i][2]]);
        }
        var c = Application.Storage.getValue("intCfg");
        if (c instanceof Lang.Array && c.size() == 3 && c[1] instanceof Lang.Array && c[1].size() == cfg.size()) {
            mode = c[0];
            cfg = c[1];
            beeps = c[2];
        }
        mTimer = new Timer.Timer();
        mTimer.start(method(:onTick), 250, true);
        sendPending();
    }

    function saveCfg() {
        Application.Storage.setValue("intCfg", [mode, cfg, beeps]);
    }

    (:typecheck(false))
    function work() {
        return cfg[mode][0];
    }

    (:typecheck(false))
    function rest() {
        return cfg[mode][1];
    }

    (:typecheck(false))
    function rounds() {
        return cfg[mode][2];
    }

    function totalPlanned() {
        return PREP + rounds() * work() + (rounds() - 1) * rest();
    }

    function isEmom() {
        return rest() == 0 && work() == 60;
    }

    // ------------------------------------------------------------ reloj

    function onTick() as Void {
        if (state != ST_RUN || paused) {
            return;
        }
        var now = System.getTimer();
        var guard = 0;
        while (state == ST_RUN && now - phaseStart >= phaseLen * 1000 && guard < 5) {
            nextPhase(phaseStart + phaseLen * 1000);
            guard++;
        }
        if (state != ST_RUN) {
            return;
        }
        var sec = remainingSecs();
        if (sec != mLastSec) {
            mLastSec = sec;
            if (sec >= 1 && sec <= 3 && phaseLen > 5) {
                countdown();
            }
            WatchUi.requestUpdate();
        }
    }

    function remainingMs() {
        var now = paused ? pauseAt : System.getTimer();
        var r = phaseLen * 1000 - (now - phaseStart);
        return r < 0 ? 0 : r;
    }

    function remainingSecs() {
        return (remainingMs() + 999) / 1000;
    }

    function elapsedSecs() {
        if (state == ST_DONE) {
            return totalSecs;
        }
        if (startMs == 0) {
            return 0;
        }
        var now = paused ? pauseAt : System.getTimer();
        return (now - startMs - pausedTotal) / 1000;
    }

    function heartRate() {
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.currentHeartRate != null) {
            return ai.currentHeartRate.toString();
        }
        return "--";
    }

    // ------------------------------------------------------------ sesión

    function start() {
        saveCfg();
        mSession = ActivityRecording.createSession({
            :name => TITLES[mode],
            :sport => ActivityRecording.SPORT_TRAINING,
            :subSport => ActivityRecording.SUB_SPORT_CARDIO_TRAINING
        });
        fPhase = mSession.createField("fase", 0, FitContributor.DATA_TYPE_UINT8, {:mesgType => FitContributor.MESG_TYPE_LAP});
        fRound = mSession.createField("ronda", 1, FitContributor.DATA_TYPE_UINT8, {:mesgType => FitContributor.MESG_TYPE_LAP});
        fRounds = mSession.createField("rondas", 2, FitContributor.DATA_TYPE_UINT16, {:mesgType => FitContributor.MESG_TYPE_SESSION});
        fJumps = mSession.createField("saltos", 3, FitContributor.DATA_TYPE_UINT16, {:mesgType => FitContributor.MESG_TYPE_SESSION});
        mSession.start();
        var now = System.getTimer();
        startMs = now;
        pausedTotal = 0;
        startedAt = Time.now().value();
        phase = PH_PREP;
        phaseLen = PREP;
        phaseStart = now;
        round = 1;
        done = 0;
        jumps = 0;
        paused = false;
        mLastSec = -1;
        state = ST_RUN;
        if (mode == MODE_COMBA && (Sensor has :registerSensorDataListener)) {
            Sensor.registerSensorDataListener(method(:onSensorData),
                {:period => 1, :accelerometer => {:enabled => true, :sampleRate => 25}});
            mSensorOn = true;
        }
        alert(PH_PREP);
    }

    // Cierra la fase actual (una vuelta en el archivo) y pasa a la siguiente.
    (:typecheck(false))
    function nextPhase(boundary) {
        if (mSession != null) {
            fPhase.setData(phase == PH_PREP ? 0 : (phase == PH_WORK ? 1 : 2));
            fRound.setData(round);
            mSession.addLap();
        }
        if (phase == PH_WORK) {
            done += 1;
            if (round >= rounds()) {
                finish(true, true);
                return;
            }
            if (rest() > 0) {
                phase = PH_REST;
                phaseLen = rest();
            } else {
                round += 1;
                phaseLen = work();
            }
        } else {
            if (phase == PH_REST) {
                round += 1;
            }
            phase = PH_WORK;
            phaseLen = work();
        }
        phaseStart = boundary;
        mLastSec = -1;
        alert(phase);
        WatchUi.requestUpdate();
    }

    function skip() {
        if (state == ST_RUN && !paused) {
            nextPhase(System.getTimer());
        }
    }

    function addTen() {
        if (state == ST_RUN) {
            phaseLen += 10;
            WatchUi.requestUpdate();
        }
    }

    function pause() {
        if (state != ST_RUN || paused) {
            return;
        }
        paused = true;
        pauseAt = System.getTimer();
        if (mSession != null && mSession.isRecording()) {
            mSession.stop();
        }
        vibe(80, 200);
        WatchUi.requestUpdate();
    }

    function resume() {
        if (state != ST_RUN || !paused) {
            return;
        }
        var d = System.getTimer() - pauseAt;
        phaseStart += d;
        pausedTotal += d;
        paused = false;
        if (mSession != null && !mSession.isRecording()) {
            mSession.start();
        }
        vibe(80, 200);
        WatchUi.requestUpdate();
    }

    (:typecheck(false))
    function finish(save, complete) {
        if (state != ST_RUN) {
            return;
        }
        totalSecs = elapsedSecs();
        if (mSensorOn) {
            Sensor.unregisterSensorDataListener();
            mSensorOn = false;
        }
        if (mSession != null) {
            if (mSession.isRecording()) {
                mSession.stop();
            }
            if (save) {
                fRounds.setData(done);
                fJumps.setData(jumps);
                mSession.save();
            } else {
                mSession.discard();
            }
            mSession = null;
        }
        saved = save;
        finishedAll = complete;
        paused = false;
        state = ST_DONE;
        if (save) {
            queueUpload();
        }
        if (complete) {
            if (beeps && (Attention has :playTone)) {
                Attention.playTone(Attention.TONE_SUCCESS);
            }
            vibe(100, 900);
        }
        WatchUi.requestUpdate();
    }

    function shutdown() {
        if (state == ST_RUN) {
            finish(true, false);
        }
        if (mTimer != null) {
            mTimer.stop();
            mTimer = null;
        }
    }

    // ------------------------------------------------------------ comba: saltos con el acelerómetro

    (:typecheck(false))
    function onSensorData(data as Sensor.SensorData) as Void {
        if (state != ST_RUN || paused || phase != PH_WORK) {
            return;
        }
        var a = data.accelerometerData;
        if (a == null || a.x == null) {
            return;
        }
        var xs = a.x;
        var ys = a.y;
        var zs = a.z;
        for (var i = 0; i < xs.size(); i++) {
            mIdx += 1;
            var m2 = xs[i] * xs[i] + ys[i] * ys[i] + zs[i] * zs[i];
            if (mArmed) {
                // pico de más de 1,7 g y al menos 0,24 s desde el anterior
                if (m2 > 2890000 && mIdx - mLastJump >= 6) {
                    jumps += 1;
                    mLastJump = mIdx;
                    mArmed = false;
                }
            } else if (m2 < 1440000) {
                mArmed = true;
            }
        }
    }

    // ------------------------------------------------------------ avisos

    function vibe(strength, ms) {
        if (Attention has :vibrate) {
            Attention.vibrate([new Attention.VibeProfile(strength, ms)]);
        }
    }

    function countdown() {
        if (beeps && (Attention has :playTone)) {
            Attention.playTone(Attention.TONE_KEY);
        }
        vibe(50, 80);
    }

    function alert(ph) {
        if (Attention has :backlight) {
            try {
                Attention.backlight(true);
            } catch (ex) {
            }
        }
        if (beeps && (Attention has :playTone)) {
            Attention.playTone(ph == PH_REST ? Attention.TONE_INTERVAL_ALERT : Attention.TONE_START);
        }
        if (ph == PH_WORK) {
            vibe(100, 600);
        } else {
            vibe(70, 300);
        }
    }

    // ------------------------------------------------------------ Nube (opcional)

    (:typecheck(false))
    function queueUpload() {
        var d = {
            "tipo" => "intervalos",
            "inicio" => startedAt,
            "min" => totalSecs / 60,
            "segundos" => totalSecs,
            "modo" => NAMES[mode],
            "trabajo" => work(),
            "descanso" => rest(),
            "rondas" => rounds(),
            "hechas" => done,
            "terminado" => finishedAll
        };
        if (mode == MODE_COMBA) {
            d.put("saltos", jumps);
        }
        var p = Application.Storage.getValue("intPending");
        if (!(p instanceof Lang.Array)) {
            p = [];
        }
        p.add(d);
        while (p.size() > 5) {
            p = p.slice(1, null);
        }
        Application.Storage.setValue("intPending", p);
        sendPending();
    }

    (:typecheck(false))
    function sendPending() {
        var p = Application.Storage.getValue("intPending");
        if (!(p instanceof Lang.Array) || p.size() == 0 || !System.getDeviceSettings().phoneConnected) {
            return;
        }
        Communications.makeWebRequest(URL, p[0],
            {
                :method => Communications.HTTP_REQUEST_METHOD_POST,
                :headers => {
                    "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                    "x-reloj-token" => TOKEN
                },
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onSent));
    }

    (:typecheck(false))
    function onSent(code, data) {
        if (code != 200) {
            return;
        }
        var p = Application.Storage.getValue("intPending");
        if (p instanceof Lang.Array && p.size() > 0) {
            p = p.slice(1, null);
            Application.Storage.setValue("intPending", p);
            if (p.size() > 0) {
                sendPending();
            }
        }
    }

    // ------------------------------------------------------------ ajustes

    (:typecheck(false))
    function cycle(opts, cur) {
        for (var i = 0; i < opts.size(); i++) {
            if (opts[i] > cur) {
                return opts[i];
            }
        }
        return opts[0];
    }

    (:typecheck(false))
    function nextWork() {
        cfg[mode][0] = cycle(WORK_OPTS, work());
        saveCfg();
    }

    (:typecheck(false))
    function nextRest() {
        cfg[mode][1] = cycle(REST_OPTS, rest());
        saveCfg();
    }

    (:typecheck(false))
    function nextRounds() {
        cfg[mode][2] = cycle(ROUND_OPTS, rounds());
        saveCfg();
    }

    (:typecheck(false))
    function resetMode() {
        cfg[mode] = [DEFAULTS[mode][0], DEFAULTS[mode][1], DEFAULTS[mode][2]];
        saveCfg();
    }
}
