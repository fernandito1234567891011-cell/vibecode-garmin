using Toybox.Application;
using Toybox.WatchUi;

// «Intervalos F5»: Tabata, HIIT, EMOM, boxeo, comba y rutina propia, con grabación y subida a la nube.
class IntApp extends Application.AppBase {

    hidden var mModel = null;

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        mModel = new IntModel();
        return [new IntView(mModel), new IntDelegate(mModel)];
    }

    function onStop(state) {
        if (mModel != null) {
            mModel.shutdown();
        }
    }
}
