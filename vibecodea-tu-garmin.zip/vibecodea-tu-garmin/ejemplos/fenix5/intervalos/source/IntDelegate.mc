using Toybox.Application;
using Toybox.WatchUi;

// Antes de empezar: ARRIBA/ABAJO cambian de modo, START empieza, ATRÁS abre los ajustes.
// En marcha: START pausa o sigue, ARRIBA salta la fase, ABAJO añade 10 s, ATRÁS pausa y abre el menú.
class IntDelegate extends WatchUi.BehaviorDelegate {

    hidden var m;

    function initialize(model) {
        BehaviorDelegate.initialize();
        m = model;
    }

    function onPreviousPage() {
        if (m.state == IntModel.ST_READY) {
            m.mode = (m.mode + m.NAMES.size() - 1) % m.NAMES.size();
            m.saveCfg();
        } else if (m.state == IntModel.ST_RUN) {
            m.skip();
        }
        WatchUi.requestUpdate();
        return true;
    }

    function onNextPage() {
        if (m.state == IntModel.ST_READY) {
            m.mode = (m.mode + 1) % m.NAMES.size();
            m.saveCfg();
        } else if (m.state == IntModel.ST_RUN) {
            m.addTen();
        }
        WatchUi.requestUpdate();
        return true;
    }

    function onSelect() {
        if (m.state == IntModel.ST_READY) {
            m.start();
        } else if (m.state == IntModel.ST_RUN) {
            if (m.paused) {
                m.resume();
            } else {
                m.pause();
            }
        }
        WatchUi.requestUpdate();
        return true;
    }

    function onBack() {
        if (m.state == IntModel.ST_READY) {
            openSetup();
            return true;
        }
        if (m.state == IntModel.ST_RUN) {
            m.pause();
            openRunMenu();
            return true;
        }
        return false;
    }

    function onMenu() {
        if (m.state == IntModel.ST_READY) {
            openSetup();
        } else if (m.state == IntModel.ST_RUN) {
            m.pause();
            openRunMenu();
        }
        return true;
    }

    function openSetup() {
        var menu = new WatchUi.Menu2({:title => "Intervalos"});
        menu.addItem(new WatchUi.MenuItem("Empezar", null, :start, {}));
        menu.addItem(new WatchUi.MenuItem("Modo", m.NAMES[m.mode], :mode, {}));
        menu.addItem(new WatchUi.MenuItem("Trabajo", IntSetupDelegate.span(m.work()), :work, {}));
        menu.addItem(new WatchUi.MenuItem("Descanso", IntSetupDelegate.span(m.rest()), :rest, {}));
        menu.addItem(new WatchUi.MenuItem("Rondas", m.rounds().toString(), :rounds, {}));
        menu.addItem(new WatchUi.MenuItem("Pitidos", m.beeps ? "Sí" : "No", :beeps, {}));
        menu.addItem(new WatchUi.MenuItem("Valores de fábrica", "Solo este modo", :reset, {}));
        menu.addItem(new WatchUi.MenuItem("Salir", null, :quit, {}));
        WatchUi.pushView(menu, new IntSetupDelegate(m, menu), WatchUi.SLIDE_UP);
    }

    function openRunMenu() {
        var menu = new WatchUi.Menu2({:title => "En pausa"});
        menu.addItem(new WatchUi.MenuItem("Seguir", null, :resume, {}));
        menu.addItem(new WatchUi.MenuItem("Saltar fase", null, :skip, {}));
        menu.addItem(new WatchUi.MenuItem("Añadir 10 s", null, :ten, {}));
        menu.addItem(new WatchUi.MenuItem("Terminar y guardar", null, :save, {}));
        menu.addItem(new WatchUi.MenuItem("Descartar", null, :discard, {}));
        WatchUi.pushView(menu, new IntRunMenuDelegate(m), WatchUi.SLIDE_UP);
    }
}

class IntSetupDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;
    hidden var mMenu;

    function initialize(model, menu) {
        Menu2InputDelegate.initialize();
        m = model;
        mMenu = menu;
    }

    static function span(secs) {
        if (secs < 60) {
            return secs.toString() + " s";
        }
        return (secs / 60).toString() + ":" + (secs % 60).format("%02d") + " min";
    }

    function refresh() {
        var ids = [:mode, :work, :rest, :rounds];
        var vals = [m.NAMES[m.mode], span(m.work()), span(m.rest()), m.rounds().toString()];
        for (var i = 0; i < ids.size(); i++) {
            var idx = mMenu.findItemById(ids[i]);
            if (idx >= 0) {
                mMenu.getItem(idx).setSubLabel(vals[i]);
            }
        }
    }

    function onSelect(item) {
        var id = item.getId();
        if (id == :start) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.start();
        } else if (id == :mode) {
            m.mode = (m.mode + 1) % m.NAMES.size();
            m.saveCfg();
            refresh();
        } else if (id == :work) {
            m.nextWork();
            refresh();
        } else if (id == :rest) {
            m.nextRest();
            refresh();
        } else if (id == :rounds) {
            m.nextRounds();
            refresh();
        } else if (id == :beeps) {
            m.beeps = !m.beeps;
            m.saveCfg();
            item.setSubLabel(m.beeps ? "Sí" : "No");
        } else if (id == :reset) {
            m.resetMode();
            refresh();
        } else if (id == :quit) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            WatchUi.popView(WatchUi.SLIDE_DOWN);
        }
        WatchUi.requestUpdate();
    }
}

class IntRunMenuDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        WatchUi.popView(WatchUi.SLIDE_DOWN);
        if (id == :resume) {
            m.resume();
        } else if (id == :skip) {
            m.resume();
            m.skip();
        } else if (id == :ten) {
            m.addTen();
            m.resume();
        } else if (id == :save) {
            m.finish(true, false);
        } else if (id == :discard) {
            m.finish(false, false);
        }
        WatchUi.requestUpdate();
    }
}
