using Toybox.Activity;
using Toybox.Application;
using Toybox.Attention;
using Toybox.Graphics;
using Toybox.Lang;
using Toybox.Math;
using Toybox.Position;
using Toybox.Sensor;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.WatchUi;

// «Volver F5»: guardas dónde has dejado el coche (o la tienda) y una flecha te lleva de vuelta.
class VolverApp extends Application.AppBase {

    hidden var mModel = null;

    function initialize() {
        AppBase.initialize();
    }

    function onStart(state) {
        mModel = new VolverModel();
        Position.enableLocationEvents(Position.LOCATION_CONTINUOUS, mModel.method(:onPosition));
        if (Sensor has :enableSensorEvents) {
            Sensor.enableSensorEvents(mModel.method(:onSensor));
        }
    }

    function onStop(state) {
        Position.enableLocationEvents(Position.LOCATION_DISABLE, null);
        if (Sensor has :enableSensorEvents) {
            Sensor.enableSensorEvents(null);
        }
    }

    function getInitialView() {
        return [new VolverView(mModel), new VolverDelegate(mModel)];
    }
}

class VolverModel {

    var LABELS = ["COCHE", "TIENDA", "MOTO", "SITIO"];
    var label = 0;
    var spot = null;
    var lat = null;
    var lon = null;
    var quality = 0;
    var heading = null;
    hidden var mArrived = false;

    (:typecheck(false))
    function initialize() {
        var s = Application.Storage.getValue("spot");
        if (s instanceof Lang.Array && s.size() == 4) {
            spot = s;
            label = s[2];
        }
    }

    (:typecheck(false))
    function onPosition(info as Position.Info) as Void {
        if (info != null && info.position != null) {
            var d = info.position.toDegrees();
            if (d[0] < 90 && d[0] > -90) {
                lat = d[0].toFloat();
                lon = d[1].toFloat();
                quality = info.accuracy;
            }
        }
        if (heading == null && info != null && info.heading != null && info.speed != null && info.speed > 1) {
            heading = info.heading;
        }
        checkArrival();
        WatchUi.requestUpdate();
    }

    (:typecheck(false))
    function onSensor(info as Sensor.Info) as Void {
        if (info != null && info.heading != null) {
            heading = info.heading;
        }
        WatchUi.requestUpdate();
    }

    function hasFix() {
        return lat != null && quality >= Position.QUALITY_POOR;
    }

    function save() {
        if (!hasFix()) {
            vibe(30, 80);
            return false;
        }
        spot = [lat, lon, label, Time.now().value()];
        Application.Storage.setValue("spot", spot);
        mArrived = false;
        vibe(80, 300);
        return true;
    }

    function clear() {
        spot = null;
        Application.Storage.deleteValue("spot");
        mArrived = false;
    }

    // Metros hasta el sitio guardado, o null.
    (:typecheck(false))
    function distance() {
        if (spot == null || lat == null) {
            return null;
        }
        var p1 = Math.toRadians(lat);
        var p2 = Math.toRadians(spot[0]);
        var dp = p2 - p1;
        var dl = Math.toRadians(spot[1] - lon);
        var a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    // Grados hacia los que hay que ir, respecto a donde mira el reloj (0 = de frente), o null.
    (:typecheck(false))
    function arrowDeg() {
        if (spot == null || lat == null) {
            return null;
        }
        var p1 = Math.toRadians(lat);
        var p2 = Math.toRadians(spot[0]);
        var dl = Math.toRadians(spot[1] - lon);
        var y = Math.sin(dl) * Math.cos(p2);
        var x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        var brg = Math.toDegrees(Math.atan2(y, x));
        var h = heading == null ? 0.0 : Math.toDegrees(heading);
        return brg - h;
    }

    function checkArrival() {
        var d = distance();
        if (d != null && d < 15 && !mArrived) {
            mArrived = true;
            vibe(100, 800);
        } else if (d != null && d > 40) {
            mArrived = false;
        }
    }

    (:typecheck(false))
    function savedTime() {
        if (spot == null) {
            return "";
        }
        var g = Gregorian.info(new Time.Moment(spot[3]), Time.FORMAT_SHORT);
        return g.hour.toString() + ":" + g.min.format("%02d");
    }

    function vibe(strength, ms) {
        if (Attention has :vibrate) {
            Attention.vibrate([new Attention.VibeProfile(strength, ms)]);
        }
    }
}

class VolverView extends WatchUi.View {

    const C_GOLD = 0xFFAA00;
    const C_WHITE = 0xFFFFFF;
    const C_GRAY = 0xAAAAAA;
    const C_GREEN = 0x55FF55;
    const C_YELLOW = 0xFFFF55;
    const C_RED = 0xFF5555;

    hidden var m;
    hidden var fAlt, fMed, fSmall, fXs;

    function initialize(model) {
        View.initialize();
        m = model;
    }

    function onLayout(dc) {
        fAlt = WatchUi.loadResource(Rez.Fonts.Alt);
        fMed = WatchUi.loadResource(Rez.Fonts.Med);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
    }

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    function onUpdate(dc) {
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        if (m.spot == null) {
            text(dc, 120, VolverLayout.S_TITLE_Y, fXs, "GUARDAR SITIO", C_WHITE, c);
            text(dc, 120, VolverLayout.S_LABEL_Y, fSmall, m.LABELS[m.label], C_GOLD, c);
            text(dc, 120, VolverLayout.S_HINT_Y, fXs, "ARRIBA/ABAJO: CAMBIA", C_GRAY, c);
            if (m.hasFix()) {
                text(dc, 120, VolverLayout.S_GPS_Y, fSmall, "GPS LISTO", C_GREEN, c);
            } else {
                text(dc, 120, VolverLayout.S_GPS_Y, fSmall, "BUSCANDO GPS...", C_YELLOW, c);
            }
            text(dc, 120, VolverLayout.S_START_Y, fSmall, "START: GUARDAR AQUÍ", C_GREEN, c);
            text(dc, 120, VolverLayout.S_BACK_Y, fXs, "ATRÁS: SALIR", C_GRAY, c);
            return;
        }
        text(dc, 120, VolverLayout.TITLE_Y, fXs, m.LABELS[m.spot[2]] + " · " + m.savedTime(), C_GOLD, c);
        var d = m.distance();
        var arrived = d != null && d < 15;
        if (d == null) {
            text(dc, 120, VolverLayout.ARROW_Y - 10, fSmall, "BUSCANDO GPS...", C_YELLOW, c);
        } else if (arrived) {
            text(dc, 120, VolverLayout.ARROW_Y - 10, fSmall, "¡AQUÍ ESTÁ!", C_GREEN, c);
        } else {
            drawArrow(dc, m.arrowDeg());
        }
        var dist = "--";
        var unit = "M";
        if (d != null) {
            if (d < 1000) {
                dist = Math.round(d).toNumber().toString();
            } else if (d < 10000) {
                var t = Math.round(d / 100.0).toNumber();
                dist = (t / 10).toString() + "," + (t % 10).toString();
                unit = "KM";
            } else {
                dist = Math.round(d / 1000.0).toNumber().toString();
                unit = "KM";
            }
        }
        var wd = dc.getTextWidthInPixels(dist, fAlt);
        var wu = dc.getTextWidthInPixels(unit, fMed);
        var left = 120 - (wd + VolverLayout.UNIT_GAP + wu) / 2;
        text(dc, left, VolverLayout.DIST_Y, fAlt, dist, C_WHITE, Graphics.TEXT_JUSTIFY_LEFT);
        text(dc, left + wd + VolverLayout.UNIT_GAP, VolverLayout.DIST_Y + VolverLayout.UNIT_DY, fMed, unit, C_WHITE,
            Graphics.TEXT_JUSTIFY_LEFT);
        if (arrived) {
            text(dc, 120, VolverLayout.FOOT_Y, fXs, "START: OPCIONES", C_GRAY, c);
        } else if (m.quality >= Position.QUALITY_USABLE) {
            text(dc, 120, VolverLayout.FOOT_Y, fXs, "GPS BIEN", C_GREEN, c);
        } else if (m.quality == Position.QUALITY_POOR) {
            text(dc, 120, VolverLayout.FOOT_Y, fXs, "GPS FLOJO", C_YELLOW, c);
        } else {
            text(dc, 120, VolverLayout.FOOT_Y, fXs, "SIN GPS", C_RED, c);
        }
    }

    function drawArrow(dc, deg) {
        if (deg == null) {
            return;
        }
        var a = Math.toRadians(deg);
        var cs = Math.cos(a);
        var sn = Math.sin(a);
        var cx = VolverLayout.ARROW_X;
        var cy = VolverLayout.ARROW_Y;
        var l = VolverLayout.ARROW_L;
        var w = VolverLayout.ARROW_W;
        var base = [[0, -l], [w, l * 0.75], [0, l * 0.35], [-w, l * 0.75]];
        var pts = [];
        for (var i = 0; i < 4; i++) {
            var x = base[i][0];
            var y = base[i][1];
            pts.add([cx + x * cs - y * sn, cy + x * sn + y * cs]);
        }
        dc.setColor(C_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.fillPolygon(pts);
    }
}

// Sin sitio: ARRIBA/ABAJO eligen qué guardas y START lo guarda. Con sitio: START abre las opciones.
class VolverDelegate extends WatchUi.BehaviorDelegate {

    hidden var m;

    function initialize(model) {
        BehaviorDelegate.initialize();
        m = model;
    }

    function onPreviousPage() {
        if (m.spot == null) {
            m.label = (m.label + m.LABELS.size() - 1) % m.LABELS.size();
            WatchUi.requestUpdate();
        }
        return true;
    }

    function onNextPage() {
        if (m.spot == null) {
            m.label = (m.label + 1) % m.LABELS.size();
            WatchUi.requestUpdate();
        }
        return true;
    }

    function onSelect() {
        if (m.spot == null) {
            m.save();
        } else {
            var menu = new WatchUi.Menu2({:title => "Volver"});
            menu.addItem(new WatchUi.MenuItem("Seguir", null, :resume, {}));
            menu.addItem(new WatchUi.MenuItem("Guardar otro aquí", null, :again, {}));
            menu.addItem(new WatchUi.MenuItem("Borrar el sitio", null, :clear, {}));
            WatchUi.pushView(menu, new VolverMenuDelegate(m), WatchUi.SLIDE_UP);
        }
        WatchUi.requestUpdate();
        return true;
    }
}

class VolverMenuDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        WatchUi.popView(WatchUi.SLIDE_DOWN);
        if (id == :again) {
            m.clear();
        } else if (id == :clear) {
            m.clear();
        }
        WatchUi.requestUpdate();
    }
}
