// GENERADO por volver_preview.py: no editar a mano.
module VolverLayout {
    const TITLE_Y = 26;
    const ARROW_X = 120;
    const ARROW_Y = 90;
    const ARROW_L = 38;
    const ARROW_W = 26;
    const DIST_Y = 122;
    const UNIT_DY = 33;
    const UNIT_GAP = 4;
    const FOOT_Y = 184;
    const S_TITLE_Y = 34;
    const S_LABEL_Y = 62;
    const S_HINT_Y = 88;
    const S_GPS_Y = 116;
    const S_START_Y = 142;
    const S_BACK_Y = 170;
}
