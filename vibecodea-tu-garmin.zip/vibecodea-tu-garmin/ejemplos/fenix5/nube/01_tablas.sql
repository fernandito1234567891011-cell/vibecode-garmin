-- Tablas para los datos del reloj (Garmin fēnix 5) y de la API de Garmin.
-- RLS activado y sin políticas: solo la función «reloj» (clave de servicio) lee y escribe.
create table if not exists public.ajustes (
  clave text primary key, valor text, actualizado timestamptz not null default now());
create table if not exists public.reloj_eventos (
  id bigint generated always as identity primary key,
  recibido timestamptz not null default now(), tipo text not null, dia date, datos jsonb not null);
create index if not exists reloj_eventos_tipo_dia on public.reloj_eventos (tipo, dia);
create table if not exists public.reloj_dia (
  dia date primary key, actualizado timestamptz not null default now(),
  pasos int, objetivo_pasos int, kcal int, pisos int, min_intensidad_semana int,
  pulso_noche int, pulso_ahora int, bateria int, altitud_m int, presion_hpa numeric(6,1),
  temp_c numeric(4,1), temp_max_c numeric(4,1), temp_min_c numeric(4,1), lluvia_pct int,
  lat numeric(5,2), lon numeric(5,2), datos jsonb);
create table if not exists public.gym_sesiones (
  inicio timestamptz primary key, minutos int, series int, repes int, detalle jsonb not null);
create table if not exists public.padel_partidos (
  inicio timestamptz primary key, minutos int, resultado text, ganado boolean, detalle jsonb);
create table if not exists public.garmin_dia (
  dia date primary key, actualizado timestamptz not null default now(),
  energia int, energia_nota text, datos jsonb);
alter table public.ajustes enable row level security;
alter table public.reloj_eventos enable row level security;
alter table public.reloj_dia enable row level security;
alter table public.gym_sesiones enable row level security;
alter table public.padel_partidos enable row level security;
alter table public.garmin_dia enable row level security;
-- Genera un token largo y aleatorio (por ejemplo: openssl rand -hex 24) y ponlo aquí.
insert into public.ajustes (clave, valor) values ('reloj_token', 'CAMBIA-ESTE-TOKEN')
  on conflict (clave) do update set valor = excluded.valor, actualizado = now();
select 'listo' as estado;
