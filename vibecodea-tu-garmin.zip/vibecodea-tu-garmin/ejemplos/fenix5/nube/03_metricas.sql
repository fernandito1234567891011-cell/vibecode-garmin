-- Métricas tipo Whoop, agua, resumen semanal y chuleta de qué significa cada dato (18-11-2026)
alter table garmin_dia
  add column if not exists sueno_nota int,
  add column if not exists deuda_sueno_min int,
  add column if not exists recuperacion int,
  add column if not exists esfuerzo numeric(4,1),
  add column if not exists fc_max int,
  add column if not exists lectura text,
  add column if not exists consejo text;
alter table reloj_dia
  add column if not exists agua_ml int,
  add column if not exists agua_objetivo_ml int;

create table if not exists semanas (
  hasta date primary key,
  actualizado timestamptz default now(),
  texto text,
  consejo text,
  datos jsonb
);
alter table semanas enable row level security;

create table if not exists glosario (
  clave text primary key,
  orden int,
  nombre text,
  que_es text,
  por_que_importa text,
  valores_buenos text
);
alter table glosario enable row level security;

insert into glosario (clave, orden, nombre, que_es, por_que_importa, valores_buenos) values
('sueno_horas', 1, 'Horas de sueño', 'El tiempo que has estado dormido de verdad, sin contar los ratos despierto.', 'Es lo que más influye en cómo te encuentras: energía, humor, hambre y concentración.', 'Adultos: de 7 a 9 h. Menos de 6 h varios días seguidos se acumula.'),
('sueno_profundo', 2, 'Sueño profundo', 'La fase más reparadora de la noche: el cuerpo recupera músculo y defensas.', 'Si falta, te levantas cansado aunque hayas dormido horas.', 'Un 13-23 % de la noche: de 1 h a 1 h 45 en 7-8 h. Suele mejorar con horarios regulares.'),
('sueno_rem', 3, 'Sueño REM', 'La fase de los sueños.', 'Ayuda a la memoria y al ánimo.', 'Un 20-25 % de la noche. El Fenix 5 a veces no la distingue y la cuenta como sueño ligero.'),
('despierto', 4, 'Rato despierto', 'Los minutos que te despiertas durante la noche, aunque no lo recuerdes.', 'Muchos cortes hacen el sueño menos reparador.', 'Menos de 30 min en total es normal.'),
('nota_sueno', 5, 'Nota de sueño (0-100)', 'Nota propia de la noche: cuenta sobre todo las horas, y también el sueño profundo, el REM y el rato despierto.', 'Resume la noche en un número para compararla con otras.', '80 o más, muy bien; de 60 a 79, normal; menos de 60, flojo.'),
('deuda_sueno', 6, 'Deuda de sueño', 'Lo que te falta en las últimas 3 noches para llegar a 8 h cada una.', 'El cansancio se acumula: una mala noche se nota, y tres seguidas mucho más.', 'Lo ideal es 0. Se recupera durmiendo un poco más varios días, no de golpe.'),
('pulso_reposo', 7, 'Pulso en reposo', 'Tus pulsaciones por minuto cuando estás quieto del todo; el reloj lo saca sobre todo de la noche.', 'Si sube 3 o más sobre tu media, suele ser cansancio, estrés, alcohol o que vas a ponerte malo.', 'En adultos, 60-100 es lo normal; con buena forma, 50-60 o menos. Lo importante es compararlo con tu media.'),
('recuperacion', 8, 'Recuperación (1-99 %)', 'Estimación propia, al estilo Whoop, de lo preparado que está tu cuerpo hoy. Sale del sueño, del pulso en reposo y del esfuerzo de ayer.', 'Te dice si hoy toca apretar o ir suave.', 'Verde, 67 o más: dale caña. Amarillo, de 34 a 66: normal. Rojo, menos de 34: suave o descanso.'),
('esfuerzo', 9, 'Esfuerzo (0-21)', 'Cuánto ha trabajado tu corazón hoy, al estilo del «strain» de Whoop. Sale del pulso de todo el día.', 'Sirve para equilibrar: los días duros piden más descanso.', 'Día normal, de 4 a 9; entreno bueno, de 10 a 14; muy duro, 18 o más.'),
('energia', 10, 'Energía (5-100)', 'Estimación propia de tu batería, como el Body Battery de los Garmin nuevos: sube durmiendo y baja con el estrés y la actividad.', 'Te dice cuánto te queda en el día.', 'Más de 60, bien; de 30 a 60, a medio gas; menos de 30, en reserva.'),
('estres', 11, 'Estrés (Garmin)', 'Garmin lo calcula con tu pulso, de 0 a 100.', 'Mucho estrés alto durante el día baja la Energía y la recuperación.', 'De 0 a 25, descanso; de 26 a 50, bajo; de 51 a 75, medio; de 76 a 100, alto. No distingue unos nervios de un café o una cuesta.'),
('pasos', 12, 'Pasos', 'Los pasos del día.', 'Moverse a lo largo del día importa aunque entrenes.', 'De 8.000 a 10.000 al día es una buena referencia.'),
('intensidad', 13, 'Minutos de intensidad', 'Minutos de actividad que te hacen sudar; los muy intensos cuentan doble.', 'Es la medida que usa la OMS para la salud del corazón.', 'Al menos 150 a la semana.'),
('vfc', 14, 'VFC (variabilidad del pulso)', 'Cuánto varía el tiempo entre un latido y el siguiente. La mide tu app «VFC de la mañana».', 'Más variación suele significar cuerpo descansado; si baja varios días seguidos, algo te está cargando.', 'Se compara contigo mismo, no con otros: lo que importa es tu tendencia.'),
('agua', 15, 'Agua', 'Lo que bebes al día, contado por botellas en el reloj.', 'Beber poco se nota en la energía y la concentración.', 'Unos 2 litros al día de bebida; más si entrenas o hace calor.')
on conflict (clave) do update set orden = excluded.orden, nombre = excluded.nombre, que_es = excluded.que_es,
  por_que_importa = excluded.por_que_importa, valores_buenos = excluded.valores_buenos;

-- Cada domingo a las 19:07 UTC (20:07 en Madrid en invierno): la semana en tres líneas y un consejo.
select cron.schedule('resumen-semana', '7 19 * * 0', $$
  select net.http_post(
    url := 'https://TU-PROYECTO.supabase.co/functions/v1/reloj/semana',
    headers := jsonb_build_object('Content-Type', 'application/json',
                                  'x-reloj-token', (select valor from public.ajustes where clave = 'reloj_token')),
    body := '{}'::jsonb, timeout_milliseconds := 20000);
$$);
select 'ok' as resultado, (select count(*) from glosario) as glosario, (select count(*) from cron.job) as tareas;
