-- Cada 3 horas (minuto 7) la base llama a la función para bajar los datos de Garmin.
create extension if not exists pg_cron;
create extension if not exists pg_net;
select cron.schedule('garmin-sync', '7 */3 * * *', $$
  select net.http_post(
    url := 'https://TU-PROYECTO.supabase.co/functions/v1/reloj/sync',
    headers := jsonb_build_object('Content-Type', 'application/json',
                                  'x-reloj-token', (select valor from public.ajustes where clave = 'reloj_token')),
    body := '{}'::jsonb, timeout_milliseconds := 20000);
$$);
select jobid, schedule, jobname from cron.job;
