-- Pendientes del día para el reloj (18-11-2026)
create table if not exists pendientes (
  id bigint generated always as identity primary key,
  creado timestamptz not null default now(),
  dia date not null default (now() at time zone 'Europe/Madrid')::date,
  hora time,
  texto text not null,
  hecho boolean not null default false,
  hecho_en timestamptz
);
alter table pendientes enable row level security;
create index if not exists pendientes_dia on pendientes (dia, hecho);
select 'ok' as resultado;
