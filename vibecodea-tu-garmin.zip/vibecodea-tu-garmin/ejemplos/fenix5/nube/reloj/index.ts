// Función «reloj» de Supabase: el servidor opcional de las apps de ejemplo.
//
//  POST /reloj           el reloj manda datos (tipo «dia», «gym», «padel»...) a través del móvil
//  GET  /reloj/energia   la esfera pide la Energía (tipo Body Battery) y las métricas tipo Whoop:
//                        nota de sueño, deuda de sueño, recuperación, esfuerzo, agua y resumen de la semana
//  POST /reloj/sync      cada 3 h (pg_cron): baja de la API personal de Garmin los resúmenes de
//                        hoy y de los dos días anteriores y recalcula la Energía
//  POST /reloj/semana    cada domingo (pg_cron): la semana en tres líneas y un consejo (tabla semanas)
//  GET  /reloj/pendientes  lo que queda por hacer (POST tipo «pendiente» lo añade; tipo «hecho» lo tacha)
//  GET  /reloj/apuntar?q=  el atajo de Siri «Añadir al reloj»: entiende «llamar a mamá a las 6 y media»
//  GET  /reloj/estado    comprobación: qué hay guardado (sin datos personales en la respuesta)
//
// Todas las rutas piden la cabecera «x-reloj-token» (o ?t=) con el token guardado en la tabla ajustes.
import { createClient } from "jsr:@supabase/supabase-js@2";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false },
});
const GARMIN = "https://personal.connectapi.garmin.com";

const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json" } });

let tokenCache: string | null = null;
async function autorizado(req: Request): Promise<boolean> {
  const t = req.headers.get("x-reloj-token") ?? new URL(req.url).searchParams.get("t");
  if (!t) return false;
  if (tokenCache === null) {
    const { data } = await db.from("ajustes").select("valor").eq("clave", "reloj_token").maybeSingle();
    tokenCache = data?.valor ?? "";
  }
  return tokenCache !== "" && t === tokenCache;
}

// Fecha local de Madrid (AAAA-MM-DD), desplazada offset días.
function diaMadrid(offset = 0): string {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Madrid" })
    .format(new Date(Date.now() + offset * 86400e3));
}

const num = (v: unknown): number | null => (typeof v === "number" && isFinite(v) ? v : null);
const ent = (v: unknown): number | null => { const n = num(v); return n === null ? null : Math.round(n); };

// ------------------------------------------------------------------ datos del reloj

async function recibir(body: any) {
  const tipo = String(body?.tipo ?? "dia");
  const dia = typeof body?.dia === "string" ? body.dia : diaMadrid();
  await db.from("reloj_eventos").insert({ tipo, dia, datos: body });
  if (tipo === "dia") {
    await db.from("reloj_dia").upsert({
      dia, actualizado: new Date().toISOString(),
      pasos: ent(body.pasos), objetivo_pasos: ent(body.objetivo), kcal: ent(body.kcal),
      pisos: ent(body.pisos), min_intensidad_semana: ent(body.intensidad),
      pulso_noche: ent(body.noche), pulso_ahora: ent(body.pulso), bateria: ent(body.bateria),
      altitud_m: ent(body.alt), presion_hpa: num(body.hpa),
      temp_c: num(body.temp), temp_max_c: num(body.tmax), temp_min_c: num(body.tmin), lluvia_pct: ent(body.lluvia),
      lat: num(body.lat), lon: num(body.lon), datos: body,
    });
  } else if (tipo === "gym" && num(body.inicio)) {
    await db.from("gym_sesiones").upsert({
      inicio: new Date(body.inicio * 1000).toISOString(), minutos: ent(body.min),
      series: ent(body.series), repes: ent(body.repes), detalle: body.detalle ?? [],
    });
  } else if (tipo === "agua") {
    await db.from("reloj_dia").upsert({
      dia, agua_ml: ent(body.ml), agua_objetivo_ml: ent(body.objetivo), actualizado: new Date().toISOString(),
    });
  } else if (tipo === "pendiente" && typeof body.texto === "string") {
    const hora = typeof body.hora === "string" && /^\d{1,2}:\d{2}$/.test(body.hora) ? body.hora : null;
    await db.from("pendientes").insert({ texto: body.texto.trim().slice(0, 80), hora, dia });
  } else if (tipo === "hecho" && num(body.id)) {
    await db.from("pendientes").update({ hecho: true, hecho_en: new Date().toISOString() }).eq("id", body.id);
  } else if (tipo === "padel" && num(body.inicio)) {
    await db.from("padel_partidos").upsert({
      inicio: new Date(body.inicio * 1000).toISOString(), minutos: ent(body.min),
      resultado: String(body.resultado ?? ""), ganado: body.ganado === true || body.ganado === 1,
      detalle: body,
    });
  }
}

// ------------------------------------------------------------------ pendientes

// El reloj solo tiene mayúsculas españolas, números y algunos signos: el resto se quita.
function paraReloj(t: string): string {
  return t.toUpperCase().replace(/[^A-Z0-9ÁÉÍÓÚÑÜ .,:%+\-\/()·!¡?¿°]/g, "").replace(/\s+/g, " ").trim();
}

function minutosMadrid(): number {
  const [h, m] = new Intl.DateTimeFormat("es-ES", { timeZone: "Europe/Madrid", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
    .format(new Date()).split(":").map(Number);
  return h * 60 + m;
}

const NUMEROS: Record<string, number> = { una: 1, uno: 1, dos: 2, tres: 3, cuatro: 4, cinco: 5, seis: 6, siete: 7,
  ocho: 8, nueve: 9, diez: 10, once: 11, doce: 12 };

// «Llamar a mamá a las 6 y media» -> texto «Llamar a mamá», hora 18:30 (la próxima vez que llegue), hoy.
// Entiende «mañana», «pasado mañana», «de la tarde/noche», «y media», «y cuarto», «menos cuarto» y «11:30».
function interpretar(q: string): { texto: string; hora: string | null; dia: string } {
  let t = ` ${q.trim()} `;
  let dia = diaMadrid(0);
  if (/\bpasado\s+mañana\b/i.test(t)) {
    dia = diaMadrid(2);
    t = t.replace(/\bpasado\s+mañana\b/i, " ");
  } else if (/(?<!de\s+la\s+)\bmañana\b/i.test(t)) {
    dia = diaMadrid(1);
    t = t.replace(/(?<!de\s+la\s+)\bmañana\b/i, " ");
  }
  t = t.replace(/\bhoy\b/i, " ");
  let hora: string | null = null;
  const re = /\b(?:a|sobre|hacia|para|antes\s+de)\s+las?\s+(\d{1,2}|una|uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce)(?:[:.h](\d{2}))?(?:\s+y\s+(media|cuarto)|\s+(menos\s+cuarto))?(?:\s+(?:de\s+la\s+)?(mañana|tarde|noche|madrugada))?(?:\s*h(?:oras)?\b)?|\b(\d{1,2}):(\d{2})\b/i;
  const m = t.match(re);
  if (m) {
    let h: number, min = 0;
    let parte: string | undefined;
    if (m[6]) {
      h = Number(m[6]);
      min = Number(m[7]);
    } else {
      h = /^\d+$/.test(m[1]) ? Number(m[1]) : NUMEROS[m[1].toLowerCase()];
      if (m[2]) min = Number(m[2]);
      if (m[3]) min = m[3].toLowerCase() === "media" ? 30 : 15;
      if (m[4]) { h -= 1; min = 45; }
      parte = m[5]?.toLowerCase();
      if ((parte === "tarde" || parte === "noche") && h < 12) h += 12;
    }
    // Sin «de la mañana/tarde»: de 1 a 7 se entiende por la tarde; de 8 a 11, por la mañana,
    // salvo que esa hora ya haya pasado hoy y la de la tarde no.
    if (!parte && h >= 1 && h <= 7) h += 12;
    const ahora = minutosMadrid();
    if (dia === diaMadrid(0) && h * 60 + min < ahora - 30) {
      if (!parte && h >= 8 && h <= 11 && (h + 12) * 60 + min >= ahora - 30) h += 12;
      else dia = diaMadrid(1);
    }
    if (h >= 0 && h < 24 && min >= 0 && min < 60) {
      hora = `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}`;
      t = t.replace(m[0], " ");
    }
  }
  let texto = t.replace(/\s+/g, " ").trim().replace(/^[,.;:\-\s]+|[,.;:\-\s]+$/g, "");
  if (!texto) texto = "Pendiente";
  return { texto: texto.charAt(0).toUpperCase() + texto.slice(1), hora, dia };
}

// Lo que queda por hacer: de hoy y de los dos días anteriores, primero lo que tiene hora.
async function pendientes() {
  const { data } = await db.from("pendientes").select("id, dia, hora, texto")
    .eq("hecho", false).gte("dia", diaMadrid(-2)).lte("dia", diaMadrid(0))
    .order("dia", { ascending: true }).order("hora", { ascending: true, nullsFirst: false }).limit(12);
  return (data ?? []).map((p: any) => [p.id, paraReloj(p.texto), p.hora ? String(p.hora).slice(0, 5) : null,
    p.dia === diaMadrid(0) ? 0 : 1]);
}

// ------------------------------------------------------------------ Garmin (API personal)

async function tokenGarmin(): Promise<string> {
  const { data } = await db.from("ajustes").select("valor, actualizado").eq("clave", "garmin_access").maybeSingle();
  if (data?.valor && Date.now() - new Date(data.actualizado).getTime() < 20 * 3600e3) return data.valor;
  const clave = Deno.env.get("GARMIN_API_KEY");
  if (!clave) throw new Error("falta el secreto GARMIN_API_KEY");
  const r = await fetch(`${GARMIN}/personalapitoken-service/personal-api/personal-api-key/token`, {
    method: "POST", headers: { Authorization: `ApiKey ${clave.trim()}` },
  });
  const txt = (await r.text()).trim();
  if (!r.ok) throw new Error(`Garmin no dio token (${r.status})`);
  let tok = txt;
  if (txt.startsWith("{")) {
    const j = JSON.parse(txt);
    tok = j.access_token ?? j.accessToken ?? j.token ?? j.personalApiToken ?? j.value ?? "";
    if (!tok) throw new Error(`respuesta del token con campos: ${Object.keys(j).join(", ")}`);
  } else if (txt.startsWith('"')) {
    tok = JSON.parse(txt);
  }
  await db.from("ajustes").upsert({ clave: "garmin_access", valor: tok, actualizado: new Date().toISOString() });
  return tok;
}

async function garmin(path: string, tok: string): Promise<any> {
  const r = await fetch(`${GARMIN}${path}`, { headers: { Authorization: `Bearer ${tok}`, Accept: "application/json" } });
  if (r.status === 204) return null;
  if (!r.ok) throw new Error(`${path.split("?")[0]} -> ${r.status}`);
  return await r.json();
}

// Energía: estimación propia tipo Body Battery (el Fenix 5 no la calcula).
// Por la mañana sale del sueño y del pulso en reposo; durante el día la gastan el estrés y la actividad.
function energia(res: any, sueno: any): { e: number; nota: string } | null {
  if (!res) return null;
  const horas = (num(sueno?.sleepTimeSeconds) ?? 0) / 3600;
  // Sin sueño registrado se parte de 50: el pulso en reposo de ese día tampoco es fiable.
  let e = horas > 0 ? 30 + 70 * Math.min(1, horas / 8) : 50;
  const total = num(sueno?.sleepTimeSeconds), profundo = num(sueno?.deepSleepSeconds);
  if (total && profundo !== null && profundo / total < 0.12) e -= 8;
  const rhr = num(res.restingHeartRate), media = num(res.lastSevenDaysAvgRestingHeartRate);
  if (horas > 0 && rhr && media && rhr > media) e -= Math.min(20, (rhr - media) * 3);
  const m = (s: unknown) => (num(s) ?? 0) / 60;
  e -= m(res.highStressDuration) * 0.25 + m(res.mediumStressDuration) * 0.12 + m(res.lowStressDuration) * 0.04;
  e -= m(res.activityStressDuration) * 0.10;
  e += m(res.restStressDuration) * 0.02;
  e = Math.round(Math.max(5, Math.min(100, e)));
  const nota = horas > 0
    ? `${Math.floor(horas)}H${String(Math.round((horas % 1) * 60)).padStart(2, "0")} DE SUEÑO`
    : "SIN SUEÑO REGISTRADO";
  return { e, nota };
}

// ---------------------------------------------------------- métricas tipo Whoop (estimación propia)
// El Fenix 5 no mide la VFC de noche, así que la recuperación sale del pulso en reposo, del sueño
// y del esfuerzo del día anterior. Zonas como Whoop: verde 67-99, amarillo 34-66, rojo 1-33.

// Nota de sueño 0-100: duración (60), sueño profundo (15), REM (15) y poco rato despierto (10).
function notaSueno(s: any): { nota: number; min: number } | null {
  const total = num(s?.sleepTimeSeconds);
  if (!total || total < 3600) return null;
  const horas = total / 3600;
  const deep = num(s?.deepSleepSeconds) ?? 0, rem = num(s?.remSleepSeconds) ?? 0;
  const awake = num(s?.awakeSleepSeconds) ?? 0;
  let p = 60 * Math.max(0, Math.min(1, (horas - 4) / 4));
  if (rem > 0) {
    p += 15 * Math.min(1, deep / total / 0.18) + 15 * Math.min(1, rem / total / 0.2);
  } else {
    p += 30 * Math.min(1, deep / total / 0.18);
  }
  p += 10 * Math.max(0, 1 - awake / 3600);
  return { nota: Math.round(Math.max(0, Math.min(100, p))), min: Math.round(total / 60) };
}

// Esfuerzo 0-21 a partir del pulso de todo el día (TRIMP con la reserva de pulso, solo por encima del 30 %).
function esfuerzo(hrDia: any, reposo: number | null, fcMax: number): number | null {
  const vals = Array.isArray(hrDia?.heartRateValues) ? hrDia.heartRateValues : null;
  if (!vals || vals.length < 10) return null;
  const rhr = reposo ?? num(hrDia?.restingHeartRate) ?? 55;
  let trimp = 0;
  let prev: number | null = null;
  for (const v of vals) {
    const t = Array.isArray(v) ? num(v[0]) : num(v?.timestamp);
    const hr = Array.isArray(v) ? num(v[1]) : num(v?.value ?? v?.heartRate);
    if (t === null) continue;
    if (prev !== null && hr !== null && fcMax > rhr) {
      const dt = Math.min(5, (t - prev) / 60000);
      const hrr = Math.max(0, Math.min(1, (hr - rhr) / (fcMax - rhr)));
      if (dt > 0 && hrr >= 0.3) trimp += dt * hrr * 0.64 * Math.exp(1.92 * hrr);
    }
    prev = t;
  }
  return Math.round(210 * (1 - Math.exp(-trimp / 120))) / 10;
}

function recuperacion(res: any, sn: { nota: number } | null, esfAyer: number | null): number | null {
  const rhr = num(res?.restingHeartRate), media = num(res?.lastSevenDaysAvgRestingHeartRate);
  // Sin sueño registrado no hay recuperación: el pulso en reposo de ese día no es fiable.
  if (!sn) return null;
  let r = 55;
  if (rhr && media) r += Math.max(-30, Math.min(25, (media - rhr) * 5));
  if (sn) r += (sn.nota - 70) * 0.6;
  if (esfAyer !== null) r -= Math.max(0, esfAyer - 12) * 2;
  return Math.round(Math.max(1, Math.min(99, r)));
}

const hm = (min: number) => {
  const m = Math.round(min);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h${String(m % 60).padStart(2, "0")}`;
};
const coma = (x: number) => String(x).replace(".", ",");

// Lectura del día en palabras normales (para la nube) y un consejo corto (para el reloj).
function leer(res: any, s: any, sn: { nota: number; min: number } | null, deuda: number | null,
  rec: number | null, esf: number | null): { lectura: string; consejo: string | null } {
  const f: string[] = [];
  let consejo: string | null = null;
  if (sn) {
    const h = sn.min / 60;
    if (h >= 7.5) f.push(`Has dormido ${hm(sn.min)}: suficiente.`);
    else if (h >= 6.5) f.push(`Has dormido ${hm(sn.min)}, algo menos de lo que necesitas (7 a 9 h).`);
    else f.push(`Has dormido ${hm(sn.min)}: te falta ${hm(480 - sn.min)} para las 8 h. Suele notarse en la energía y en el hambre.`);
    const total = num(s?.sleepTimeSeconds) ?? 0, deep = num(s?.deepSleepSeconds) ?? 0;
    if (total > 0) {
      const pct = Math.round((100 * deep) / total);
      f.push(pct >= 13
        ? `Sueño profundo ${hm(deep / 60)} (${pct} %): bien.`
        : `Poco sueño profundo: ${hm(deep / 60)} (${pct} %; lo habitual es un 13-23 %). Es la fase en la que el cuerpo se repara.`);
    }
    if (deuda !== null && deuda >= 120) f.push(`Arrastras ${hm(deuda)} de sueño de las últimas noches.`);
  } else {
    f.push("Esta noche el reloj no ha registrado sueño.");
  }
  const rhr = num(res?.restingHeartRate), media = num(res?.lastSevenDaysAvgRestingHeartRate);
  if (rhr && media) {
    const d = Math.round(rhr - media);
    if (d >= 3) f.push(`Pulso en reposo ${rhr}, ${d} por encima de tu media: suele ser cansancio, estrés, alcohol o que vas a ponerte malo.`);
    else if (d <= -2) f.push(`Pulso en reposo ${rhr}, por debajo de tu media: buena señal.`);
  }
  if (rec !== null) {
    if (rec >= 67) { f.push(`Recuperación ${rec} %: buen día para entrenar fuerte.`); consejo = "HOY: DALE CAÑA"; }
    else if (rec >= 34) { f.push(`Recuperación ${rec} %: entrena, pero sin pasarte.`); consejo = "HOY: SIN PASARTE"; }
    else { f.push(`Recuperación ${rec} %: hoy mejor suave o descanso.`); consejo = "HOY: SUAVE"; }
  }
  if (deuda !== null && deuda >= 180) consejo = "HOY: ACUÉSTATE ANTES";
  if (esf !== null) {
    const e = coma(esf);
    if (esf >= 18) f.push(`Esfuerzo ${e} de 21: día muy duro; mañana toca recuperar.`);
    else if (esf >= 14) f.push(`Esfuerzo ${e} de 21: día duro; cena bien y duerme más.`);
    else if (esf >= 8) f.push(`Esfuerzo ${e} de 21: día movido.`);
    else f.push(`Esfuerzo ${e} de 21: día tranquilo.`);
  }
  return { lectura: f.join(" "), consejo };
}

async function fcMaxima(): Promise<number> {
  const { data } = await db.from("ajustes").select("valor").eq("clave", "fc_max").maybeSingle();
  const v = Number(data?.valor);
  return isFinite(v) && v > 120 ? v : 190;
}

async function sync() {
  const tok = await tokenGarmin();
  const ini = diaMadrid(-3), fin = diaMadrid(0);
  const suenos: Record<string, any> = {};
  try {
    const lista = await garmin(`/sleep-service/sleep/dailySleepSummariesByDate?startDate=${ini}&endDate=${fin}`, tok);
    for (const s of Array.isArray(lista) ? lista : []) if (s?.calendarDate) suenos[s.calendarDate] = s;
  } catch (_) { /* sin sueño: seguimos */ }
  let fcMax = await fcMaxima();
  const hechos: string[] = [];
  let esfAyer: number | null = null;
  {
    const { data } = await db.from("garmin_dia").select("esfuerzo").eq("dia", diaMadrid(-3)).maybeSingle();
    esfAyer = num(data?.esfuerzo);
  }
  for (const off of [-2, -1, 0]) {
    const dia = diaMadrid(off);
    let res: any = null, hr: any = null;
    try { res = await garmin(`/usersummary-service/usersummary/daily?calendarDate=${dia}`, tok); } catch (_) { /* nada */ }
    try { hr = await garmin(`/wellness-service/wellness/dailyHeartRate?date=${dia}`, tok); } catch (_) { /* nada */ }
    if (!res && !suenos[dia]) { esfAyer = null; continue; }
    const visto = num(hr?.maxHeartRate);
    if (visto && visto > fcMax) fcMax = visto;
    const en = energia(res, suenos[dia]);
    const sn = notaSueno(suenos[dia]);
    let deuda = 0, noches = 0;
    for (let k = 2; k >= 0; k--) {
      const s = notaSueno(suenos[diaMadrid(off - k)]);
      if (s) { deuda += Math.max(0, 480 - s.min); noches++; }
    }
    const esf = esfuerzo(hr, num(res?.restingHeartRate), fcMax);
    const rec = recuperacion(res, sn, esfAyer);
    const lec = leer(res, suenos[dia], sn, noches ? deuda : null, rec, esf);
    await db.from("garmin_dia").upsert({
      dia, actualizado: new Date().toISOString(),
      energia: en?.e ?? null, energia_nota: en?.nota ?? null,
      sueno_nota: sn?.nota ?? null, deuda_sueno_min: noches ? deuda : null,
      recuperacion: rec, esfuerzo: esf, fc_max: fcMax, lectura: lec.lectura, consejo: lec.consejo,
      datos: { resumen: res, sueno: suenos[dia] ?? null },
    });
    esfAyer = esf;
    hechos.push(dia);
  }
  return hechos;
}

// Lo que la esfera necesita, en claves cortas (la memoria del reloj en segundo plano es pequeña).
async function paraLaEsfera() {
  const { data } = await db.from("garmin_dia")
    .select("dia, energia, energia_nota, sueno_nota, deuda_sueno_min, recuperacion, esfuerzo, consejo")
    .not("energia", "is", null).gte("dia", diaMadrid(-1)).order("dia", { ascending: false }).limit(1);
  if (!data?.length) return null;
  const g = data[0];
  const out: Record<string, unknown> = {
    energia: g.energia, nota: g.energia_nota, dia: g.dia,
    sn: g.sueno_nota, deuda: g.deuda_sueno_min, rec: g.recuperacion, esf: g.esfuerzo, con: g.consejo,
  };
  const { data: hoy } = await db.from("reloj_dia").select("agua_ml, agua_objetivo_ml").eq("dia", diaMadrid(0)).maybeSingle();
  if (hoy?.agua_ml != null) out.agua = [hoy.agua_ml, hoy.agua_objetivo_ml ?? 2000];
  // Próximo pendiente con hora de hoy: [texto, minuto del día]. La esfera decide cuándo enseñarlo.
  const ahora = new Intl.DateTimeFormat("es-ES", { timeZone: "Europe/Madrid", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
    .format(new Date()).split(":").map(Number);
  const minAhora = ahora[0] * 60 + ahora[1];
  const lista = (await pendientes()).filter((p) => p[3] === 0 && p[2] !== null)
    .map((p) => [p[1], Number(String(p[2]).slice(0, 2)) * 60 + Number(String(p[2]).slice(3, 5))] as [string, number])
    .filter((p) => p[1] >= minAhora - 120);
  if (lista.length) out.pend = lista[0];
  // Resumen de los últimos 7 días: [gimnasio, pádel, otras sesiones, sueño medio (min), pasos medios]
  const desde = diaMadrid(-6);
  const desdeTs = new Date(Date.now() - 7 * 86400e3).toISOString();
  const cuenta = async (t: string) =>
    (await db.from(t).select("*", { count: "exact", head: true }).gte("inicio", desdeTs)).count ?? 0;
  const otros = (await db.from("reloj_eventos").select("*", { count: "exact", head: true })
    .in("tipo", ["intervalos", "escalada"]).gte("dia", desde)).count ?? 0;
  const { data: sem } = await db.from("garmin_dia").select("datos").gte("dia", desde);
  let sMin = 0, sN = 0, pasos = 0, pN = 0;
  for (const r of sem ?? []) {
    const s = num((r as any).datos?.sueno?.sleepTimeSeconds);
    if (s && s > 3600) { sMin += s / 60; sN++; }
    const p = num((r as any).datos?.resumen?.totalSteps);
    if (p) { pasos += p; pN++; }
  }
  out.sem = [await cuenta("gym_sesiones"), await cuenta("padel_partidos"), otros,
    sN ? Math.round(sMin / sN) : null, pN ? Math.round(pasos / pN) : null];
  return out;
}

// ------------------------------------------------------------------ la semana en tres líneas

async function resumenSemana() {
  const filas = async (d0: number, d1: number) => (await db.from("garmin_dia")
    .select("dia, sueno_nota, recuperacion, esfuerzo, datos").gte("dia", diaMadrid(d0)).lte("dia", diaMadrid(d1))).data ?? [];
  const media = (rows: any[], f: (r: any) => number | null) => {
    const v = rows.map(f).filter((x): x is number => x !== null && isFinite(x));
    return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
  };
  const sueno = (r: any) => { const x = num(r.datos?.sueno?.sleepTimeSeconds); return x && x > 3600 ? x / 60 : null; };
  const esta = await filas(-6, 0), antes = await filas(-13, -7);
  const sM = media(esta, sueno), sM0 = media(antes, sueno);
  const rM = media(esta, (r) => num(r.recuperacion));
  const eM = media(esta, (r) => num(r.esfuerzo));
  const pM = media(esta, (r) => num(r.datos?.resumen?.totalSteps));
  const desdeTs = new Date(Date.now() - 7 * 86400e3).toISOString();
  const cuenta = async (t: string) =>
    (await db.from(t).select("*", { count: "exact", head: true }).gte("inicio", desdeTs)).count ?? 0;
  const gym = await cuenta("gym_sesiones"), padel = await cuenta("padel_partidos");
  const { data: ev } = await db.from("reloj_eventos").select("tipo").in("tipo", ["intervalos", "escalada"]).gte("dia", diaMadrid(-6));
  const inter = (ev ?? []).filter((e: any) => e.tipo === "intervalos").length;
  const esc = (ev ?? []).filter((e: any) => e.tipo === "escalada").length;
  const { data: ag } = await db.from("reloj_dia").select("agua_ml").gte("dia", diaMadrid(-6)).not("agua_ml", "is", null);
  const aM = media(ag ?? [], (r: any) => num(r.agua_ml));

  const lineas: string[] = [];
  if (sM !== null) {
    let l = `Has dormido ${hm(sM)} de media`;
    if (sM0 !== null && Math.abs(sM - sM0) >= 10) l += ` (${hm(Math.abs(sM - sM0))} ${sM > sM0 ? "más" : "menos"} que la semana anterior)`;
    lineas.push(`${l}; lo ideal son 7 a 9 h.`);
  }
  const partes: string[] = [];
  if (gym) partes.push(`${gym} de gimnasio`);
  if (padel) partes.push(`${padel} de pádel`);
  if (inter) partes.push(`${inter} de intervalos`);
  if (esc) partes.push(`${esc} de escalada`);
  const n = gym + padel + inter + esc;
  lineas.push(n ? `Has entrenado ${n} ${n === 1 ? "vez" : "veces"}: ${partes.join(", ")}.` : "Esta semana el reloj no ha grabado entrenos.");
  const extra: string[] = [];
  if (rM !== null) extra.push(`recuperación media ${Math.round(rM)} %`);
  if (pM !== null) extra.push(`${Math.round(pM).toLocaleString("es-ES")} pasos al día`);
  if (aM !== null) extra.push(`${coma(Math.round(aM / 100) / 10)} l de agua al día`);
  if (extra.length) lineas.push(extra[0][0].toUpperCase() + extra.join(", ").slice(1) + ".");

  let consejo = "Vas bien: sigue así.";
  if (sM !== null && sM < 420) consejo = `Lo que más te ayudaría: dormir ${hm(480 - sM)} más cada noche.`;
  else if (rM !== null && rM < 40) consejo = "Mete un día de descanso de verdad.";
  else if (n === 0) consejo = "Haz al menos dos entrenos la semana que viene.";
  else if (pM !== null && pM < 6000) consejo = "Camina un poco más: apunta a 8.000 pasos al día.";

  const datos = { sueno_medio_min: sM && Math.round(sM), sueno_semana_anterior_min: sM0 && Math.round(sM0),
    recuperacion_media: rM && Math.round(rM), esfuerzo_medio: eM && Math.round(eM * 10) / 10,
    pasos_medios: pM && Math.round(pM), agua_media_ml: aM && Math.round(aM),
    entrenos: { gimnasio: gym, padel, intervalos: inter, escalada: esc } };
  await db.from("semanas").upsert({ hasta: diaMadrid(0), actualizado: new Date().toISOString(),
    texto: lineas.join("\n"), consejo, datos });
  return { hasta: diaMadrid(0), texto: lineas, consejo };
}

// ------------------------------------------------------------------ rutas

Deno.serve(async (req) => {
  if (!(await autorizado(req))) return json({ error: "no autorizado" }, 401);
  const ruta = new URL(req.url).pathname.replace(/\/+$/, "").split("/").pop();
  try {
    if (req.method === "POST" && ruta === "sync") {
      return json({ ok: true, dias: await sync() });
    }
    if (req.method === "GET" && ruta === "energia") {
      const out = await paraLaEsfera();
      if (!out) return json({ error: "sin energía todavía" }, 404);
      return json(out);
    }
    if (req.method === "GET" && ruta === "apuntar") {
      // Para el atajo de Siri «Añadir al reloj»: ?q=<lo que has dicho>. Responde en texto para leerlo en el móvil.
      const q = new URL(req.url).searchParams.get("q") ?? "";
      if (!q.trim()) return new Response("No he entendido qué apuntar.", { headers: { "Content-Type": "text/plain; charset=utf-8" } });
      const p = interpretar(q);
      await db.from("pendientes").insert({ texto: p.texto.slice(0, 80), hora: p.hora, dia: p.dia });
      await db.from("reloj_eventos").insert({ tipo: "pendiente", dia: p.dia, datos: { q, ...p } });
      const cuando = p.dia === diaMadrid(0) ? "hoy" : p.dia === diaMadrid(1) ? "mañana" : "pasado mañana";
      const frase = `Apuntado para ${cuando}${p.hora ? ` a las ${p.hora}` : ""}: ${p.texto}.`;
      return new Response(frase, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
    }
    if (req.method === "GET" && ruta === "pendientes") {
      return json({ p: await pendientes() });
    }
    if (ruta === "semana") {
      if (req.method === "POST") return json(await resumenSemana());
      const { data } = await db.from("semanas").select("hasta, texto, consejo").order("hasta", { ascending: false }).limit(1);
      return data?.length ? json(data[0]) : json({ error: "sin resumen todavía" }, 404);
    }
    if (req.method === "GET" && ruta === "estado") {
      const cuenta = async (t: string) => (await db.from(t).select("*", { count: "exact", head: true })).count ?? 0;
      const { data: g } = await db.from("garmin_dia").select("dia, energia, sueno_nota, recuperacion, esfuerzo")
        .order("dia", { ascending: false }).limit(3);
      return json({
        reloj_dia: await cuenta("reloj_dia"), eventos: await cuenta("reloj_eventos"),
        gym: await cuenta("gym_sesiones"), padel: await cuenta("padel_partidos"),
        garmin: g ?? [], clave_garmin: Boolean(Deno.env.get("GARMIN_API_KEY")),
      });
    }
    if (req.method === "POST") {
      await recibir(await req.json());
      return json({ ok: true });
    }
    return json({ error: "ruta" }, 404);
  } catch (e) {
    return json({ error: String(e instanceof Error ? e.message : e) }, 500);
  }
});
