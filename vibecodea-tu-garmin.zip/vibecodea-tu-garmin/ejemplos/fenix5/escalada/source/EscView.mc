using Toybox.Graphics;
using Toybox.WatchUi;

// Pantalla de «Escalada F5». Posiciones: EscLayout (revisadas con escalada_preview.py).
class EscView extends WatchUi.View {

    const C_GOLD = 0xFFAA00;
    const C_WHITE = 0xFFFFFF;
    const C_GRAY = 0xAAAAAA;
    const C_DARK = 0x555555;
    const C_GREEN = 0x55FF55;
    const C_BLUE = 0x55AAFF;

    hidden var m;
    hidden var fTime, fGrade, fSmall, fXs, iHeart;

    function initialize(model) {
        View.initialize();
        m = model;
    }

    function onLayout(dc) {
        fTime = WatchUi.loadResource(Rez.Fonts.Time);
        fGrade = WatchUi.loadResource(Rez.Fonts.Grade);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
        iHeart = WatchUi.loadResource(Rez.Drawables.Heart);
    }

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    function clock(secs) {
        var h = secs / 3600;
        var mm = (secs % 3600) / 60;
        var ss = secs % 60;
        if (h > 0) {
            return h.toString() + ":" + mm.format("%02d") + ":" + ss.format("%02d");
        }
        return mm.toString() + ":" + ss.format("%02d");
    }

    function onUpdate(dc) {
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        var s = m.state;
        if (s == EscModel.ST_READY) {
            drawReady(dc);
        } else if (s == EscModel.ST_GRADE) {
            drawGrade(dc);
        } else if (s == EscModel.ST_DONE) {
            drawDone(dc);
        } else {
            drawRun(dc);
        }
    }

    function drawReady(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        text(dc, 120, EscLayout.R_TITLE_Y, fXs, "ESCALADA", C_GOLD, c);
        text(dc, 120, EscLayout.R_TYPE_Y, fSmall, m.type == m.TYPE_VIA ? "VÍA" : "BLOQUE", C_WHITE, c);
        text(dc, 120, EscLayout.R_GRADE_Y, fXs, "ÚLTIMO GRADO " + m.gradeText(m.type, m.grade[m.type]), C_GRAY, c);
        text(dc, 120, EscLayout.R_HINT1_Y, fXs, "ARRIBA/ABAJO: CAMBIA", C_GRAY, c);
        text(dc, 120, EscLayout.R_START_Y, fSmall, "START: EMPEZAR", C_GREEN, c);
        text(dc, 120, EscLayout.R_HINT2_Y, fXs, "ATRÁS: SALIR", C_GRAY, c);
    }

    function drawGrade(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        var n = m.routes.size() + 1;
        text(dc, 120, EscLayout.G_TITLE_Y, fXs, "¿QUÉ GRADO?", C_GOLD, c);
        text(dc, 120, EscLayout.G_SUB_Y, fXs, (m.type == m.TYPE_VIA ? "VÍA " : "BLOQUE ") + n.toString() + " · " + clock(m.climbSecs), C_GRAY, c);
        text(dc, 120, EscLayout.G_GRADE_Y, fGrade, m.gradeText(m.type, m.pendingGrade), C_WHITE, c);
        text(dc, 120, EscLayout.G_HINT1_Y, fXs, "ARRIBA/ABAJO: CAMBIA", C_GRAY, c);
        text(dc, 120, EscLayout.G_HINT2_Y, fSmall, "START: SIGUIENTE", C_GREEN, c);
    }

    (:typecheck(false))
    function drawDone(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        text(dc, 120, EscLayout.D_TITLE_Y, fSmall, m.saved ? "GUARDADO" : "DESCARTADO", m.saved ? C_GREEN : C_GRAY, c);
        var nv = m.count(m.TYPE_VIA);
        var nb = m.count(m.TYPE_BLOQUE);
        var l1;
        if (nv > 0 && nb > 0) {
            l1 = nv.toString() + " VÍAS · " + nb.toString() + " BLOQUES";
        } else if (nb > 0) {
            l1 = nb.toString() + (nb == 1 ? " BLOQUE" : " BLOQUES");
        } else {
            l1 = nv.toString() + (nv == 1 ? " VÍA" : " VÍAS");
        }
        text(dc, 120, EscLayout.D_L1_Y, fXs, l1, C_WHITE, c);
        text(dc, 120, EscLayout.D_L2_Y, fXs, m.sends().toString() + " ENCADENES", C_WHITE, c);
        var y = EscLayout.D_L3_Y;
        var mv = m.maxSent(m.TYPE_VIA);
        if (mv >= 0) {
            text(dc, 120, y, fXs, "MÁXIMO VÍA " + m.gradeText(m.TYPE_VIA, mv), C_GOLD, c);
            y = EscLayout.D_L4_Y;
        }
        var mb = m.maxSent(m.TYPE_BLOQUE);
        if (mb >= 0) {
            text(dc, 120, y, fXs, "MÁXIMO BLOQUE " + m.gradeText(m.TYPE_BLOQUE, mb), C_GOLD, c);
        }
        text(dc, 120, EscLayout.D_L5_Y, fXs, clock(m.totalSecs) + " EN TOTAL", C_GRAY, c);
        text(dc, 120, EscLayout.D_HINT_Y, fXs, "ATRÁS: SALIR", C_GRAY, c);
    }

    (:typecheck(false))
    function drawRun(dc) {
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        var climbing = m.state == EscModel.ST_CLIMB;
        var via = m.type == m.TYPE_VIA;
        var top;
        var label;
        var col;
        var secs;
        var ring;
        var l1 = "";
        var l2 = "";
        if (climbing) {
            top = (via ? "VÍA " : "BLOQUE ") + (m.routes.size() + 1).toString();
            label = "ESCALANDO";
            col = C_GREEN;
            secs = m.climbNow();
            ring = 1.0;
            var a = m.altNow();
            if (a != null && (a >= 2 || a <= -2)) {
                l1 = "ALTURA " + (a > 0 ? "+" : "") + a.toString() + " M";
            }
            var mx = m.maxSent(m.type);
            if (mx >= 0) {
                l2 = "MÁXIMO HOY " + m.gradeText(m.type, mx);
            }
        } else {
            top = (via ? "VÍAS: " : "BLOQUES: ") + m.count(m.type).toString();
            secs = m.restSecs();
            var target = m.restTarget();
            ring = secs >= target ? 1.0 : secs.toFloat() / target;
            if (m.routes.size() == 0) {
                label = "CALENTANDO";
                col = C_BLUE;
            } else if (secs >= target) {
                label = via ? "¡A POR OTRA!" : "¡A POR OTRO!";
                col = C_GREEN;
            } else {
                label = "DESCANSO";
                col = C_BLUE;
            }
            l1 = m.sends().toString() + " ENCADENES";
            var n = m.routes.size();
            if (n > 0) {
                var r = m.routes[n - 1];
                l2 = m.gradeText(r[0], r[1]) + " · " + m.resultText(r[0], r[2]);
            }
        }
        dc.setPenWidth(EscLayout.RING_PEN);
        dc.setColor(C_DARK, Graphics.COLOR_TRANSPARENT);
        dc.drawCircle(120, 120, EscLayout.RING_R);
        dc.setColor(col, Graphics.COLOR_TRANSPARENT);
        if (ring >= 0.997) {
            dc.drawCircle(120, 120, EscLayout.RING_R);
        } else if (ring > 0.003) {
            dc.drawArc(120, 120, EscLayout.RING_R, Graphics.ARC_CLOCKWISE, 90, 90 - (360 * ring).toNumber());
        }
        dc.setPenWidth(1);

        text(dc, 120, EscLayout.TOP_Y, fXs, top, C_GOLD, c);
        text(dc, 120, EscLayout.STATE_Y, fSmall, label, col, c);
        text(dc, 120, EscLayout.TIME_Y, fTime, clock(secs), C_WHITE, c);
        text(dc, 120, EscLayout.L1_Y, fXs, l1, C_WHITE, c);
        text(dc, 120, EscLayout.L2_Y, fXs, l2, C_GRAY, c);
        text(dc, 120, EscLayout.HINT_Y, fXs, climbing ? "START: TERMINAR" : "START: A ESCALAR", C_GREEN, c);

        var tot = clock(m.totalNow());
        var hr = m.heartRate();
        var w = dc.getTextWidthInPixels(tot, fXs) + 10 + 16 + dc.getTextWidthInPixels(hr, fXs);
        var x = 120 - w / 2;
        text(dc, x, EscLayout.FOOT_Y, fXs, tot, C_GRAY, Graphics.TEXT_JUSTIFY_LEFT);
        var hx = x + dc.getTextWidthInPixels(tot, fXs) + 10;
        dc.drawBitmap(hx, EscLayout.FOOT_ICON_Y, iHeart);
        text(dc, hx + 16, EscLayout.FOOT_Y, fXs, hr, C_WHITE, Graphics.TEXT_JUSTIFY_LEFT);
    }
}
