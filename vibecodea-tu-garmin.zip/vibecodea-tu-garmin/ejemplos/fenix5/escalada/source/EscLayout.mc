// GENERADO por escalada_preview.py: no editar a mano.
module EscLayout {
    const RING_R = 113;
    const RING_PEN = 6;
    const TOP_Y = 28;
    const STATE_Y = 46;
    const TIME_Y = 60;
    const L1_Y = 130;
    const L2_Y = 149;
    const HINT_Y = 168;
    const FOOT_Y = 187;
    const FOOT_ICON_Y = 191;
    const G_TITLE_Y = 34;
    const G_SUB_Y = 55;
    const G_GRADE_Y = 66;
    const G_HINT1_Y = 136;
    const G_HINT2_Y = 156;
    const R_TITLE_Y = 34;
    const R_TYPE_Y = 56;
    const R_GRADE_Y = 80;
    const R_HINT1_Y = 112;
    const R_START_Y = 136;
    const R_HINT2_Y = 162;
    const D_TITLE_Y = 40;
    const D_L1_Y = 64;
    const D_L2_Y = 84;
    const D_L3_Y = 102;
    const D_L4_Y = 120;
    const D_L5_Y = 140;
    const D_HINT_Y = 166;
}
