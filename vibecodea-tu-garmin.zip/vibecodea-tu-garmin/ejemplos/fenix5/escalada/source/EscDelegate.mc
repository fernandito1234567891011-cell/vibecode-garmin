using Toybox.WatchUi;

// Preparado: ARRIBA/ABAJO vía o bloque, START empieza.
// Descanso: START empieza la siguiente. Escalando: START la termina y pide grado y resultado.
// ATRÁS abre el menú (cambiar de vía a bloque, terminar, descartar).
class EscDelegate extends WatchUi.BehaviorDelegate {

    hidden var m;

    function initialize(model) {
        BehaviorDelegate.initialize();
        m = model;
    }

    function onPreviousPage() {
        if (m.state == EscModel.ST_READY) {
            m.switchType();
        } else if (m.state == EscModel.ST_GRADE) {
            m.harder();
        }
        WatchUi.requestUpdate();
        return true;
    }

    function onNextPage() {
        if (m.state == EscModel.ST_READY) {
            m.switchType();
        } else if (m.state == EscModel.ST_GRADE) {
            m.easier();
        }
        WatchUi.requestUpdate();
        return true;
    }

    function onSelect() {
        var s = m.state;
        if (s == EscModel.ST_READY) {
            m.start();
        } else if (s == EscModel.ST_REST) {
            m.startClimb();
        } else if (s == EscModel.ST_CLIMB) {
            m.top();
        } else if (s == EscModel.ST_GRADE) {
            openResult();
        }
        WatchUi.requestUpdate();
        return true;
    }

    function onBack() {
        var s = m.state;
        if (s == EscModel.ST_READY || s == EscModel.ST_DONE) {
            return false;
        }
        if (s == EscModel.ST_GRADE) {
            openResult();
        } else {
            openMenu();
        }
        return true;
    }

    function onMenu() {
        var s = m.state;
        if (s == EscModel.ST_REST || s == EscModel.ST_CLIMB) {
            openMenu();
        }
        return true;
    }

    function openResult() {
        var via = m.type == m.TYPE_VIA;
        var menu = new WatchUi.Menu2({:title => "¿Cómo ha ido?"});
        menu.addItem(new WatchUi.MenuItem(via ? "Encadenada" : "Encadenado", "Sin caerme", :sent, {}));
        menu.addItem(new WatchUi.MenuItem("Con caídas", "Llegué arriba", :falls, {}));
        menu.addItem(new WatchUi.MenuItem("Sin acabar", null, :project, {}));
        WatchUi.pushView(menu, new EscResultDelegate(m), WatchUi.SLIDE_UP);
    }

    function openMenu() {
        var via = m.type == m.TYPE_VIA;
        var menu = new WatchUi.Menu2({:title => "Escalada"});
        menu.addItem(new WatchUi.MenuItem("Seguir", null, :resume, {}));
        if (m.state == EscModel.ST_CLIMB) {
            menu.addItem(new WatchUi.MenuItem(via ? "Anular esta vía" : "Anular este bloque", null, :cancel, {}));
        } else {
            menu.addItem(new WatchUi.MenuItem(via ? "Pasar a bloques" : "Pasar a vías", null, :switch, {}));
        }
        menu.addItem(new WatchUi.MenuItem("Terminar y guardar", null, :save, {}));
        menu.addItem(new WatchUi.MenuItem("Descartar", null, :discard, {}));
        WatchUi.pushView(menu, new EscMenuDelegate(m), WatchUi.SLIDE_UP);
    }
}

class EscResultDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        WatchUi.popView(WatchUi.SLIDE_DOWN);
        m.confirm(id == :sent ? 0 : (id == :falls ? 1 : 2));
        WatchUi.requestUpdate();
    }
}

class EscMenuDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        WatchUi.popView(WatchUi.SLIDE_DOWN);
        if (id == :cancel) {
            m.cancelClimb();
        } else if (id == :switch) {
            m.switchType();
        } else if (id == :save) {
            m.finish(true);
        } else if (id == :discard) {
            m.finish(false);
        }
        WatchUi.requestUpdate();
    }
}
