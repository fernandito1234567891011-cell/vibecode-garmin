using Toybox.Application;
using Toybox.WatchUi;

// «Escalada F5»: vías y bloques con grado y resultado, descansos con aviso, grabación y subida a la nube.
class EscApp extends Application.AppBase {

    hidden var mModel = null;

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        mModel = new EscModel();
        return [new EscView(mModel), new EscDelegate(mModel)];
    }

    function onStop(state) {
        if (mModel != null) {
            mModel.shutdown();
        }
    }
}
