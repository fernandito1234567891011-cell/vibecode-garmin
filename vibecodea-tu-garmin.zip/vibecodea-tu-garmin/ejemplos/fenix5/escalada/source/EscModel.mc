using Toybox.Activity;
using Toybox.ActivityRecording;
using Toybox.Application;
using Toybox.Attention;
using Toybox.Communications;
using Toybox.FitContributor;
using Toybox.Lang;
using Toybox.Math;
using Toybox.System;
using Toybox.Time;
using Toybox.Timer;
using Toybox.WatchUi;

// Escalada: vías (grado francés) y bloques (grado Font). Cada vía: tiempo, grado, resultado y metros subidos.
// Graba como escalada en roca con pulso, una vuelta por vía y otra por descanso, y sube la sesión a la nube.
class EscModel {

    enum {
        ST_READY,
        ST_REST,
        ST_CLIMB,
        ST_GRADE,
        ST_DONE
    }

    const URL = "https://TU-PROYECTO.supabase.co/functions/v1/reloj";
    const TOKEN = "CAMBIA-ESTE-TOKEN";
    const TYPE_VIA = 0;
    const TYPE_BLOQUE = 1;
    const WARMUP = 600;

    var GRADES = [
        ["4", "5a", "5b", "5c", "6a", "6a+", "6b", "6b+", "6c", "6c+", "7a", "7a+", "7b", "7b+", "7c", "7c+",
         "8a", "8a+", "8b", "8b+", "8c", "8c+", "9a"],
        ["3", "4", "4+", "5", "5+", "6A", "6A+", "6B", "6B+", "6C", "6C+", "7A", "7A+", "7B", "7B+", "7C", "7C+",
         "8A", "8A+", "8B", "8B+", "8C"]
    ];
    var REST_TARGET = [180, 120];

    var state = ST_READY;
    var type = 0;
    var grade = [4, 3];
    var routes = [];
    var pendingGrade = 4;
    var climbSecs = 0;
    var altGain = null;
    var saved = false;
    var totalSecs = 0;

    hidden var mStartMs = 0;
    hidden var mStartedAt = 0;
    hidden var mRestStart = 0;
    hidden var mClimbStart = 0;
    hidden var mAltStart = null;
    hidden var mRestAlerted = false;
    hidden var mSession = null;
    hidden var mTimer = null;
    hidden var fPhase, fRoute, fVias, fBloques, fSends;

    (:typecheck(false))
    function initialize() {
        var c = Application.Storage.getValue("escCfg");
        if (c instanceof Lang.Array && c.size() == 3) {
            type = c[0];
            grade = [c[1], c[2]];
        }
        mTimer = new Timer.Timer();
        mTimer.start(method(:onTick), 1000, true);
        sendPending();
    }

    function saveCfg() {
        Application.Storage.setValue("escCfg", [type, grade[0], grade[1]]);
    }

    function onTick() as Void {
        if (state == ST_REST && routes.size() > 0 && !mRestAlerted && restSecs() >= REST_TARGET[type]) {
            mRestAlerted = true;
            if (Attention has :playTone) {
                Attention.playTone(Attention.TONE_INTERVAL_ALERT);
            }
            vibe(80, 400);
        }
        if (state != ST_READY && state != ST_DONE) {
            WatchUi.requestUpdate();
        }
    }

    function now() {
        return System.getTimer();
    }

    function totalNow() {
        return state == ST_DONE ? totalSecs : (now() - mStartMs) / 1000;
    }

    function restSecs() {
        return (now() - mRestStart) / 1000;
    }

    function climbNow() {
        return (now() - mClimbStart) / 1000;
    }

    function restTarget() {
        return routes.size() == 0 ? WARMUP : REST_TARGET[type];
    }

    (:typecheck(false))
    function altitude() {
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.altitude != null) {
            return ai.altitude;
        }
        return null;
    }

    (:typecheck(false))
    function altNow() {
        var a = altitude();
        if (a == null || mAltStart == null) {
            return null;
        }
        return Math.round(a - mAltStart).toNumber();
    }

    function heartRate() {
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.currentHeartRate != null) {
            return ai.currentHeartRate.toString();
        }
        return "--";
    }

    function gradeText(t, g) {
        return GRADES[t][g];
    }

    // ------------------------------------------------------------ sesión

    function start() {
        saveCfg();
        mSession = ActivityRecording.createSession({
            :name => "Escalada",
            :sport => ActivityRecording.SPORT_ROCK_CLIMBING,
            :subSport => ActivityRecording.SUB_SPORT_GENERIC
        });
        fPhase = mSession.createField("fase", 0, FitContributor.DATA_TYPE_UINT8, {:mesgType => FitContributor.MESG_TYPE_LAP});
        fRoute = mSession.createField("ruta", 1, FitContributor.DATA_TYPE_UINT8, {:mesgType => FitContributor.MESG_TYPE_LAP});
        fVias = mSession.createField("vias", 2, FitContributor.DATA_TYPE_UINT8, {:mesgType => FitContributor.MESG_TYPE_SESSION});
        fBloques = mSession.createField("bloques", 3, FitContributor.DATA_TYPE_UINT8, {:mesgType => FitContributor.MESG_TYPE_SESSION});
        fSends = mSession.createField("encadenes", 4, FitContributor.DATA_TYPE_UINT8, {:mesgType => FitContributor.MESG_TYPE_SESSION});
        mSession.start();
        mStartMs = now();
        mStartedAt = Time.now().value();
        mRestStart = mStartMs;
        mRestAlerted = false;
        state = ST_REST;
        vibe(80, 300);
    }

    (:typecheck(false))
    function lap(phase, route) {
        if (mSession != null) {
            fPhase.setData(phase);
            fRoute.setData(route);
            mSession.addLap();
        }
    }

    function startClimb() {
        if (state != ST_REST) {
            return;
        }
        lap(0, 0);
        mClimbStart = now();
        mAltStart = altitude();
        state = ST_CLIMB;
        vibe(100, 300);
    }

    // Arriba (o se acabó el intento): cierra la vuelta de la vía y pide el grado.
    function top() {
        if (state != ST_CLIMB) {
            return;
        }
        climbSecs = climbNow();
        altGain = altNow();
        lap(type + 1, routes.size() + 1);
        pendingGrade = grade[type];
        mRestStart = now();
        mRestAlerted = false;
        state = ST_GRADE;
        vibe(80, 200);
    }

    function cancelClimb() {
        if (state == ST_CLIMB) {
            lap(type + 1, 0);
            mRestStart = now();
            mRestAlerted = false;
            state = ST_REST;
        }
    }

    function harder() {
        if (pendingGrade < GRADES[type].size() - 1) {
            pendingGrade++;
        }
    }

    function easier() {
        if (pendingGrade > 0) {
            pendingGrade--;
        }
    }

    // result: 0 encadenada, 1 con caídas, 2 sin acabar
    function confirm(result) {
        if (state != ST_GRADE) {
            return;
        }
        routes.add([type, pendingGrade, result, climbSecs, altGain]);
        grade[type] = pendingGrade;
        saveCfg();
        state = ST_REST;
    }

    function switchType() {
        type = 1 - type;
        saveCfg();
    }

    // ------------------------------------------------------------ cuentas

    (:typecheck(false))
    function count(t) {
        var n = 0;
        for (var i = 0; i < routes.size(); i++) {
            if (t < 0 || routes[i][0] == t) {
                n++;
            }
        }
        return n;
    }

    (:typecheck(false))
    function sends() {
        var n = 0;
        for (var i = 0; i < routes.size(); i++) {
            if (routes[i][2] == 0) {
                n++;
            }
        }
        return n;
    }

    // Índice del grado más alto encadenado de ese tipo, o -1.
    (:typecheck(false))
    function maxSent(t) {
        var best = -1;
        for (var i = 0; i < routes.size(); i++) {
            if (routes[i][0] == t && routes[i][2] == 0 && routes[i][1] > best) {
                best = routes[i][1];
            }
        }
        return best;
    }

    function resultText(t, r) {
        if (r == 0) {
            return t == TYPE_VIA ? "ENCADENADA" : "ENCADENADO";
        }
        return r == 1 ? "CON CAÍDAS" : "SIN ACABAR";
    }

    // ------------------------------------------------------------ fin

    (:typecheck(false))
    function finish(save) {
        if (state == ST_READY || state == ST_DONE) {
            return;
        }
        if (state == ST_CLIMB) {
            top();
            confirm(2);
        } else if (state == ST_GRADE) {
            confirm(0);
        }
        totalSecs = (now() - mStartMs) / 1000;
        if (mSession != null) {
            if (mSession.isRecording()) {
                mSession.stop();
            }
            if (save) {
                fVias.setData(count(TYPE_VIA));
                fBloques.setData(count(TYPE_BLOQUE));
                fSends.setData(sends());
                mSession.save();
            } else {
                mSession.discard();
            }
            mSession = null;
        }
        saved = save;
        state = ST_DONE;
        if (save) {
            queueUpload();
        }
        WatchUi.requestUpdate();
    }

    function shutdown() {
        if (state != ST_READY && state != ST_DONE) {
            finish(true);
        }
        if (mTimer != null) {
            mTimer.stop();
            mTimer = null;
        }
    }

    function vibe(strength, ms) {
        if (Attention has :vibrate) {
            Attention.vibrate([new Attention.VibeProfile(strength, ms)]);
        }
    }

    // ------------------------------------------------------------ Nube (opcional)

    (:typecheck(false))
    function queueUpload() {
        var rs = [];
        var names = ["encadenada", "con caídas", "sin acabar"];
        for (var i = 0; i < routes.size(); i++) {
            var r = routes[i];
            var d = {
                "tipo" => r[0] == TYPE_VIA ? "via" : "bloque",
                "grado" => gradeText(r[0], r[1]),
                "resultado" => names[r[2]],
                "segundos" => r[3]
            };
            if (r[4] != null) {
                d.put("altura", r[4]);
            }
            rs.add(d);
        }
        var body = {
            "tipo" => "escalada",
            "inicio" => mStartedAt,
            "min" => totalSecs / 60,
            "segundos" => totalSecs,
            "vias" => count(TYPE_VIA),
            "bloques" => count(TYPE_BLOQUE),
            "encadenes" => sends(),
            "rutas" => rs
        };
        var mv = maxSent(TYPE_VIA);
        if (mv >= 0) {
            body.put("max_via", gradeText(TYPE_VIA, mv));
        }
        var mb = maxSent(TYPE_BLOQUE);
        if (mb >= 0) {
            body.put("max_bloque", gradeText(TYPE_BLOQUE, mb));
        }
        var p = Application.Storage.getValue("escPending");
        if (!(p instanceof Lang.Array)) {
            p = [];
        }
        p.add(body);
        while (p.size() > 3) {
            p = p.slice(1, null);
        }
        Application.Storage.setValue("escPending", p);
        sendPending();
    }

    (:typecheck(false))
    function sendPending() {
        var p = Application.Storage.getValue("escPending");
        if (!(p instanceof Lang.Array) || p.size() == 0 || !System.getDeviceSettings().phoneConnected) {
            return;
        }
        Communications.makeWebRequest(URL, p[0],
            {
                :method => Communications.HTTP_REQUEST_METHOD_POST,
                :headers => {
                    "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                    "x-reloj-token" => TOKEN
                },
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onSent));
    }

    (:typecheck(false))
    function onSent(code, data) {
        if (code != 200) {
            return;
        }
        var p = Application.Storage.getValue("escPending");
        if (p instanceof Lang.Array && p.size() > 0) {
            p = p.slice(1, null);
            Application.Storage.setValue("escPending", p);
            if (p.size() > 0) {
                sendPending();
            }
        }
    }
}
