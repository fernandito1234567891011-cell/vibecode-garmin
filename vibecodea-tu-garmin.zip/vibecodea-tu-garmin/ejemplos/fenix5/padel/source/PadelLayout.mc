// GENERADO por padel_preview.py: no editar a mano.
module PadelLayout {
    const NOS_LBL_Y = 24;
    const NOS_PTS_Y = 26;
    const NOS_G_Y = 47;
    const NOS_BALL_Y = 63;
    const MID_Y = 98;
    const ELL_PTS_Y = 105;
    const ELL_G_Y = 126;
    const ELL_BALL_Y = 142;
    const ELL_LBL_Y = 169;
    const FOOT_Y = 189;
    const FOOT_ICON_Y = 193;
    const G_X = 50;
    const BALL_X = 190;
    const BALL_R = 6;
}
