using Toybox.Graphics;
using Toybox.WatchUi;

// Pantalla de «Pádel F5»: arriba NOSOTROS (botón ARRIBA), abajo ELLOS (botón ABAJO).
// Posiciones: PadelLayout (revisadas con padel_preview.py).
class PadelView extends WatchUi.View {

    const C_US = 0x55FF55;
    const C_THEM = 0xFF5555;
    const C_GRAY = 0xAAAAAA;
    const C_WHITE = 0xFFFFFF;
    const C_GOLD = 0xFFAA00;
    const C_BLUE = 0x00AAFF;

    hidden var m;
    hidden var fBig, fMed, fSmall, fXs, iHeart;

    function initialize(model) {
        View.initialize();
        m = model;
    }

    function onLayout(dc) {
        fBig = WatchUi.loadResource(Rez.Fonts.Big);
        fMed = WatchUi.loadResource(Rez.Fonts.Med);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
        iHeart = WatchUi.loadResource(Rez.Drawables.Heart);
    }

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    // Puntos ganados en %: «62%», o «--» si no hubo
    function pct(won, total) {
        if (total == 0) {
            return "--";
        }
        return (won * 100 / total).toString() + "%";
    }

    function clock(secs) {
        var h = secs / 3600;
        var mm = (secs % 3600) / 60;
        var ss = secs % 60;
        if (h > 0) {
            return h.toString() + ":" + mm.format("%02d") + ":" + ss.format("%02d");
        }
        return mm.toString() + ":" + ss.format("%02d");
    }

    function onUpdate(dc) {
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        if (m.state == PadelModel.ST_READY) {
            text(dc, 120, 40, fSmall, "PÁDEL", C_GOLD, c);
            text(dc, 120, 72, fXs, m.MODOS[m.modo].toUpper(), C_WHITE, c);
            text(dc, 120, 92, fXs, m.superTb ? "SET 3: SÚPER TIE-BREAK" : "SET 3: NORMAL", C_WHITE, c);
            text(dc, 120, 112, fXs, m.saca == 0 ? "SACAMOS NOSOTROS" : "SACAN ELLOS", C_WHITE, c);
            text(dc, 120, 140, fSmall, "START: EMPEZAR", C_US, c);
            text(dc, 120, 166, fXs, "ATRÁS: AJUSTES", C_GRAY, c);
            return;
        }
        if (m.state == PadelModel.ST_SAVED) {
            text(dc, 120, 40, fSmall, "GUARDADO", C_US, c);
            text(dc, 120, 64, fMed, m.score != null ? m.score.resultText() : "", C_WHITE, c);
            text(dc, 120, 94, fXs, m.savedMinutes.toString() + " MIN", C_GRAY, c);
            if (m.score != null) {
                var st = m.score.stats;
                text(dc, 120, 116, fXs, "SAQUE " + pct(st[0], st[1]) + " · RESTO " + pct(st[2], st[3]), C_WHITE, c);
                var l2 = "MEJOR RACHA " + st[7].toString();
                if (st[5] > 0) {
                    l2 = "ORO " + st[4].toString() + "/" + st[5].toString() + " · RACHA " + st[7].toString();
                }
                text(dc, 120, 135, fXs, l2, C_GOLD, c);
            }
            text(dc, 120, 166, fXs, "ATRÁS: SALIR", C_GRAY, c);
            return;
        }
        var s = m.score;
        text(dc, 120, PadelLayout.NOS_LBL_Y, fXs, "NOSOTROS", C_US, c);
        text(dc, 120, PadelLayout.ELL_LBL_Y, fXs, "ELLOS", C_THEM, c);
        if (s.done) {
            // Final: sets ganados en grande y el resultado abajo
            text(dc, 120, PadelLayout.NOS_PTS_Y, fBig, s.setsWon(0).toString(), C_WHITE, c);
            text(dc, 120, PadelLayout.ELL_PTS_Y, fBig, s.setsWon(1).toString(), C_WHITE, c);
            text(dc, 120, PadelLayout.MID_Y, fSmall, s.ganador == 0 ? "¡PARTIDO GANADO!" : "PARTIDO PERDIDO",
                s.ganador == 0 ? C_US : C_THEM, c);
            text(dc, 120, PadelLayout.FOOT_Y, fXs, s.resultText(), C_WHITE, c);
            return;
        }
        text(dc, 120, PadelLayout.NOS_PTS_Y, fBig, s.pointText(0), C_WHITE, c);
        text(dc, 120, PadelLayout.ELL_PTS_Y, fBig, s.pointText(1), C_WHITE, c);
        text(dc, PadelLayout.G_X, PadelLayout.NOS_G_Y, fMed, s.g[0].toString(), C_GRAY, c);
        text(dc, PadelLayout.G_X, PadelLayout.ELL_G_Y, fMed, s.g[1].toString(), C_GRAY, c);
        // Pelota junto al equipo que saca
        dc.setColor(0xFFFF00, Graphics.COLOR_TRANSPARENT);
        dc.fillCircle(PadelLayout.BALL_X, s.server == 0 ? PadelLayout.NOS_BALL_Y : PadelLayout.ELL_BALL_Y, PadelLayout.BALL_R);
        // Línea del medio
        var mid;
        var col = C_GRAY;
        if (m.hasMsg()) {
            mid = m.msg;
            col = m.msgColor;
        } else if (s.tb) {
            mid = s.tbMeta == 10 ? "SÚPER TIE-BREAK" : "TIE-BREAK";
            col = C_BLUE;
        } else if (s.decisivePoint()) {
            mid = s.modo == 2 ? "STAR POINT" : "PUNTO DE ORO";
            col = C_GOLD;
        } else {
            mid = "SET " + (s.sets.size() + 1).toString();
            if (s.sets.size() > 0) {
                mid += " · " + s.resultText();
            }
        }
        text(dc, 120, PadelLayout.MID_Y, fSmall, mid, col, c);
        // Pie: tiempo y pulso
        var t = clock(m.elapsed());
        var hr = m.heartRate();
        var w = dc.getTextWidthInPixels(t, fXs) + 10 + 16 + dc.getTextWidthInPixels(hr, fXs);
        var left = 120 - w / 2;
        text(dc, left, PadelLayout.FOOT_Y, fXs, t, C_GRAY, Graphics.TEXT_JUSTIFY_LEFT);
        var hx = left + dc.getTextWidthInPixels(t, fXs) + 10;
        dc.drawBitmap(hx, PadelLayout.FOOT_ICON_Y, iHeart);
        text(dc, hx + 16, PadelLayout.FOOT_Y, fXs, hr, C_WHITE, Graphics.TEXT_JUSTIFY_LEFT);
    }
}
