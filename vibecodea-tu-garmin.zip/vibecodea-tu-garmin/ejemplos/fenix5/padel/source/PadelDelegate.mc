using Toybox.Application;
using Toybox.Lang;
using Toybox.WatchUi;

// Botones: ARRIBA = punto nuestro, ABAJO = punto de ellos, ATRÁS = deshacer el último punto,
// START = menú (seguir, deshacer, terminar y guardar, descartar).
class PadelDelegate extends WatchUi.BehaviorDelegate {

    hidden var m;

    function initialize(model) {
        BehaviorDelegate.initialize();
        m = model;
    }

    function onPreviousPage() {
        if (m.state == PadelModel.ST_PLAY) {
            m.point(0);
            WatchUi.requestUpdate();
        }
        return true;
    }

    function onNextPage() {
        if (m.state == PadelModel.ST_PLAY) {
            m.point(1);
            WatchUi.requestUpdate();
        }
        return true;
    }

    function onSelect() {
        if (m.state == PadelModel.ST_READY) {
            m.start();
        } else if (m.state == PadelModel.ST_PLAY) {
            openPlayMenu();
        }
        WatchUi.requestUpdate();
        return true;
    }

    function onBack() {
        if (m.state == PadelModel.ST_READY) {
            openSetup();
            return true;
        }
        if (m.state == PadelModel.ST_PLAY) {
            m.undo();
            WatchUi.requestUpdate();
            return true;
        }
        return false;
    }

    function onMenu() {
        if (m.state == PadelModel.ST_READY) {
            openSetup();
        } else if (m.state == PadelModel.ST_PLAY) {
            openPlayMenu();
        }
        return true;
    }

    function openSetup() {
        var menu = new WatchUi.Menu2({:title => "Pádel"});
        menu.addItem(new WatchUi.MenuItem("Empezar", null, :start, {}));
        menu.addItem(new WatchUi.MenuItem("Iguales (40-40)", m.MODOS[m.modo], :modo, {}));
        menu.addItem(new WatchUi.MenuItem("Tercer set", m.superTb ? "Súper tie-break" : "Set normal", :tb, {}));
        menu.addItem(new WatchUi.MenuItem("Saca primero", m.saca == 0 ? "Nosotros" : "Ellos", :saca, {}));
        menu.addItem(new WatchUi.MenuItem("Salir", null, :quit, {}));
        WatchUi.pushView(menu, new PadelSetupDelegate(m), WatchUi.SLIDE_UP);
    }

    function openPlayMenu() {
        var menu = new WatchUi.Menu2({:title => "Partido"});
        menu.addItem(new WatchUi.MenuItem("Seguir", null, :resume, {}));
        menu.addItem(new WatchUi.MenuItem("Deshacer último punto", null, :undo, {}));
        menu.addItem(new WatchUi.MenuItem("Terminar y guardar", null, :save, {}));
        menu.addItem(new WatchUi.MenuItem("Descartar", null, :discard, {}));
        WatchUi.pushView(menu, new PadelPlayMenuDelegate(m), WatchUi.SLIDE_UP);
    }
}

class PadelSetupDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        if (id == :start) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.start();
        } else if (id == :modo) {
            m.modo = (m.modo + 1) % 3;
            item.setSubLabel(m.MODOS[m.modo]);
            m.saveCfg();
        } else if (id == :tb) {
            m.superTb = !m.superTb;
            item.setSubLabel(m.superTb ? "Súper tie-break" : "Set normal");
            m.saveCfg();
        } else if (id == :saca) {
            m.saca = 1 - m.saca;
            item.setSubLabel(m.saca == 0 ? "Nosotros" : "Ellos");
            m.saveCfg();
        } else if (id == :quit) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            WatchUi.popView(WatchUi.SLIDE_DOWN);
        }
        WatchUi.requestUpdate();
    }
}

class PadelPlayMenuDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        WatchUi.popView(WatchUi.SLIDE_DOWN);
        if (id == :undo) {
            m.undo();
        } else if (id == :save) {
            m.finish(true);
        } else if (id == :discard) {
            m.finish(false);
        }
        WatchUi.requestUpdate();
    }
}
