using Toybox.Application;
using Toybox.WatchUi;

// «Pádel F5»: marcador con un botón por punto, grabación del partido y subida a la nube.
class PadelApp extends Application.AppBase {

    hidden var mModel = null;

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        mModel = new PadelModel();
        return [new PadelView(mModel), new PadelDelegate(mModel)];
    }

    function onStop(state) {
        if (mModel != null) {
            mModel.shutdown();
        }
    }
}
