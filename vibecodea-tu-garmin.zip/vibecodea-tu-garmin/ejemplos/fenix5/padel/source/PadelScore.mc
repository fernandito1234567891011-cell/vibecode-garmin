using Toybox.Lang;

// Marcador de pádel. Gemelo del motor en Python (padel/motor.py), probado con test_motor.py.
//
// modo de iguales (40-40): 0 = ventaja, 1 = punto de oro, 2 = star point (ventaja en los dos
// primeros iguales y punto decisivo en el tercero). Mejor de 3 sets a 6 juegos, tie-break a 7
// en 6-6 y, si superTb, el tercer set es un súper tie-break a 10.
// Equipos: 0 = nosotros, 1 = ellos.
class PadelScore {

    enum {
        EV_NONE,
        EV_GAME,
        EV_SET,
        EV_MATCH,
        EV_SIDES
    }

    var modo = 1;
    var superTb = true;
    var sets = [];
    var setsTxt = [];
    var g = [0, 0];
    var p = [0, 0];
    var tb = false;
    var tbMeta = 7;
    var tbFirst = 0;
    var server = 0;
    var iguales = 0;
    var done = false;
    var ganador = -1;
    var tot = [0, 0];
    var evento = EV_NONE;
    var eventoQuien = -1;
    // [saque ganados, saque total, resto ganados, resto total, oro ganados, oro total,
    //  racha actual, mejor racha, juegos de saque ganados, juegos de saque, breaks, juegos al resto]
    var stats = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    hidden var mHist = [];

    function initialize(m, sTb, saca) {
        modo = m;
        superTb = sTb;
        server = saca;
    }

    function copy2(a) {
        return [a[0], a[1]];
    }

    (:typecheck(false))
    function snap() {
        var ss = [];
        var st = [];
        for (var i = 0; i < sets.size(); i++) {
            ss.add(copy2(sets[i]));
            st.add(setsTxt[i]);
        }
        return [ss, st, copy2(g), copy2(p), tb, tbMeta, tbFirst, server, iguales, done, ganador, copy2(tot),
            stats.slice(0, stats.size())];
    }

    (:typecheck(false))
    function undo() {
        var n = mHist.size();
        if (n == 0) {
            return false;
        }
        var s = mHist[n - 1];
        mHist = mHist.slice(0, n - 1);
        sets = s[0];
        setsTxt = s[1];
        g = s[2];
        p = s[3];
        tb = s[4];
        tbMeta = s[5];
        tbFirst = s[6];
        server = s[7];
        iguales = s[8];
        done = s[9];
        ganador = s[10];
        tot = s[11];
        stats = s[12];
        evento = EV_NONE;
        return true;
    }

    (:typecheck(false))
    function setsWon(k) {
        var n = 0;
        for (var i = 0; i < sets.size(); i++) {
            if (sets[i][k] > sets[i][1 - k]) {
                n += 1;
            }
        }
        return n;
    }

    function point(k) {
        if (done) {
            return;
        }
        mHist.add(snap());
        if (mHist.size() > 200) {
            mHist = mHist.slice(1, null);
        }
        evento = EV_NONE;
        eventoQuien = k;
        tot[k] += 1;
        countPoint(k);
        var o = 1 - k;
        if (tb) {
            p[k] += 1;
            var n = p[0] + p[1];
            if (p[k] >= tbMeta && p[k] - p[o] >= 2) {
                g[k] += 1;
                endSet(k, true);
                return;
            }
            // en el tie-break el primero saca un punto y después se cambia cada dos
            server = (((n - 1) / 2) % 2 == 1) ? tbFirst : 1 - tbFirst;
            if (n % 6 == 0) {
                evento = EV_SIDES;
            }
            return;
        }
        p[k] += 1;
        var a = p[k];
        var b = p[o];
        if (a >= 3 && b >= 3) {
            if (a == b) {
                iguales += 1;
                return;
            }
            var decisivo = (modo == 1) || (modo == 2 && iguales >= 3);
            if (a - b >= 2 || decisivo) {
                endGame(k);
            }
            return;
        }
        if (a >= 4 && a - b >= 2) {
            endGame(k);
        }
    }

    (:typecheck(false))
    function countPoint(k) {
        var gold = decisivePoint();
        if (server == 0) {
            stats[1] += 1;
            if (k == 0) {
                stats[0] += 1;
            }
        } else {
            stats[3] += 1;
            if (k == 0) {
                stats[2] += 1;
            }
        }
        if (gold) {
            stats[5] += 1;
            if (k == 0) {
                stats[4] += 1;
            }
        }
        if (k == 0) {
            stats[6] += 1;
            if (stats[6] > stats[7]) {
                stats[7] = stats[6];
            }
        } else {
            stats[6] = 0;
        }
    }

    function endGame(k) {
        if (server == 0) {
            stats[9] += 1;
            if (k == 0) {
                stats[8] += 1;
            }
        } else {
            stats[11] += 1;
            if (k == 0) {
                stats[10] += 1;
            }
        }
        g[k] += 1;
        p = [0, 0];
        iguales = 0;
        server = 1 - server;
        evento = EV_GAME;
        var a = g[k];
        var b = g[1 - k];
        if (a >= 6 && a - b >= 2) {
            endSet(k, false);
            return;
        }
        if (g[0] == 6 && g[1] == 6) {
            startTb(7);
            return;
        }
        if ((g[0] + g[1]) % 2 == 1) {
            evento = EV_SIDES;
        }
    }

    function startTb(meta) {
        tb = true;
        tbMeta = meta;
        tbFirst = server;
        p = [0, 0];
    }

    function endSet(k, wasTb) {
        var txt;
        if (wasTb && tbMeta == 10) {
            txt = p[0].toString() + "-" + p[1].toString();
        } else {
            txt = g[0].toString() + "-" + g[1].toString();
        }
        sets.add([g[0], g[1]]);
        setsTxt.add(txt);
        g = [0, 0];
        p = [0, 0];
        iguales = 0;
        if (wasTb) {
            server = 1 - tbFirst;
        }
        tb = false;
        evento = EV_SET;
        if (setsWon(k) == 2) {
            done = true;
            ganador = k;
            evento = EV_MATCH;
            return;
        }
        if (sets.size() == 2 && superTb) {
            startTb(10);
        }
    }

    function pointText(k) {
        if (tb) {
            return p[k].toString();
        }
        var a = p[k];
        var b = p[1 - k];
        if (a >= 3 && b >= 3) {
            if (a == b) {
                return "40";
            }
            return a > b ? "AD" : "40";
        }
        var n = ["0", "15", "30", "40"];
        return n[a > 3 ? 3 : a];
    }

    // ¿El próximo punto decide el juego? (para avisar de «PUNTO DE ORO» o «STAR POINT»)
    function decisivePoint() {
        if (tb || p[0] < 3 || p[1] < 3 || p[0] != p[1]) {
            return false;
        }
        return modo == 1 || (modo == 2 && iguales >= 3);
    }

    (:typecheck(false))
    function resultText() {
        var s = "";
        for (var i = 0; i < setsTxt.size(); i++) {
            s += (i > 0 ? " " : "") + setsTxt[i];
        }
        return s;
    }
}
