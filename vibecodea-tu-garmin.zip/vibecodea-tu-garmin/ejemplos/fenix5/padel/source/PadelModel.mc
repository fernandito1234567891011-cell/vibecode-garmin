using Toybox.Activity;
using Toybox.ActivityRecording;
using Toybox.Application;
using Toybox.Attention;
using Toybox.Communications;
using Toybox.FitContributor;
using Toybox.Lang;
using Toybox.System;
using Toybox.Time;
using Toybox.Timer;
using Toybox.WatchUi;

// Partido de pádel: marcador, grabación con pulso y subida a la nube.
class PadelModel {

    enum {
        ST_READY,
        ST_PLAY,
        ST_SAVED
    }

    const URL = "https://TU-PROYECTO.supabase.co/functions/v1/reloj";
    const TOKEN = "CAMBIA-ESTE-TOKEN";
    var MODOS = ["Ventaja", "Punto de oro", "Star point"];

    var state = ST_READY;
    var modo = 1;
    var superTb = true;
    var saca = 0;
    var score = null;
    var msg = "";
    var msgColor = 0xFFFFFF;
    var msgUntil = 0;
    var startMs = 0;
    var startedAt = 0;
    var savedMinutes = 0;

    hidden var mSession = null;
    hidden var mTimer = null;
    hidden var fWinner, fSet, fGUs, fGThem, fSUs, fSThem, fPUs, fPThem;

    (:typecheck(false))
    function initialize() {
        var c = Application.Storage.getValue("padelCfg");
        if (c instanceof Lang.Array && c.size() == 3) {
            modo = c[0];
            superTb = c[1];
            saca = c[2];
        }
        mTimer = new Timer.Timer();
        mTimer.start(method(:onTick), 1000, true);
        sendPending();
    }

    function saveCfg() {
        Application.Storage.setValue("padelCfg", [modo, superTb, saca]);
    }

    function onTick() as Void {
        WatchUi.requestUpdate();
    }

    function elapsed() {
        if (startMs == 0) {
            return 0;
        }
        return (System.getTimer() - startMs) / 1000;
    }

    function heartRate() {
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.currentHeartRate != null) {
            return ai.currentHeartRate.toString();
        }
        return "--";
    }

    // ------------------------------------------------------------ partido

    function start() {
        saveCfg();
        score = new PadelScore(modo, superTb, saca);
        mSession = ActivityRecording.createSession({
            :name => "Pádel",
            :sport => ActivityRecording.SPORT_TENNIS,
            :subSport => ActivityRecording.SUB_SPORT_GENERIC
        });
        fWinner = mSession.createField("juego_para", 0, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_LAP});
        fSet = mSession.createField("set", 1, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_LAP});
        fGUs = mSession.createField("juegos_nos", 2, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_LAP});
        fGThem = mSession.createField("juegos_ellos", 3, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_LAP});
        fSUs = mSession.createField("sets_nos", 4, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_SESSION});
        fSThem = mSession.createField("sets_ellos", 5, FitContributor.DATA_TYPE_UINT8,
            {:mesgType => FitContributor.MESG_TYPE_SESSION});
        fPUs = mSession.createField("puntos_nos", 6, FitContributor.DATA_TYPE_UINT16,
            {:mesgType => FitContributor.MESG_TYPE_SESSION});
        fPThem = mSession.createField("puntos_ellos", 7, FitContributor.DATA_TYPE_UINT16,
            {:mesgType => FitContributor.MESG_TYPE_SESSION});
        mSession.start();
        startMs = System.getTimer();
        startedAt = Time.now().value();
        state = ST_PLAY;
        vibe(1);
    }

    function point(k) {
        if (state != ST_PLAY || score == null || score.done) {
            return;
        }
        score.point(k);
        var ev = score.evento;
        var quien = k == 0 ? "NOSOTROS" : "ELLOS";
        var col = k == 0 ? 0x55FF55 : 0xFF5555;
        if (ev == PadelScore.EV_NONE) {
            vibe(0);
            return;
        }
        if (ev == PadelScore.EV_GAME || ev == PadelScore.EV_SIDES || ev == PadelScore.EV_SET || ev == PadelScore.EV_MATCH) {
            if (!score.tb || ev != PadelScore.EV_SIDES) {
                lap(k);
            }
        }
        if (ev == PadelScore.EV_MATCH) {
            show(k == 0 ? "¡PARTIDO GANADO!" : "PARTIDO PERDIDO", col, 3600);
            vibe(3);
        } else if (ev == PadelScore.EV_SET) {
            var t = score.setsTxt[score.setsTxt.size() - 1];
            show("SET " + quien + " " + t, col, 6);
            vibe(2);
        } else if (ev == PadelScore.EV_SIDES) {
            show("CAMBIO DE LADO", 0xFFFF55, score.tb ? 8 : 25);
            vibe(score.tb ? 0 : 1);
        } else {
            show("JUEGO " + quien, col, 3);
            vibe(1);
        }
    }

    // Una vuelta del archivo por juego, con quién lo ganó y cómo va el set.
    (:typecheck(false))
    function lap(k) {
        if (mSession == null) {
            return;
        }
        var n = score.sets.size();
        var gs = score.g;
        if (score.evento == PadelScore.EV_SET || score.evento == PadelScore.EV_MATCH) {
            gs = score.sets[n - 1];
            n -= 1;
        }
        fWinner.setData(k + 1);
        fSet.setData(n + 1);
        fGUs.setData(gs[0]);
        fGThem.setData(gs[1]);
        mSession.addLap();
    }

    function undo() {
        if (score != null && score.undo()) {
            msgUntil = 0;
            vibe(0);
        }
    }

    function show(text, color, secs) {
        msg = text;
        msgColor = color;
        msgUntil = System.getTimer() + secs * 1000;
    }

    function hasMsg() {
        return msgUntil > System.getTimer();
    }

    (:typecheck(false))
    function finish(save) {
        if (mSession != null) {
            if (save) {
                fSUs.setData(score.setsWon(0));
                fSThem.setData(score.setsWon(1));
                fPUs.setData(score.tot[0]);
                fPThem.setData(score.tot[1]);
                mSession.stop();
                mSession.save();
                savedMinutes = elapsed() / 60;
                queueUpload();
            } else {
                mSession.stop();
                mSession.discard();
            }
            mSession = null;
        }
        state = ST_SAVED;
    }

    function shutdown() {
        if (mSession != null) {
            finish(true);
        }
        if (mTimer != null) {
            mTimer.stop();
            mTimer = null;
        }
    }

    // ------------------------------------------------------------ Nube (opcional)

    (:typecheck(false))
    function queueUpload() {
        var sets = [];
        for (var i = 0; i < score.sets.size(); i++) {
            sets.add([score.sets[i][0], score.sets[i][1]]);
        }
        var d = {
            "tipo" => "padel",
            "inicio" => startedAt,
            "min" => savedMinutes,
            "resultado" => score.resultText(),
            "ganado" => score.done && score.ganador == 0,
            "terminado" => score.done,
            "sets" => sets,
            "puntos" => [score.tot[0], score.tot[1]],
            "iguales" => MODOS[modo],
            "super_tb" => superTb,
            "estadisticas" => {
                "saque_ganados" => score.stats[0], "saque_total" => score.stats[1],
                "resto_ganados" => score.stats[2], "resto_total" => score.stats[3],
                "oro_ganados" => score.stats[4], "oro_total" => score.stats[5],
                "mejor_racha" => score.stats[7],
                "juegos_saque_ganados" => score.stats[8], "juegos_saque" => score.stats[9],
                "breaks" => score.stats[10], "juegos_resto" => score.stats[11]
            }
        };
        var p = Application.Storage.getValue("padelPending");
        if (!(p instanceof Lang.Array)) {
            p = [];
        }
        p.add(d);
        while (p.size() > 5) {
            p = p.slice(1, null);
        }
        Application.Storage.setValue("padelPending", p);
        var hist = Application.Storage.getValue("padelLog");
        if (!(hist instanceof Lang.Array)) {
            hist = [];
        }
        hist.add([startedAt, savedMinutes, score.resultText(), score.ganador]);
        while (hist.size() > 30) {
            hist = hist.slice(1, null);
        }
        Application.Storage.setValue("padelLog", hist);
        sendPending();
    }

    (:typecheck(false))
    function sendPending() {
        var p = Application.Storage.getValue("padelPending");
        if (!(p instanceof Lang.Array) || p.size() == 0 || !System.getDeviceSettings().phoneConnected) {
            return;
        }
        Communications.makeWebRequest(URL, p[0],
            {
                :method => Communications.HTTP_REQUEST_METHOD_POST,
                :headers => {
                    "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                    "x-reloj-token" => TOKEN
                },
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onSent));
    }

    (:typecheck(false))
    function onSent(code, data) {
        if (code != 200) {
            return;
        }
        var p = Application.Storage.getValue("padelPending");
        if (p instanceof Lang.Array && p.size() > 0) {
            p = p.slice(1, null);
            Application.Storage.setValue("padelPending", p);
            if (p.size() > 0) {
                sendPending();
            }
        }
    }

    // 0 = punto (toque corto), 1 = juego, 2 = set, 3 = partido
    function vibe(kind) {
        if (!(Attention has :vibrate)) {
            return;
        }
        var v;
        if (kind == 0) {
            v = [new Attention.VibeProfile(50, 60)];
        } else if (kind == 1) {
            v = [new Attention.VibeProfile(80, 300)];
        } else if (kind == 2) {
            v = [new Attention.VibeProfile(100, 300), new Attention.VibeProfile(0, 150), new Attention.VibeProfile(100, 300)];
        } else {
            v = [new Attention.VibeProfile(100, 800)];
        }
        Attention.vibrate(v);
    }
}
