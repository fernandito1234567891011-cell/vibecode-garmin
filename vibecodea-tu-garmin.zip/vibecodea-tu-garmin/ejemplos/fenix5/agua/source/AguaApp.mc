using Toybox.Application;
using Toybox.Attention;
using Toybox.Communications;
using Toybox.Graphics;
using Toybox.Lang;
using Toybox.Math;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.Timer;
using Toybox.WatchUi;

// «Agua F5»: un toque por botella. Lo de hoy sube a la nube y sale también en la esfera.
class AguaApp extends Application.AppBase {

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        var m = new AguaModel();
        return [new AguaView(m), new AguaDelegate(m)];
    }
}

class AguaModel {

    const URL = "https://TU-PROYECTO.supabase.co/functions/v1/reloj";
    const TOKEN = "CAMBIA-ESTE-TOKEN";
    var BOTTLES = [330, 500, 750, 1000];
    var GOALS = [1500, 2000, 2500, 3000, 3500];

    var ml = 0;
    var bottle = 500;
    var goal = 2000;
    var msg = "";
    hidden var mDay = 0;
    hidden var mMsgTimer = null;

    (:typecheck(false))
    function initialize() {
        var c = Application.Storage.getValue("aguaCfg");
        if (c instanceof Lang.Array && c.size() == 2) {
            bottle = c[0];
            goal = c[1];
        }
        load();
        if (Application.Storage.getValue("aguaPend") == true) {
            send();
        }
    }

    function today() {
        var g = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        return g.year * 10000 + g.month * 100 + g.day;
    }

    (:typecheck(false))
    function load() {
        var a = Application.Storage.getValue("agua");
        var d = today();
        if (a instanceof Lang.Array && a.size() == 2 && a[0] == d) {
            ml = a[1];
        } else {
            ml = 0;
        }
        mDay = d;
    }

    // Si ha cambiado el día desde la última vez, se empieza de cero.
    function checkDay() {
        if (today() != mDay) {
            load();
        }
    }

    function save() {
        Application.Storage.setValue("agua", [mDay, ml]);
        Application.Storage.setValue("aguaPend", true);
        send();
    }

    function add(sign) {
        checkDay();
        var before = ml;
        ml += sign * bottle;
        if (ml < 0) {
            ml = 0;
        }
        save();
        if (sign > 0) {
            show("+" + litres(bottle) + " L");
            if (before < goal && ml >= goal) {
                vibe(100, 600);
            } else {
                vibe(50, 120);
            }
        } else {
            show("-" + litres(bottle) + " L");
            vibe(40, 80);
        }
    }

    function reset() {
        ml = 0;
        save();
    }

    function show(t) {
        msg = t;
        if (mMsgTimer == null) {
            mMsgTimer = new Timer.Timer();
        }
        mMsgTimer.stop();
        mMsgTimer.start(method(:clearMsg), 2000, false);
        WatchUi.requestUpdate();
    }

    function clearMsg() as Void {
        msg = "";
        WatchUi.requestUpdate();
    }

    function vibe(strength, ms) {
        if (Attention has :vibrate) {
            Attention.vibrate([new Attention.VibeProfile(strength, ms)]);
        }
    }

    // 1500 -> «1,5»; 2000 -> «2»; 330 -> «0,33»
    function litres(v) {
        var c = Math.round(v / 10.0).toNumber();
        var s = (c / 100).toString();
        var dec = c % 100;
        if (dec != 0) {
            s += "," + (dec % 10 == 0 ? (dec / 10).toString() : dec.format("%02d"));
        }
        return s;
    }

    // Litros con un decimal como mucho: 990 -> «1»
    function litresShort(v) {
        var d = Math.round(v / 100.0).toNumber();
        return d % 10 == 0 ? (d / 10).toString() : (d / 10).toString() + "," + (d % 10).toString();
    }

    function saveCfg() {
        Application.Storage.setValue("aguaCfg", [bottle, goal]);
    }

    (:typecheck(false))
    function next(opts, cur) {
        for (var i = 0; i < opts.size(); i++) {
            if (opts[i] > cur) {
                return opts[i];
            }
        }
        return opts[0];
    }

    (:typecheck(false))
    function send() {
        if (!System.getDeviceSettings().phoneConnected) {
            return;
        }
        var d = mDay;
        var dia = (d / 10000).toString() + "-" + ((d / 100) % 100).format("%02d") + "-" + (d % 100).format("%02d");
        Communications.makeWebRequest(URL, {"tipo" => "agua", "dia" => dia, "ml" => ml, "objetivo" => goal},
            {
                :method => Communications.HTTP_REQUEST_METHOD_POST,
                :headers => {
                    "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                    "x-reloj-token" => TOKEN
                },
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onSent));
    }

    (:typecheck(false))
    function onSent(code, data) {
        if (code == 200) {
            Application.Storage.setValue("aguaPend", false);
        }
    }
}

class AguaView extends WatchUi.View {

    const C_GOLD = 0xFFAA00;
    const C_WHITE = 0xFFFFFF;
    const C_GRAY = 0xAAAAAA;
    const C_DARK = 0x555555;
    const C_GREEN = 0x55FF55;
    const C_BLUE = 0x00AAFF;

    hidden var m;
    hidden var fAlt, fMed, fSmall, fXs;

    function initialize(model) {
        View.initialize();
        m = model;
    }

    function onLayout(dc) {
        fAlt = WatchUi.loadResource(Rez.Fonts.Alt);
        fMed = WatchUi.loadResource(Rez.Fonts.Med);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
    }

    function onShow() {
        m.checkDay();
    }

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    function onUpdate(dc) {
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        var frac = m.goal > 0 ? m.ml.toFloat() / m.goal : 0.0;
        if (frac > 1) {
            frac = 1.0;
        }
        dc.setPenWidth(AguaLayout.RING_PEN);
        dc.setColor(C_DARK, Graphics.COLOR_TRANSPARENT);
        dc.drawCircle(120, 120, AguaLayout.RING_R);
        if (frac >= 0.997) {
            dc.setColor(C_GREEN, Graphics.COLOR_TRANSPARENT);
            dc.drawCircle(120, 120, AguaLayout.RING_R);
        } else if (frac > 0.003) {
            dc.setColor(C_BLUE, Graphics.COLOR_TRANSPARENT);
            dc.drawArc(120, 120, AguaLayout.RING_R, Graphics.ARC_CLOCKWISE, 90, 90 - (360 * frac).toNumber());
        }
        dc.setPenWidth(1);

        text(dc, 120, AguaLayout.TITLE_Y, fXs, "AGUA HOY", C_GOLD, c);
        var big = m.litresShort(m.ml);
        var wa = dc.getTextWidthInPixels(big, fAlt);
        var wl = dc.getTextWidthInPixels("L", fMed);
        var left = 120 - (wa + AguaLayout.L_GAP + wl) / 2;
        text(dc, left, AguaLayout.BIG_Y, fAlt, big, C_WHITE, Graphics.TEXT_JUSTIFY_LEFT);
        text(dc, left + wa + AguaLayout.L_GAP, AguaLayout.BIG_Y + AguaLayout.L_DY, fMed, "L", C_WHITE, Graphics.TEXT_JUSTIFY_LEFT);
        var goalTxt = m.ml >= m.goal ? "¡OBJETIVO CUMPLIDO!" : "DE " + m.litresShort(m.goal) + " L · BOTELLA " + m.litres(m.bottle);
        text(dc, 120, AguaLayout.GOAL_Y, fSmall, goalTxt, C_GRAY, c);

        var total = (m.goal + m.bottle - 1) / m.bottle;
        var full = m.ml / m.bottle;
        if (total <= 8) {
            drawBottles(dc, full, total);
        } else {
            text(dc, 120, AguaLayout.BOT_Y + 4, fSmall, full.toString() + " DE " + total.toString() + " BOTELLAS", C_BLUE, c);
        }
        if (m.msg.length() > 0) {
            text(dc, 120, AguaLayout.MSG_Y, fSmall, m.msg, C_GREEN, c);
        } else {
            text(dc, 120, AguaLayout.HINT_Y, fXs, "START: +1 BOTELLA", C_GREEN, c);
        }
        text(dc, 120, AguaLayout.HINT2_Y, fXs, "MENÚ: AJUSTES", C_GRAY, c);
    }

    function drawBottles(dc, full, total) {
        var w = AguaLayout.BOT_W;
        var h = AguaLayout.BOT_H;
        var g = AguaLayout.BOT_GAP;
        var neck = AguaLayout.BOT_NECK;
        var tw = total * w + (total - 1) * g;
        var x = 120 - tw / 2;
        var y = AguaLayout.BOT_Y;
        for (var i = 0; i < total; i++) {
            dc.setColor(i < full ? C_BLUE : C_DARK, Graphics.COLOR_TRANSPARENT);
            dc.fillRoundedRectangle(x, y + neck, w, h - neck, 3);
            dc.fillRectangle(x + w / 2 - 3, y, 6, neck + 1);
            x += w + g;
        }
    }
}

// START suma una botella. MENÚ (mantener ARRIBA): quitar una, tamaño de botella, objetivo, poner a cero.
class AguaDelegate extends WatchUi.BehaviorDelegate {

    hidden var m;

    function initialize(model) {
        BehaviorDelegate.initialize();
        m = model;
    }

    function onSelect() {
        m.add(1);
        WatchUi.requestUpdate();
        return true;
    }

    function onMenu() {
        var menu = new WatchUi.Menu2({:title => "Agua"});
        menu.addItem(new WatchUi.MenuItem("Quitar una botella", null, :minus, {}));
        menu.addItem(new WatchUi.MenuItem("Botella", m.litres(m.bottle) + " l", :bottle, {}));
        menu.addItem(new WatchUi.MenuItem("Objetivo del día", m.litresShort(m.goal) + " l", :goal, {}));
        menu.addItem(new WatchUi.MenuItem("Poner hoy a cero", null, :reset, {}));
        WatchUi.pushView(menu, new AguaMenuDelegate(m), WatchUi.SLIDE_UP);
        return true;
    }
}

class AguaMenuDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;

    function initialize(model) {
        Menu2InputDelegate.initialize();
        m = model;
    }

    function onSelect(item) {
        var id = item.getId();
        if (id == :minus) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.add(-1);
        } else if (id == :bottle) {
            m.bottle = m.next(m.BOTTLES, m.bottle);
            m.saveCfg();
            item.setSubLabel(m.litres(m.bottle) + " l");
        } else if (id == :goal) {
            m.goal = m.next(m.GOALS, m.goal);
            m.saveCfg();
            item.setSubLabel(m.litresShort(m.goal) + " l");
            m.save();
        } else if (id == :reset) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
            m.reset();
        }
        WatchUi.requestUpdate();
    }
}
