// GENERADO por agua_preview.py: no editar a mano.
module AguaLayout {
    const RING_R = 113;
    const RING_PEN = 6;
    const TITLE_Y = 30;
    const BIG_Y = 44;
    const L_DY = 33;
    const L_GAP = 4;
    const GOAL_Y = 108;
    const BOT_Y = 134;
    const BOT_W = 14;
    const BOT_H = 26;
    const BOT_GAP = 6;
    const BOT_NECK = 5;
    const MSG_Y = 163;
    const HINT_Y = 166;
    const HINT2_Y = 186;
}
