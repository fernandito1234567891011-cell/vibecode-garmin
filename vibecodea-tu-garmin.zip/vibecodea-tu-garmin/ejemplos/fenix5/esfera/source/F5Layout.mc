// GENERADO por preview.py: no editar a mano. Posiciones revisadas con la vista previa.
module F5Layout {
    const RING_R = 113;
    const RING_PEN = 6;
    const MOON_Y = 23;
    const MOON_R = 9;
    const ZOD_Y = 14;
    const ZOD_GAP = 4;
    const SEC_R = 113;
    const SEC_DOT = 4;
    const DATE_Y = 36;
    const TIME_Y = 42;
    const STATUS_Y = 106;
    const ROW1_ICON_Y = 129;
    const ROW1_Y = 142;
    const ROW1_DX = 66;
    const ROW2_ICON_Y = 169;
    const ROW2_Y = 167;
    const ROW2_DX = 52;
    const ROW3_ICON_Y = 189;
    const ROW3_Y = 187;
    const ROW4_ICON_Y = 207;
    const ROW4_Y = 205;
    const ICON_GAP = 16;
    const SUN_GAP = 10;
}
