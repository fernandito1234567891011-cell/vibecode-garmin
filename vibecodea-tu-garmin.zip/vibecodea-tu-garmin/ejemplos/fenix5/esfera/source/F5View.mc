using Toybox.Activity;
using Toybox.ActivityMonitor;
using Toybox.Application;
using Toybox.Graphics;
using Toybox.Lang;
using Toybox.Math;
using Toybox.SensorHistory;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.WatchUi;

// Esfera F5+ para el fenix 5 (240x240, 64 colores).
// Posiciones: F5Layout (generado por preview.py, revisado con la vista previa en 11 escenarios).
//
// Línea del medio: «tarjetas» que rotan cada minuto (y cada 3 s al levantar la muñeca):
// cuenta atrás para la cama, cómo ha ido la noche, Energía, tiempo de hoy, altitud,
// presión (con aviso de tormenta) y próxima luna llena o nueva. De madrugada solo «HORA DE DORMIR».
class F5View extends WatchUi.WatchFace {

    const C_GOLD = 0xFFAA00;
    const C_SKY = 0x55AAFF;
    const C_GREEN = 0x55FF55;
    const C_YELLOW = 0xFFFF55;
    const C_ORANGE = 0xFF5500;
    const C_RED = 0xFF0000;
    const C_GRAY = 0xAAAAAA;
    const C_DIM = 0x555555;
    const C_MOON = 0xFFFFAA;
    const C_WHITE = 0xFFFFFF;

    hidden var fTime, fMed, fSmall, fXs, fZod;
    hidden var iHeart, iSteps, iFlame, iBolt, iBell, iBt, iSunUp, iSunDown;
    hidden var iWx;
    hidden var mDays = ["DOM", "LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB"];
    hidden var mMonths = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"];
    hidden var mSunDay = -1;
    hidden var mSunrise = null;
    hidden var mSunset = null;
    hidden var mAwake = false;
    hidden var mWakeAt = 0;
    hidden var mCards = null;
    hidden var mCardsMin = -1;
    hidden var mLocAt = 0;

    function initialize() {
        WatchFace.initialize();
        // Datos de la versión 1 (otro formato): fuera.
        Application.Storage.deleteValue("hist");
        Application.Storage.deleteValue("night");
    }

    function onLayout(dc) {
        fTime = WatchUi.loadResource(Rez.Fonts.Time);
        fMed = WatchUi.loadResource(Rez.Fonts.Med);
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
        fZod = WatchUi.loadResource(Rez.Fonts.Zod);
        iHeart = WatchUi.loadResource(Rez.Drawables.Heart);
        iSteps = WatchUi.loadResource(Rez.Drawables.Steps);
        iFlame = WatchUi.loadResource(Rez.Drawables.Flame);
        iBolt = WatchUi.loadResource(Rez.Drawables.Bolt);
        iBell = WatchUi.loadResource(Rez.Drawables.Bell);
        iBt = WatchUi.loadResource(Rez.Drawables.Bt);
        iSunUp = WatchUi.loadResource(Rez.Drawables.SunUp);
        iSunDown = WatchUi.loadResource(Rez.Drawables.SunDown);
        iWx = [
            WatchUi.loadResource(Rez.Drawables.WxSun),
            WatchUi.loadResource(Rez.Drawables.WxMoon),
            WatchUi.loadResource(Rez.Drawables.WxPartly),
            WatchUi.loadResource(Rez.Drawables.WxCloud),
            WatchUi.loadResource(Rez.Drawables.WxFog),
            WatchUi.loadResource(Rez.Drawables.WxRain),
            WatchUi.loadResource(Rez.Drawables.WxSnow),
            WatchUi.loadResource(Rez.Drawables.WxStorm)
        ];
    }

    // Al levantar la muñeca: segundos y tarjetas cada 3 s durante unos 10 s.
    function onExitSleep() {
        mAwake = true;
        mWakeAt = Time.now().value();
        WatchUi.requestUpdate();
    }

    function onEnterSleep() {
        mAwake = false;
        WatchUi.requestUpdate();
    }

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    function onUpdate(dc) {
        var cx = 120;
        var now = Time.now();
        var info = Gregorian.info(now, Time.FORMAT_SHORT);
        var clock = System.getClockTime();
        var am = ActivityMonitor.getInfo();
        var ds = System.getDeviceSettings();
        var battery = System.getSystemStats().battery.toNumber();

        F5Night.update();
        updateLocation(now);
        shareNight();

        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();

        // Anillos: pasos a la izquierda (de abajo arriba), batería a la derecha.
        var steps = (am != null && am.steps != null) ? am.steps : 0;
        var goal = (am != null && am.stepGoal != null && am.stepGoal > 0) ? am.stepGoal : 10000;
        drawRings(dc, steps.toFloat() / goal, battery);

        // Luna y, a su lado, el símbolo del signo por el que pasa (en dorado si es el signo natal que elijas; -1 = ninguno).
        var ph = F5Astro.moonPhase(now.value());
        var sign = F5Astro.moonSign(now.value());
        var zch = (97 + sign).toChar().toString();
        var mr = F5Layout.MOON_R;
        var gw = 2 * mr + 1 + F5Layout.ZOD_GAP + dc.getTextWidthInPixels(zch, fZod);
        var mx = cx - gw / 2 + mr;
        drawMoon(dc, mx, F5Layout.MOON_Y, mr, ph);
        text(dc, mx + mr + 1 + F5Layout.ZOD_GAP, F5Layout.ZOD_Y, fZod, zch, sign == -1 ? C_GOLD : C_SKY, // -1: pon aquí tu signo natal (0 Aries … 11 Piscis)
            Graphics.TEXT_JUSTIFY_LEFT);

        // Fecha y hora
        text(dc, cx, F5Layout.DATE_Y, fSmall,
            mDays[info.day_of_week - 1] + " " + info.day + " " + mMonths[info.month - 1],
            C_GOLD, Graphics.TEXT_JUSTIFY_CENTER);
        var hh = clock.hour;
        if (!ds.is24Hour) {
            hh = hh % 12;
            if (hh == 0) {
                hh = 12;
            }
        }
        text(dc, cx, F5Layout.TIME_Y, fTime, hh.toString() + ":" + clock.min.format("%02d"),
            C_WHITE, Graphics.TEXT_JUSTIFY_CENTER);

        // Línea del medio
        var card = currentCard(clock, now, ph);
        text(dc, cx, F5Layout.STATUS_Y, fSmall, card[0], card[1], Graphics.TEXT_JUSTIFY_CENTER);

        // Fila 1: pulso, pasos, calorías
        var kcal = (am != null && am.calories != null) ? am.calories : 0;
        drawStat(dc, cx - F5Layout.ROW1_DX, iHeart, heartRate());
        drawStat(dc, cx, iSteps, thousands(steps));
        drawStat(dc, cx + F5Layout.ROW1_DX, iFlame, thousands(kcal));

        // Fila 2: tiempo, minutos de intensidad de la semana, notificaciones (gris sin móvil)
        var wr = weatherRow();
        var en = energyValue();
        var enTxt = "--";
        var enCol = C_GRAY;
        if (en != null) {
            enTxt = en.toString();
            enCol = en >= 60 ? C_GREEN : (en >= 30 ? C_YELLOW : C_RED);
        }
        drawSmallStat(dc, cx - F5Layout.ROW2_DX, wr[0], wr[1], C_WHITE);
        drawSmallStat(dc, cx, iBolt, enTxt, enCol);
        drawSmallStat(dc, cx + F5Layout.ROW2_DX, iBell, ds.notificationCount.toString(),
            ds.phoneConnected ? C_WHITE : C_DIM);

        // Fila 3: salida y puesta de sol (grupo centrado)
        updateSun(info);
        var sr = hm(mSunrise);
        var ss = hm(mSunset);
        var w1 = dc.getTextWidthInPixels(sr, fXs);
        var w2 = dc.getTextWidthInPixels(ss, fXs);
        var left = cx - (F5Layout.ICON_GAP + w1 + F5Layout.SUN_GAP + F5Layout.ICON_GAP + w2) / 2;
        dc.drawBitmap(left, F5Layout.ROW3_ICON_Y, iSunUp);
        text(dc, left + F5Layout.ICON_GAP, F5Layout.ROW3_Y, fXs, sr, C_GOLD, Graphics.TEXT_JUSTIFY_LEFT);
        var left2 = left + F5Layout.ICON_GAP + w1 + F5Layout.SUN_GAP;
        dc.drawBitmap(left2, F5Layout.ROW3_ICON_Y, iSunDown);
        text(dc, left2 + F5Layout.ICON_GAP, F5Layout.ROW3_Y, fXs, ss, C_GOLD, Graphics.TEXT_JUSTIFY_LEFT);

        // Fila 4: bluetooth y batería
        var bt = battery.toString() + "%";
        var left4 = cx - (F5Layout.ICON_GAP + dc.getTextWidthInPixels(bt, fXs)) / 2;
        if (ds.phoneConnected) {
            dc.drawBitmap(left4, F5Layout.ROW4_ICON_Y, iBt);
        }
        text(dc, left4 + F5Layout.ICON_GAP, F5Layout.ROW4_Y, fXs, bt, battery > 20 ? C_GOLD : C_RED,
            Graphics.TEXT_JUSTIFY_LEFT);

        // Segundos: punto blanco que recorre el borde (solo con la muñeca levantada)
        if (mAwake) {
            var a = Math.toRadians(90 - clock.sec * 6);
            var sx = Math.round(120 + F5Layout.SEC_R * Math.cos(a)).toNumber();
            var sy = Math.round(120 - F5Layout.SEC_R * Math.sin(a)).toNumber();
            dc.setColor(C_WHITE, Graphics.COLOR_TRANSPARENT);
            dc.fillCircle(sx, sy, F5Layout.SEC_DOT);
        }
    }

    function drawRings(dc, sp, battery) {
        var r = F5Layout.RING_R;
        dc.setPenWidth(F5Layout.RING_PEN);
        dc.setColor(0x000055, Graphics.COLOR_TRANSPARENT);
        dc.drawArc(120, 120, r, Graphics.ARC_CLOCKWISE, 240, 120);
        dc.setColor(0x555500, Graphics.COLOR_TRANSPARENT);
        dc.drawArc(120, 120, r, Graphics.ARC_COUNTER_CLOCKWISE, 300, 60);
        if (sp > 1) {
            sp = 1.0;
        }
        var stepDeg = (120 * sp).toNumber();
        if (stepDeg >= 2) {
            dc.setColor(sp >= 1 ? 0x00FF55 : 0x00AAFF, Graphics.COLOR_TRANSPARENT);
            dc.drawArc(120, 120, r, Graphics.ARC_CLOCKWISE, 240, 240 - stepDeg);
        }
        var batDeg = (120 * battery / 100.0).toNumber();
        if (batDeg >= 2) {
            dc.setColor(battery > 20 ? C_GOLD : C_RED, Graphics.COLOR_TRANSPARENT);
            dc.drawArc(120, 120, r, Graphics.ARC_COUNTER_CLOCKWISE, 300, (300 + batDeg) % 360);
        }
        dc.setPenWidth(1);
    }

    // Disco lunar: parte iluminada como polígono (limbo + terminador elíptico).
    function drawMoon(dc, cx, cy, r, phase) {
        dc.setColor(C_DIM, Graphics.COLOR_TRANSPARENT);
        dc.fillCircle(cx, cy, r);
        var k = Math.cos(phase * 2 * Math.PI);
        var sgn = phase < 0.5 ? 1 : -1;
        var pts = [];
        for (var i = 0; i <= 16; i++) {
            var a = Math.PI / 2 - Math.PI * i / 16;
            pts.add([cx + sgn * r * Math.cos(a), cy - r * Math.sin(a)]);
        }
        for (var i = 0; i <= 16; i++) {
            var a = -Math.PI / 2 + Math.PI * i / 16;
            pts.add([cx + sgn * k * r * Math.cos(a), cy - r * Math.sin(a)]);
        }
        dc.setColor(C_MOON, Graphics.COLOR_TRANSPARENT);
        dc.fillPolygon(pts);
    }

    function drawStat(dc, x, icon, val) {
        dc.drawBitmap(x - 7, F5Layout.ROW1_ICON_Y, icon);
        text(dc, x, F5Layout.ROW1_Y, fMed, val, C_WHITE, Graphics.TEXT_JUSTIFY_CENTER);
    }

    function drawSmallStat(dc, x, icon, val, color) {
        var left = x - (F5Layout.ICON_GAP + dc.getTextWidthInPixels(val, fXs)) / 2;
        dc.drawBitmap(left, F5Layout.ROW2_ICON_Y, icon);
        text(dc, left + F5Layout.ICON_GAP, F5Layout.ROW2_Y, fXs, val, color, Graphics.TEXT_JUSTIFY_LEFT);
    }

    // ------------------------------------------------------------------ tarjetas

    function currentCard(clock, now, phase) {
        var minOfDay = clock.hour * 60 + clock.min;
        if (mCards == null || mCardsMin != minOfDay) {
            mCards = buildCards(minOfDay, phase);
            mCardsMin = minOfDay;
        }
        var idx = clock.min;
        if (mAwake) {
            idx += (now.value() - mWakeAt) / 3;
        }
        return mCards[idx % mCards.size()];
    }

    function buildCards(nowMin, phase) {
        var bed = prop("bedHour", 1) * 60 + prop("bedMinute", 0);
        var wake = prop("wakeHour", 8) * 60 + prop("wakeMinute", 20);
        var until = (bed - nowMin + 1440) % 1440;
        if (between(nowMin, bed, wake)) {
            return [["HORA DE DORMIR", C_RED]];
        }
        // Pendiente con hora: manda él desde 15 min antes hasta 30 min después; luego entra en la rueda.
        var pc = pendCard(nowMin);
        if (pc != null && pc[2]) {
            return [[pc[0], pc[1]]];
        }
        if (until > 0 && until <= 30) {
            return [[bedText(until), C_ORANGE]];
        }
        var cards = [];
        if (pc != null) {
            cards.add([pc[0], pc[1]]);
        }
        var pr = pressure();
        if (pr != null && pr[1] != null && pr[1] <= -4.0) {
            cards.add(["¡TORMENTA! " + pr[1].format("%.0f") + " HPA EN 3 H", C_RED]);
        }
        if (until > 0 && until <= 180) {
            cards.add([bedText(until), C_GOLD]);
        }
        if (nowMin < 14 * 60) {
            var nc = nightCard();
            if (nc != null) {
                cards.add(nc);
            }
        }
        var en = energyValue();
        if (en != null) {
            cards.add(["ENERGÍA " + en.toString() + " DE 100", en >= 60 ? C_GREEN : (en >= 30 ? C_YELLOW : C_RED)]);
        }
        // Métricas tipo Whoop calculadas en la nube (Supabase), con su consejo del día
        var mt = metrics();
        if (mt != null) {
            var con = mt["con"];
            if (con != null && nowMin < 21 * 60) {
                cards.add([con, C_GOLD]);
            }
            var sn = mt["sn"];
            if (sn != null && nowMin < 14 * 60) {
                var ts = "SUEÑO " + sn.toString();
                var deuda = mt["deuda"];
                if (deuda != null && deuda >= 30) {
                    ts += " · DEUDA " + hmShort(deuda);
                }
                cards.add([ts, sn >= 80 ? C_GREEN : (sn >= 60 ? C_YELLOW : C_RED)]);
            }
            var rec = mt["rec"];
            if (rec != null) {
                cards.add(["RECUPERADO " + rec.toString() + "%", rec >= 67 ? C_GREEN : (rec >= 34 ? C_YELLOW : C_RED)]);
            }
            var esf = mt["esf"];
            if (esf != null && nowMin >= 12 * 60) {
                cards.add(["ESFUERZO " + fmt1(esf) + " DE 21", C_ORANGE]);
            }
            var agua = mt["agua"];
            if (agua instanceof Lang.Array && agua.size() == 2 && agua[0] != null && agua[1] != null) {
                cards.add(["AGUA " + litros(agua[0]) + " DE " + litros(agua[1]) + " L", C_SKY]);
            }
            var sem = mt["sem"];
            if (sem instanceof Lang.Array && sem.size() == 5
                && Gregorian.info(Time.now(), Time.FORMAT_SHORT).day_of_week == 1) {
                var nTrain = 0;
                for (var k = 0; k < 3; k++) {
                    if (sem[k] != null) {
                        nTrain += sem[k];
                    }
                }
                cards.add(["SEMANA: " + nTrain.toString() + (nTrain == 1 ? " ENTRENO" : " ENTRENOS"), C_GOLD]);
                if (sem[3] != null) {
                    cards.add(["SUEÑO MEDIO " + hmShort(sem[3]), C_GOLD]);
                }
                if (sem[4] != null) {
                    cards.add(["PASOS MEDIOS " + thousands(sem[4]), C_GOLD]);
                }
            }
        }
        var am = ActivityMonitor.getInfo();
        if (am != null && am.activeMinutesWeek != null && am.activeMinutesWeek.total != null) {
            cards.add(["INTENSIDAD " + am.activeMinutesWeek.total.toString() + " MIN", C_YELLOW]);
        }
        var wc = weatherCard();
        if (wc != null) {
            cards.add(wc);
        }
        var alt = altitude();
        if (alt != null && alt > 800) {
            cards.add(["ALTITUD " + Math.round(alt).toNumber().toString() + " M", C_GRAY]);
        }
        if (pr != null && pr[1] != null && (pr[1] >= 1.0 || pr[1] <= -1.0)) {
            var t = Math.round(pr[0]).toNumber().toString() + " HPA";
            if (pr[1] != null) {
                if (pr[1] >= 1.0) {
                    t += " · SUBE " + pr[1].format("%.0f");
                } else if (pr[1] <= -1.0) {
                    t += " · BAJA " + (-pr[1]).format("%.0f");
                } else {
                    t += " · ESTABLE";
                }
            }
            cards.add([t, C_SKY]);
        }
        cards.add([F5Astro.nextMoonText(phase), C_MOON]);
        return cards;
    }

    function bedText(until) {
        return "A LA CAMA EN " + (until / 60).toString() + ":" + (until % 60).format("%02d");
    }

    // ¿Está nowMin entre a (incluido) y b (excluido), contando el paso por medianoche?
    function between(nowMin, a, b) {
        if (a <= b) {
            return nowMin >= a && nowMin < b;
        }
        return nowMin >= a || nowMin < b;
    }

    // El servicio en segundo plano no puede leer el almacén: le dejamos el pulso de la noche en una propiedad.
    (:typecheck(false))
    function shareNight() {
        var n = F5Night.lastNight();
        if (n == null) {
            return;
        }
        var old = Application.Properties.getValue("nightHr");
        if (old == null || old != n) {
            Application.Properties.setValue("nightHr", n);
        }
    }

    // Pulso de la noche frente a su normal.
    function nightCard() {
        var night = F5Night.lastNight();
        if (night == null) {
            return null;
        }
        var base = F5Night.baseline();
        if (base[1] < 3) {
            return ["NOCHE " + night + " · BASE " + base[1] + "/3", C_GRAY];
        }
        var d = night - base[0];
        if (d >= 5) {
            return ["NOCHE " + night + " · MUY CARGADO", C_RED];
        }
        if (d >= 2) {
            return ["NOCHE " + night + " · CARGADO", C_YELLOW];
        }
        return ["NOCHE " + night + " · FRESCO", C_GREEN];
    }

    // [icono, «12°»] para la fila 2.
    (:typecheck(false))
    function weatherRow() {
        var wx = weather();
        if (wx == null) {
            return [iWx[3], "--°"];
        }
        return [iWx[wxIndex(wx[1], wx[2])], Math.round(wx[0]).toNumber().toString() + "°"];
    }

    (:typecheck(false))
    function weatherCard() {
        var wx = weather();
        if (wx == null || wx[3] == null || wx[4] == null) {
            return null;
        }
        var t = Math.round(wx[3]).toNumber().toString() + "°/" + Math.round(wx[4]).toNumber().toString() + "°";
        var pop = wx[5];
        if (pop != null && pop >= 20) {
            t += " · LLUVIA " + Math.round(pop).toNumber().toString() + "%";
        } else {
            t += " · SIN LLUVIA";
        }
        return [t, C_WHITE];
    }

    // ------------------------------------------------------------------ datos

    // [temp, código, de día, máx, mín, prob. lluvia] si tiene menos de 3 h; si no, null.
    (:typecheck(false))
    function weather() {
        var wx = Application.Storage.getValue("wx");
        var at = Application.Storage.getValue("wxAt");
        if (!(wx instanceof Lang.Array) || at == null || wx.size() < 6 || wx[0] == null || wx[1] == null) {
            return null;
        }
        if (Time.now().value() - at > 3 * 3600) {
            return null;
        }
        return wx;
    }

    // Código WMO de Open-Meteo -> icono (0 sol, 1 luna, 2 nubes y claros, 3 nubes, 4 niebla,
    // 5 lluvia, 6 nieve, 7 tormenta).
    (:typecheck(false))
    function wxIndex(code, isDay) {
        if (code == null) {
            return 3;
        }
        var c = code.toNumber();
        if (c == 0) {
            return (isDay != null && isDay.toNumber() == 0) ? 1 : 0;
        }
        if (c <= 2) {
            return 2;
        }
        if (c == 3) {
            return 3;
        }
        if (c == 45 || c == 48) {
            return 4;
        }
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) {
            return 6;
        }
        if (c >= 95) {
            return 7;
        }
        if (c >= 51) {
            return 5;
        }
        return 3;
    }

    // [texto, color, exclusiva] del próximo pendiente con hora, o null.
    (:typecheck(false))
    function pendCard(nowMin) {
        var mt = metrics();
        if (mt == null) {
            return null;
        }
        var p = mt["pend"];
        if (!(p instanceof Lang.Array) || p.size() != 2 || p[0] == null || p[1] == null) {
            return null;
        }
        var at = p[1];
        if (nowMin < at - 15 || nowMin > at + 120) {
            return null;
        }
        var t = p[0];
        if (t.length() > 14) {
            var cut = t.substring(0, 14);
            var sp = null;
            for (var i = 13; i > 5; i--) {
                if (cut.substring(i, i + 1).equals(" ")) {
                    sp = i;
                    break;
                }
            }
            t = sp != null ? cut.substring(0, sp) : cut;
        }
        return [hm(at) + " · " + t, C_ORANGE, nowMin <= at + 30];
    }

    // Lo último que llegó de la nube (diccionario) si tiene menos de 3 h.
    (:typecheck(false))
    function metrics() {
        var e = Application.Storage.getValue("energy");
        var at = Application.Storage.getValue("energyAt");
        if (!(e instanceof Lang.Dictionary) || at == null || Time.now().value() - at > 3 * 3600) {
            return null;
        }
        return e;
    }

    // 205 -> «3H25»
    function hmShort(min) {
        var m = min.toNumber();
        return (m / 60).toString() + "H" + (m % 60).format("%02d");
    }

    // 12.4 -> «12,4»
    function fmt1(x) {
        var d = Math.round(x * 10).toNumber();
        return (d / 10).toString() + "," + (d % 10).toString();
    }

    // 1500 -> «1,5»; 2000 -> «2»
    function litros(ml) {
        var d = Math.round(ml / 100.0).toNumber();
        return d % 10 == 0 ? (d / 10).toString() : (d / 10).toString() + "," + (d % 10).toString();
    }

    (:typecheck(false))
    function energyValue() {
        var e = Application.Storage.getValue("energy");
        var at = Application.Storage.getValue("energyAt");
        if (!(e instanceof Lang.Dictionary) || at == null || Time.now().value() - at > 3 * 3600) {
            return null;
        }
        return e["energia"];
    }

    // Altitud del barómetro (m) o null.
    (:typecheck(false))
    function altitude() {
        if ((Toybox has :SensorHistory) && (SensorHistory has :getElevationHistory)) {
            var it = SensorHistory.getElevationHistory({:period => 1});
            if (it != null) {
                var s = it.next();
                if (s != null && s.data != null) {
                    return s.data;
                }
            }
        }
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.altitude != null) {
            return ai.altitude;
        }
        return null;
    }

    // [presión a nivel del mar (hPa), cambio en 3 h (hPa) o null] o null.
    // El cambio descuenta lo que has subido o bajado: subir un puerto no es una tormenta.
    (:typecheck(false))
    function pressure() {
        if (!(Toybox has :SensorHistory) || !(SensorHistory has :getPressureHistory)) {
            return null;
        }
        var it = SensorHistory.getPressureHistory({:period => new Time.Duration(3 * 3600)});
        if (it == null) {
            return null;
        }
        var newest = null;
        var newestT = 0;
        var oldest = null;
        var oldestT = 0;
        var s = it.next();
        while (s != null) {
            if (s.data != null && s.when != null) {
                if (newest == null) {
                    newest = s.data / 100.0;
                    newestT = s.when.value();
                }
                oldest = s.data / 100.0;
                oldestT = s.when.value();
            }
            s = it.next();
        }
        if (newest == null) {
            return null;
        }
        if (newestT < oldestT) {
            var tp = newest;
            newest = oldest;
            oldest = tp;
            var tt = newestT;
            newestT = oldestT;
            oldestT = tt;
        }
        var altNow = altitude();
        // El historial puede venir en presión de la estación o ya al nivel del mar: se mira a cuál se parece.
        var station = altNow != null && altNow > -500 && altNow < 9000
            && absf(newest - 1013.25 * Math.pow(1 - 0.0000225577 * altNow, 5.25588)) < absf(newest - 1013.25);
        var p = station ? seaLevel(newest, altNow) : newest;
        var diff = null;
        if (oldest != null && newestT - oldestT >= 7200) {
            if (station) {
                var altThen = altitudeAt(oldestT);
                diff = p - seaLevel(oldest, altThen != null ? altThen : altNow);
            } else {
                diff = newest - oldest;
            }
        }
        return [p, diff];
    }

    function seaLevel(hpa, alt) {
        return hpa * Math.pow(1 - 0.0000225577 * alt, -5.25588);
    }

    // Altitud del barómetro en un momento de las últimas horas (la muestra más cercana) o null.
    (:typecheck(false))
    function altitudeAt(t) {
        if (!(Toybox has :SensorHistory) || !(SensorHistory has :getElevationHistory)) {
            return null;
        }
        var it = SensorHistory.getElevationHistory({:period => new Time.Duration(4 * 3600)});
        if (it == null) {
            return null;
        }
        var best = null;
        var bestD = 0;
        var s = it.next();
        while (s != null) {
            if (s.data != null && s.when != null) {
                var d = absf(s.when.value() - t);
                if (best == null || d < bestD) {
                    best = s.data;
                    bestD = d;
                }
            }
            s = it.next();
        }
        return bestD <= 600 ? best : null;
    }

    function heartRate() {
        var ai = Activity.getActivityInfo();
        if (ai != null && ai.currentHeartRate != null) {
            return ai.currentHeartRate.toString();
        }
        var it = ActivityMonitor.getHeartRateHistory(1, true);
        if (it != null) {
            var s = it.next();
            if (s != null && s.heartRate != null && s.heartRate != ActivityMonitor.INVALID_HR_SAMPLE) {
                return s.heartRate.toString();
            }
        }
        return "--";
    }

    (:typecheck(false))
    function prop(key, def) {
        var v = Application.Properties.getValue(key);
        if (v instanceof Lang.Number) {
            return v;
        }
        if (v instanceof Lang.Float || v instanceof Lang.Double) {
            return v.toNumber();
        }
        return def;
    }

    (:typecheck(false))
    function propF(key, def) {
        var v = Application.Properties.getValue(key);
        if (v instanceof Lang.Number || v instanceof Lang.Float || v instanceof Lang.Double) {
            return v.toFloat();
        }
        return def;
    }

    // Si el reloj conoce su posición GPS, la guarda (como mucho una vez por hora) para el tiempo y el sol.
    (:typecheck(false))
    function updateLocation(now) {
        if (now.value() - mLocAt < 3600) {
            return;
        }
        mLocAt = now.value();
        var ai = Activity.getActivityInfo();
        if (ai == null || ai.currentLocation == null) {
            return;
        }
        var deg = ai.currentLocation.toDegrees();
        var lat = deg[0].toFloat();
        var lon = deg[1].toFloat();
        if (absf(lat) > 90 || absf(lon) > 180 || (absf(lat) < 0.01 && absf(lon) < 0.01)) {
            return;
        }
        var oldLat = propF("lat", 40.4168);
        var oldLon = propF("lon", -3.7038);
        if (absf(lat - oldLat) > 0.05 || absf(lon - oldLon) > 0.05) {
            Application.Properties.setValue("lat", lat);
            Application.Properties.setValue("lon", lon);
            mSunDay = -1;
        }
    }

    // Salida y puesta de sol: se calculan una vez al día (o al cambiar de sitio).
    function updateSun(info) {
        if (mSunDay == info.day) {
            return;
        }
        var lat = propF("lat", 40.4168);
        var lon = propF("lon", -3.7038);
        var now = Time.now();
        var u = Gregorian.utcInfo(now, Time.FORMAT_SHORT);
        var off = (info.hour * 60 + info.min) - (u.hour * 60 + u.min);
        if (off > 720) {
            off -= 1440;
        } else if (off < -720) {
            off += 1440;
        }
        var n = F5Astro.dayOfYear(info.year, info.month, info.day);
        mSunrise = F5Astro.sunEvent(lat, lon, n, true, off);
        mSunset = F5Astro.sunEvent(lat, lon, n, false, off);
        mSunDay = info.day;
    }

    function absf(x) {
        return x < 0 ? -x : x;
    }

    function hm(mins) {
        if (mins == null) {
            return "--:--";
        }
        return (mins / 60).toString() + ":" + (mins % 60).format("%02d");
    }

    function thousands(n) {
        var s = n.toString();
        var out = "";
        var c = 0;
        for (var i = s.length() - 1; i >= 0; i--) {
            out = s.substring(i, i + 1) + out;
            c++;
            if (c % 3 == 0 && i > 0) {
                out = "." + out;
            }
        }
        return out;
    }
}
