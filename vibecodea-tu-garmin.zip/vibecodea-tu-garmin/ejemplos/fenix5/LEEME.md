# Ejemplos probados en un fēnix 5

Son las apps de un proyecto real, con los datos personales quitados. Funcionan en un fēnix 5 (pantalla redonda de 240×240, MIP de 64 colores, Connect IQ 3.1). En otro reloj sirven de referencia: la lógica se reutiliza tal cual y el dibujo hay que adaptarlo.

Todas compilan con el SDK 9.3 para el fēnix 5. `vfc/` compila también para el Forerunner 265 y el Venu 3 con solo añadirlos a su `manifest.xml`.

## Antes de usar uno

1. **Id nuevo.** En `manifest.xml`, cambia el `id` de `<iq:application>` por uno tuyo (32 caracteres hexadecimales).
2. **Tu reloj.** Añade `<iq:product id="…"/>` con el id de tu modelo, y quita `fenix5` si no lo usas.
3. **Tamaños.** Las posiciones están pensadas para 240×240. Las de las esferas y varias apps salen de los archivos `*Layout.mc`, que generan los scripts de `herramientas/`. Para otra resolución, recalcula esas posiciones o pásalas a fracciones del ancho y el alto.
4. **Fuentes.** Las de `resources/fonts` están dibujadas para 240×240. Para otro tamaño, genera las tuyas con `scripts/generar_fuente.py`.
5. **Servidor.** Las apps que mandan o piden datos tienen dos constantes, `URL` y `TOKEN`, con `TU-PROYECTO` y `CAMBIA-ESTE-TOKEN`. Sin servidor siguen funcionando; solo fallan, sin hacer nada, las peticiones a la nube. Son: `esfera` y `analogica` (en `F5Service.mc`), `agua`, `hoy`, `gym`, `padel`, `intervalos` y `escalada`.

## Qué hay

| Carpeta | Tipo | Notas |
|---|---|---|
| `esfera/` | Esfera | Línea del medio que rota, luna con su signo, pulso de la noche, tiempo de Open-Meteo, anillos de pasos y batería. Ajustes de hora de dormir en `resources/settings/properties.xml` |
| `analogica/` | Esfera | Mismos datos que `esfera/`, con agujas y subesferas |
| `vfc/` | App | Usa fuentes del sistema y posiciones relativas: es la más fácil de llevar a otro reloj |
| `gym/` | App | Fuerza por series; descanso por defecto de 90 s |
| `padel/` | App | Marcador; el motor está en `PadelScore.mc` y tiene un gemelo en Python con pruebas en `herramientas/` |
| `intervalos/` | App | Seis modos guardados con sus valores |
| `escalada/` | App | Graba como escalada en roca, con campos FIT propios |
| `montana/` | Widget | Gráficas de 4 horas de presión, altitud y temperatura |
| `agua/` | Widget | Botella de 500 ml y objetivo de 2 l por defecto |
| `hoy/` | Widget | Necesita el servidor de `nube/` |
| `volver/` | App | Coche, tienda, moto o sitio |
| `nube/` | Servidor | SQL y función de Supabase; ver `references/nube-opcional.md` |
| `herramientas/` | Python | Vistas previas, comprobación de que nada se pisa y generador de fuentes e iconos |

## Herramientas

Necesitan Python 3 y Pillow (`pip install pillow`).

- `python3 preview.py` dibuja la esfera en varios casos (los peores incluidos), comprueba que nada se sale del círculo ni se pisa, y escribe `esfera/source/F5Layout.mc` con las posiciones. Los demás `*_preview.py` hacen lo mismo con cada app.
- `python3 generar_recursos.py` crea las fuentes y los iconos de `herramientas/assets`. Usa la fuente Inter Display; cambia las rutas del principio del archivo por las de la fuente que tengas.
- `python3 test_padel_motor.py` prueba las reglas del marcador de pádel.
