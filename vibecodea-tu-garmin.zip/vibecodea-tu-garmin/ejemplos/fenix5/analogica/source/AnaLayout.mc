// GENERADO por analogica_preview.py: no editar a mano.
module AnaLayout {
    const TICK_OUT = 118;
    const TICK_IN = 106;
    const TICK_MAIN_IN = 100;
    const TICK_MIN_IN = 114;
    const TICK_PEN = 3;
    const TICK_MAIN_PEN = 5;
    const MOON_Y = 31;
    const MOON_R = 7;
    const ZOD_Y = 23;
    const ZOD_GAP = 4;
    const DATE_Y = 42;
    const SUB_L_X = 64;
    const SUB_R_X = 176;
    const SUB_Y = 120;
    const SUB_R = 22;
    const SUB_PEN = 3;
    const SUB_NUM_Y = 107;
    const SUB_ICON_Y = 132;
    const STATUS_Y = 148;
    const STATUS_MAXW = 190;
    const ROW_Y = 167;
    const ROW_ICON_Y = 171;
    const BOT_Y = 186;
    const BOT_ICON_Y = 190;
    const ICON_GAP = 16;
    const PAIR_GAP = 12;
    const HOUR_LEN = 58;
    const HOUR_W = 5;
    const MIN_LEN = 90;
    const MIN_W = 4;
    const HAND_TAIL = 12;
    const SEC_LEN = 102;
    const SEC_TAIL = 20;
    const CAP_R = 5;
}
