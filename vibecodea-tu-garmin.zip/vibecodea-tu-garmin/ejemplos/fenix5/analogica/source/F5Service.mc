using Toybox.ActivityMonitor;
using Toybox.Application;
using Toybox.Background;
using Toybox.Communications;
using Toybox.Lang;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;

// Servicio en segundo plano, cada 30 min, a través del móvil (Garmin Connect):
// 1) el tiempo de Open-Meteo (gratis y sin clave) para la ubicación guardada;
// 2) manda el resumen del día a su Supabase personal (función «reloj»);
// 3) recoge de allí la «Energía» (estimación tipo Body Battery calculada con la API de Garmin).
// Devuelve {"wx": [temp, código, de día, máx, mín, prob. lluvia], "en": {"energia": n, ...}}.
(:background)
class F5Service extends System.ServiceDelegate {

    const URL = "https://TU-PROYECTO.supabase.co/functions/v1/reloj";
    const TOKEN = "CAMBIA-ESTE-TOKEN";

    hidden var mOut;

    function initialize() {
        ServiceDelegate.initialize();
        mOut = {};
    }

    (:typecheck(false))
    function onTemporalEvent() {
        var lat = Application.Properties.getValue("lat");
        var lon = Application.Properties.getValue("lon");
        if (lat == null) {
            lat = 40.4168;
        }
        if (lon == null) {
            lon = -3.7038;
        }
        Communications.makeWebRequest(
            "https://api.open-meteo.com/v1/forecast",
            {
                "latitude" => lat.format("%.3f"),
                "longitude" => lon.format("%.3f"),
                "current" => "temperature_2m,weather_code,is_day",
                "daily" => "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
                "forecast_days" => "1",
                "timezone" => "auto"
            },
            {
                :method => Communications.HTTP_REQUEST_METHOD_GET,
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onWeather)
        );
    }

    (:typecheck(false))
    function onWeather(code, data) {
        if (code == 200 && data != null) {
            var cur = data["current"];
            var day = data["daily"];
            if (cur != null && day != null) {
                mOut["wx"] = [cur["temperature_2m"], cur["weather_code"], cur["is_day"],
                              first(day["temperature_2m_max"]), first(day["temperature_2m_min"]),
                              first(day["precipitation_probability_max"])];
            }
        }
        postDay();
    }

    // Resumen del día para la nube. Todo lo que no esté disponible se deja fuera.
    (:typecheck(false))
    function postDay() {
        var d = {"tipo" => "dia"};
        var i = Gregorian.info(Time.now(), Time.FORMAT_SHORT);
        d["dia"] = i.year.format("%04d") + "-" + i.month.format("%02d") + "-" + i.day.format("%02d");
        if (Toybox has :ActivityMonitor) {
            var am = ActivityMonitor.getInfo();
            if (am != null) {
                d["pasos"] = am.steps;
                d["objetivo"] = am.stepGoal;
                d["kcal"] = am.calories;
                d["pisos"] = am.floorsClimbed;
                if (am.activeMinutesWeek != null) {
                    d["intensidad"] = am.activeMinutesWeek.total;
                }
            }
        }
        d["bateria"] = System.getSystemStats().battery.toNumber();
        var night = Application.Properties.getValue("nightHr");
        if (night != null && night > 0) {
            d["noche"] = night;
        }
        var wx = mOut["wx"];
        if (wx != null) {
            d["temp"] = wx[0];
            d["tmax"] = wx[3];
            d["tmin"] = wx[4];
            d["lluvia"] = wx[5];
        }
        var lat = Application.Properties.getValue("lat");
        var lon = Application.Properties.getValue("lon");
        if (lat != null && lon != null) {
            d["lat"] = (lat * 100).toNumber() / 100.0;
            d["lon"] = (lon * 100).toNumber() / 100.0;
        }
        Communications.makeWebRequest(URL, d,
            {
                :method => Communications.HTTP_REQUEST_METHOD_POST,
                :headers => {
                    "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                    "x-reloj-token" => TOKEN
                },
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onPosted));
    }

    (:typecheck(false))
    function onPosted(code, data) {
        Communications.makeWebRequest(URL + "/energia", null,
            {
                :method => Communications.HTTP_REQUEST_METHOD_GET,
                :headers => {"x-reloj-token" => TOKEN},
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onEnergy));
    }

    (:typecheck(false))
    function onEnergy(code, data) {
        if (code == 200 && data != null && data["energia"] != null) {
            mOut["en"] = data;
        }
        Background.exit(mOut);
    }

    (:typecheck(false))
    function first(arr) {
        if (arr == null || arr.size() == 0) {
            return null;
        }
        return arr[0];
    }
}
