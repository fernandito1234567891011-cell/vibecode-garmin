using Toybox.Application;
using Toybox.Background;
using Toybox.Lang;
using Toybox.System;
using Toybox.Time;
using Toybox.WatchUi;

// Esfera F5+ para el fēnix 5.
// Todo se calcula en el reloj salvo el tiempo (Open-Meteo) y, en la fase 2, la «Energía»:
// esas dos cosas llegan cada 30 min a través del móvil (el reloj no tiene internet propio).
(:background)
class F5App extends Application.AppBase {

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        Background.registerForTemporalEvent(new Time.Duration(30 * 60));
        return [new F5View()];
    }

    function getServiceDelegate() {
        return [new F5Service()];
    }

    (:typecheck(false))
    function onBackgroundData(data) {
        if (data instanceof Lang.Dictionary) {
            var now = Time.now().value();
            var wx = data["wx"];
            if (wx != null) {
                Application.Storage.setValue("wx", wx);
                Application.Storage.setValue("wxAt", now);
            }
            var en = data["en"];
            if (en != null) {
                Application.Storage.setValue("energy", en);
                Application.Storage.setValue("energyAt", now);
            }
        }
        WatchUi.requestUpdate();
    }

    function onSettingsChanged() {
        WatchUi.requestUpdate();
    }
}
