using Toybox.ActivityMonitor;
using Toybox.Application;
using Toybox.Lang;
using Toybox.Math;
using Toybox.Time;
using Toybox.Time.Gregorian;

// Pulso de la noche: la media de 30 minutos más baja entre las 22:00 y las 11:00.
// Es la definición de Garmin del pulso en reposo, limitada a la noche.
// El fenix 5 solo guarda unas 4 horas de pulso para las apps, así que la esfera
// lo revisa cada 10 minutos durante la noche y se queda con el valor más bajo.
module F5Night {

    const WINDOW_SECS = 1800;
    const KEEP_DAYS = 21;

    function keyOf(moment) {
        var i = Gregorian.info(moment, Time.FORMAT_SHORT);
        return i.year * 10000 + i.month * 100 + i.day;
    }

    // La noche se apunta con la fecha de la mañana en que termina.
    function nightMorning(now) {
        var info = Gregorian.info(now, Time.FORMAT_SHORT);
        var today = Time.today();
        if (info.hour >= 12) {
            return today.add(new Time.Duration(86400));
        }
        return today;
    }

    // Media de 30 min más baja dentro de la ventana de la noche, con el historial disponible.
    function scan(start, end) {
        var now = Time.now();
        var it = ActivityMonitor.getHeartRateHistory(now.subtract(start), false);
        if (it == null) {
            return null;
        }
        var vals = [];
        var times = [];
        var s = it.next();
        while (s != null) {
            var hr = s.heartRate;
            var t = s.when;
            if (hr != null && t != null && hr != ActivityMonitor.INVALID_HR_SAMPLE && hr > 25 && hr < 200) {
                var tv = t.value();
                if (tv >= start.value() && tv <= end.value()) {
                    vals.add(hr);
                    times.add(tv);
                }
            }
            s = it.next();
        }
        var n = vals.size();
        if (n < 5) {
            return null;
        }
        var best = null;
        var sum = 0;
        var j = 0;
        for (var i = 0; i < n; i++) {
            while (j < n && times[j] - times[i] < WINDOW_SECS) {
                sum += vals[j];
                j++;
            }
            var cnt = j - i;
            if (cnt >= 5 && times[j - 1] - times[i] >= 1200) {
                var avg = sum.toFloat() / cnt;
                if (best == null || avg < best) {
                    best = avg;
                }
            }
            sum -= vals[i];
        }
        return best == null ? null : Math.round(best).toNumber();
    }

    // Llamar a menudo: como mucho recalcula cada 10 minutos.
    function update() {
        var now = Time.now();
        var last = Application.Storage.getValue("nightAt") as Lang.Number or Null;
        if (last != null && now.value() - last < 600) {
            return;
        }
        Application.Storage.setValue("nightAt", now.value());
        var morning = nightMorning(now);
        var start = morning.subtract(new Time.Duration(2 * 3600));
        var end = morning.add(new Time.Duration(11 * 3600));
        if (now.value() < start.value() || now.value() > end.value() + 4 * 3600) {
            return;
        }
        var v = scan(start, end);
        if (v == null) {
            return;
        }
        var key = keyOf(morning);
        var hist = Application.Storage.getValue("nights") as Lang.Dictionary or Null;
        if (hist == null) {
            hist = {};
        }
        var old = hist[key];
        if (old == null || v < old) {
            hist[key] = v;
            trim(hist);
            Application.Storage.setValue("nights", hist);
        }
    }

    function trim(hist) {
        var keys = sortNumbers(hist.keys());
        for (var i = 0; i < keys.size() - KEEP_DAYS; i++) {
            hist.remove(keys[i]);
        }
    }

    // Pulso de la última noche (la que acabó esta mañana) o null.
    function lastNight() {
        var hist = Application.Storage.getValue("nights") as Lang.Dictionary or Null;
        if (hist == null) {
            return null;
        }
        return hist[keyOf(Time.today())];
    }

    // [mediana de las noches anteriores (máx. 14), cuántas hay]. Con menos de 3, el valor de ajustes.
    function baseline() {
        var today = keyOf(Time.today());
        var hist = Application.Storage.getValue("nights") as Lang.Dictionary or Null;
        var vals = [];
        if (hist != null) {
            var keys = sortNumbers(hist.keys());
            for (var i = keys.size() - 1; i >= 0 && vals.size() < 14; i--) {
                if (keys[i] < today) {
                    vals.add(hist[keys[i]]);
                }
            }
        }
        if (vals.size() < 3) {
            var b = Application.Properties.getValue("baseRhr");
            return [b == null ? 50 : b, vals.size()];
        }
        vals = sortNumbers(vals);
        var m = vals.size();
        var med = (m % 2 == 1) ? vals[m / 2] : (vals[m / 2 - 1] + vals[m / 2]) / 2.0;
        return [Math.round(med).toNumber(), m];
    }

    // Ordenación por inserción (listas de 21 como mucho).
    function sortNumbers(arr) {
        var a = [];
        for (var k = 0; k < arr.size(); k++) {
            a.add(arr[k]);
        }
        for (var i = 1; i < a.size(); i++) {
            var x = a[i];
            var j = i - 1;
            while (j >= 0 && a[j] > x) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = x;
        }
        return a;
    }
}
