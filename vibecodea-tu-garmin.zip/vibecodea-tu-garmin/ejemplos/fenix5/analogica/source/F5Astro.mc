using Toybox.Lang;
using Toybox.Math;

// Luna (fase y signo) y salida/puesta de sol. Todo calculado en el reloj, sin internet.
module F5Astro {

    const SYNODIC = 29.530588853;

    // Fracción de la lunación: 0 = nueva, 0.5 = llena. Referencia: luna nueva del 6-1-2000 18:14 UTC.
    function moonPhase(nowSecs) {
        var days = (nowSecs - 947182440) / 86400.0;
        var age = days - Math.floor(days / SYNODIC) * SYNODIC;
        return age / SYNODIC;
    }

    // Signo por el que pasa la Luna: 0 = Aries ... 11 = Piscis (error de 1-2 grados).
    function moonSign(nowSecs) {
        var d = (nowSecs - 946728000) / 86400.0;
        var l = 218.316 + 13.176396 * d;
        var m = Math.toRadians(134.963 + 13.064993 * d);
        var lon = l + 6.289 * Math.sin(m);
        lon = lon - Math.floor(lon / 360.0) * 360.0;
        var i = (lon / 30.0).toNumber();
        if (i < 0 || i > 11) {
            i = 0;
        }
        return i;
    }

    // Texto de la próxima luna llena o nueva («LUNA LLENA EN 4 DÍAS», «LUNA NUEVA HOY»…).
    function nextMoonText(phase) {
        var toFull = (phase <= 0.5 ? 0.5 - phase : 1.5 - phase) * SYNODIC;
        var toNew = (1.0 - phase) * SYNODIC;
        var sinceFull = (phase - 0.5) * SYNODIC;
        var sinceNew = phase * SYNODIC;
        if ((sinceFull >= 0 && sinceFull < 0.75) || toFull < 0.75) {
            return "LUNA LLENA HOY";
        }
        if (sinceNew < 0.75 || toNew < 0.75) {
            return "LUNA NUEVA HOY";
        }
        var full = toFull < toNew;
        var d = Math.round(full ? toFull : toNew).toNumber();
        var what = full ? "LUNA LLENA" : "LUNA NUEVA";
        if (d <= 1) {
            return what + " MAÑANA";
        }
        return what + " EN " + d.toString() + " DÍAS";
    }

    function sinD(a) { return Math.sin(Math.toRadians(a)); }
    function cosD(a) { return Math.cos(Math.toRadians(a)); }

    function norm(a, m) {
        return a - Math.floor(a / m) * m;
    }

    // Minutos locales de la salida (rising = true) o la puesta del sol. Algoritmo del almanaque NOAA.
    function sunEvent(lat, lon, dayOfYear, rising, offsetMin) {
        var lngHour = lon / 15.0;
        var t = dayOfYear + ((rising ? 6.0 : 18.0) - lngHour) / 24.0;
        var m = 0.9856 * t - 3.289;
        var l = norm(m + 1.916 * sinD(m) + 0.020 * sinD(2 * m) + 282.634, 360.0);
        var ra = norm(Math.toDegrees(Math.atan(0.91764 * Math.tan(Math.toRadians(l)))), 360.0);
        ra = (ra + (Math.floor(l / 90.0) * 90.0 - Math.floor(ra / 90.0) * 90.0)) / 15.0;
        var sinDec = 0.39782 * sinD(l);
        var cosDec = Math.cos(Math.asin(sinDec));
        var cosH = (cosD(90.833) - sinDec * sinD(lat)) / (cosDec * cosD(lat));
        if (cosH > 1 || cosH < -1) {
            return null;
        }
        var h = Math.toDegrees(Math.acos(cosH));
        if (rising) {
            h = 360 - h;
        }
        var tt = h / 15.0 + ra - 0.06571 * t - 6.622;
        var ut = norm(tt - lngHour, 24.0);
        var mins = Math.round(ut * 60 + offsetMin).toNumber();
        return ((mins % 1440) + 1440) % 1440;
    }

    function dayOfYear(year, month, day) {
        var cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        var n = cum[month - 1] + day;
        var leap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
        if (leap && month > 2) {
            n += 1;
        }
        return n;
    }
}
