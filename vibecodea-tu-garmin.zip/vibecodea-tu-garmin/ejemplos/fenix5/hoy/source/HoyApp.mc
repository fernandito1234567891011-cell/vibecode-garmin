using Toybox.Application;
using Toybox.Attention;
using Toybox.Communications;
using Toybox.Graphics;
using Toybox.Lang;
using Toybox.System;
using Toybox.Time;
using Toybox.Time.Gregorian;
using Toybox.WatchUi;

// «Hoy F5»: lo que tienes pendiente hoy (lo apuntas desde el móvil y llega a la nube).
// START abre la lista: eliges uno y queda tachado.
class HoyApp extends Application.AppBase {

    function initialize() {
        AppBase.initialize();
    }

    function getInitialView() {
        var m = new HoyModel();
        return [new HoyView(m), new HoyDelegate(m)];
    }
}

class HoyModel {

    const URL = "https://TU-PROYECTO.supabase.co/functions/v1/reloj";
    const TOKEN = "CAMBIA-ESTE-TOKEN";

    // [[id, texto, "HH:MM" o null, 0 hoy / 1 de días anteriores], ...]
    var items = [];
    var at = 0;
    var online = false;

    (:typecheck(false))
    function initialize() {
        var p = Application.Storage.getValue("pend");
        if (p instanceof Lang.Array) {
            items = p;
        }
        var a = Application.Storage.getValue("pendAt");
        if (a != null) {
            at = a;
        }
    }

    (:typecheck(false))
    function refresh() {
        if (!System.getDeviceSettings().phoneConnected) {
            online = false;
            WatchUi.requestUpdate();
            return;
        }
        sendDone();
        Communications.makeWebRequest(URL + "/pendientes", null,
            {
                :method => Communications.HTTP_REQUEST_METHOD_GET,
                :headers => {"x-reloj-token" => TOKEN},
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onList));
    }

    (:typecheck(false))
    function onList(code, data) {
        if (code == 200 && data != null && data["p"] instanceof Lang.Array) {
            items = filterDone(data["p"]);
            at = Time.now().value();
            online = true;
            Application.Storage.setValue("pend", items);
            Application.Storage.setValue("pendAt", at);
        } else {
            online = false;
        }
        WatchUi.requestUpdate();
    }

    // Quita los que ya se tacharon en el reloj y aún no han llegado al servidor.
    (:typecheck(false))
    function filterDone(list) {
        var q = Application.Storage.getValue("pendDone");
        if (!(q instanceof Lang.Array) || q.size() == 0) {
            return list;
        }
        var out = [];
        for (var i = 0; i < list.size(); i++) {
            if (q.indexOf(list[i][0]) < 0) {
                out.add(list[i]);
            }
        }
        return out;
    }

    (:typecheck(false))
    function markDone(id) {
        var out = [];
        for (var i = 0; i < items.size(); i++) {
            if (items[i][0] != id) {
                out.add(items[i]);
            }
        }
        items = out;
        Application.Storage.setValue("pend", items);
        var q = Application.Storage.getValue("pendDone");
        if (!(q instanceof Lang.Array)) {
            q = [];
        }
        q.add(id);
        Application.Storage.setValue("pendDone", q);
        if (Attention has :vibrate) {
            Attention.vibrate([new Attention.VibeProfile(60, 150)]);
        }
        sendDone();
    }

    (:typecheck(false))
    function sendDone() {
        var q = Application.Storage.getValue("pendDone");
        if (!(q instanceof Lang.Array) || q.size() == 0 || !System.getDeviceSettings().phoneConnected) {
            return;
        }
        Communications.makeWebRequest(URL, {"tipo" => "hecho", "id" => q[0]},
            {
                :method => Communications.HTTP_REQUEST_METHOD_POST,
                :headers => {
                    "Content-Type" => Communications.REQUEST_CONTENT_TYPE_JSON,
                    "x-reloj-token" => TOKEN
                },
                :responseType => Communications.HTTP_RESPONSE_CONTENT_TYPE_JSON
            },
            method(:onDoneSent));
    }

    (:typecheck(false))
    function onDoneSent(code, data) {
        if (code != 200) {
            return;
        }
        var q = Application.Storage.getValue("pendDone");
        if (q instanceof Lang.Array && q.size() > 0) {
            q = q.slice(1, null);
            Application.Storage.setValue("pendDone", q);
            if (q.size() > 0) {
                sendDone();
            }
        }
    }

    (:typecheck(false))
    function updatedText() {
        if (at == 0) {
            return online ? "AL DÍA" : "SIN MÓVIL";
        }
        var g = Gregorian.info(new Time.Moment(at), Time.FORMAT_SHORT);
        return (online ? "AL DÍA · " : "SIN MÓVIL · ") + g.hour.toString() + ":" + g.min.format("%02d");
    }
}

class HoyView extends WatchUi.View {

    const C_GOLD = 0xFFAA00;
    const C_WHITE = 0xFFFFFF;
    const C_GRAY = 0xAAAAAA;
    const C_GREEN = 0x55FF55;
    const C_YELLOW = 0xFFFF55;

    hidden var m;
    hidden var fSmall, fXs;

    function initialize(model) {
        View.initialize();
        m = model;
    }

    function onLayout(dc) {
        fSmall = WatchUi.loadResource(Rez.Fonts.Small);
        fXs = WatchUi.loadResource(Rez.Fonts.Xs);
    }

    function onShow() {
        m.refresh();
    }

    function text(dc, x, y, font, s, color, just) {
        dc.setColor(color, Graphics.COLOR_TRANSPARENT);
        dc.drawText(x, y, font, s, just);
    }

    // Corta por la última palabra que quepa.
    function fit(dc, s, maxw) {
        if (dc.getTextWidthInPixels(s, fXs) <= maxw) {
            return s;
        }
        var t = s;
        while (t.length() > 1 && dc.getTextWidthInPixels(t, fXs) > maxw) {
            t = t.substring(0, t.length() - 1);
        }
        for (var i = t.length() - 1; i > 3; i--) {
            if (t.substring(i, i + 1).equals(" ")) {
                return t.substring(0, i);
            }
        }
        return t;
    }

    (:typecheck(false))
    function onUpdate(dc) {
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();
        var c = Graphics.TEXT_JUSTIFY_CENTER;
        var l = Graphics.TEXT_JUSTIFY_LEFT;
        text(dc, 120, HoyLayout.TITLE_Y, fXs, "PENDIENTES", C_GOLD, c);
        var n = m.items.size();
        if (n == 0) {
            text(dc, 120, HoyLayout.EMPTY_Y, fSmall, "NADA PENDIENTE", C_GREEN, c);
        }
        var rows = n < HoyLayout.ROWS ? n : HoyLayout.ROWS;
        for (var i = 0; i < rows; i++) {
            var it = m.items[i];
            var y = HoyLayout.ROW_Y + i * HoyLayout.ROW_DY;
            var th = it[2] == null ? "" : it[2];
            var wt = th.length() > 0 ? dc.getTextWidthInPixels(th, fXs) + HoyLayout.TIME_GAP : 0;
            var body = fit(dc, it[1], HoyLayout.ROW_MAXW - wt);
            var w = wt + dc.getTextWidthInPixels(body, fXs);
            var x = 120 - w / 2;
            if (wt > 0) {
                text(dc, x, y, fXs, th, C_GOLD, l);
            }
            text(dc, x + wt, y, fXs, body, it[3] == 1 ? C_GRAY : C_WHITE, l);
        }
        if (n > HoyLayout.ROWS) {
            text(dc, 120, HoyLayout.MORE_Y, fXs, "+" + (n - HoyLayout.ROWS).toString() + " MÁS", C_GRAY, c);
        }
        if (n > 0) {
            text(dc, 120, HoyLayout.HINT_Y, fXs, "START: TACHAR", C_GREEN, c);
        }
        text(dc, 120, HoyLayout.FOOT_Y, fXs, m.updatedText(), m.online ? C_GRAY : C_YELLOW, c);
    }
}

class HoyDelegate extends WatchUi.BehaviorDelegate {

    hidden var m;

    function initialize(model) {
        BehaviorDelegate.initialize();
        m = model;
    }

    (:typecheck(false))
    function onSelect() {
        if (m.items.size() == 0) {
            m.refresh();
            return true;
        }
        var menu = new WatchUi.Menu2({:title => "¿Qué has hecho?"});
        for (var i = 0; i < m.items.size(); i++) {
            var it = m.items[i];
            var sub = it[2] != null ? it[2] : (it[3] == 1 ? "De días anteriores" : "Sin hora");
            menu.addItem(new WatchUi.MenuItem(it[1], sub, it[0], {}));
        }
        WatchUi.pushView(menu, new HoyMenuDelegate(m, menu), WatchUi.SLIDE_UP);
        return true;
    }
}

class HoyMenuDelegate extends WatchUi.Menu2InputDelegate {

    hidden var m;
    hidden var mMenu;

    function initialize(model, menu) {
        Menu2InputDelegate.initialize();
        m = model;
        mMenu = menu;
    }

    function onSelect(item) {
        var id = item.getId();
        m.markDone(id);
        var idx = mMenu.findItemById(id);
        if (idx >= 0) {
            mMenu.deleteItem(idx);
        }
        if (m.items.size() == 0) {
            WatchUi.popView(WatchUi.SLIDE_DOWN);
        }
        WatchUi.requestUpdate();
    }
}
