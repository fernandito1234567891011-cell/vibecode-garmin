// GENERADO por hoy_preview.py: no editar a mano.
module HoyLayout {
    const TITLE_Y = 30;
    const ROW_Y = 54;
    const ROW_DY = 24;
    const ROWS = 4;
    const ROW_MAXW = 170;
    const TIME_GAP = 8;
    const MORE_Y = 150;
    const EMPTY_Y = 96;
    const HINT_Y = 168;
    const FOOT_Y = 186;
}
