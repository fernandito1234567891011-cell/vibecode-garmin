"""Vista previa fiel de la esfera F5+ (240x240, fenix 5) + comprobaciones automáticas.

- Dibuja con las MISMAS fuentes BMFont e iconos que van al reloj.
- Las posiciones salen de LAYOUT, que este script exporta a proj/esfera/source/F5Layout.mc,
  así la vista previa y el reloj usan exactamente los mismos números.
- Comprueba en varios escenarios (incluido el peor) que nada se sale de la pantalla redonda,
  nada toca los anillos y nada se pisa.
"""
import math, os, itertools, sys
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
A = os.path.join(HERE, 'assets')
LAYOUT_MC = os.path.join(HERE, '..', 'esfera', 'source', 'F5Layout.mc')

# ---------------------------------------------------------------- disposición
# y = parte de arriba de la línea de texto (como dc.drawText); los iconos, su esquina superior.
LAYOUT = {
    'RING_R': 113, 'RING_PEN': 6,
    'MOON_Y': 23, 'MOON_R': 9, 'ZOD_Y': 14, 'ZOD_GAP': 4,
    'SEC_R': 113, 'SEC_DOT': 4,
    'DATE_Y': 36,
    'TIME_Y': 42,
    'STATUS_Y': 106,
    'ROW1_ICON_Y': 129, 'ROW1_Y': 142, 'ROW1_DX': 66,
    'ROW2_ICON_Y': 169, 'ROW2_Y': 167, 'ROW2_DX': 52,
    'ROW3_ICON_Y': 189, 'ROW3_Y': 187,
    'ROW4_ICON_Y': 207, 'ROW4_Y': 205,
    'ICON_GAP': 16,      # de la esquina del icono al texto (icono de 14 + 2 de aire)
    'SUN_GAP': 10,       # aire entre salida y puesta
}
L = LAYOUT


def export_layout():
    lines = ['// GENERADO por preview.py: no editar a mano. Posiciones revisadas con la vista previa.',
             'module F5Layout {']
    for k, v in LAYOUT.items():
        lines.append(f'    const {k} = {v};')
    lines.append('}')
    os.makedirs(os.path.dirname(LAYOUT_MC), exist_ok=True)
    with open(LAYOUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


# ---------------------------------------------------------------- dibujo
def snap(c):
    return tuple(min((0, 85, 170, 255), key=lambda v: abs(v - x)) for x in c)


class BMFont:
    def __init__(self, fid):
        self.chars = {}
        for line in open(os.path.join(A, 'fonts', fid + '.fnt'), encoding='utf-8'):
            parts = line.split()
            if not parts:
                continue
            kv = dict(p.split('=', 1) for p in parts[1:] if '=' in p)
            if parts[0] == 'common':
                self.line_h = int(kv['lineHeight']); self.base = int(kv['base'])
            elif parts[0] == 'char':
                self.chars[int(kv['id'])] = {k: int(v) for k, v in kv.items() if k not in ('page', 'chnl')}
        self.atlas = Image.open(os.path.join(A, 'fonts', fid + '.png')).convert('RGBA')
        self.fid = fid

    def width(self, s):
        return sum(self.chars[ord(c)]['xadvance'] for c in s if ord(c) in self.chars)


class DC:
    def __init__(self):
        self.img = Image.new('RGB', (240, 240), (0, 0, 0))
        self.d = ImageDraw.Draw(self.img)
        self.fg = (255, 255, 255)
        self.pen = 1
        self.boxes = []   # (grupo, etiqueta, x0, y0, x1, y1) de tinta real
        self.circles = [] # (etiqueta, cx, cy, r): para estos se mide el círculo, no su caja
        self.missing = []

    def color(self, rgb):
        self.fg = snap(((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255))

    def text(self, x, y, font, s, just='c', group=None):
        for ch in s:
            if ord(ch) not in font.chars:
                self.missing.append((font.fid, ch, s))
        s2 = ''.join(ch for ch in s if ord(ch) in font.chars)
        w = font.width(s2)
        if just == 'c':
            x = x - w // 2
        elif just == 'r':
            x = x - w
        x0 = y0 = 10**6; x1 = y1 = -10**6
        for ch in s2:
            g = font.chars[ord(ch)]
            crop = font.atlas.crop((g['x'], g['y'], g['x'] + g['width'], g['y'] + g['height']))
            mask = crop.split()[3]
            gx, gy = x + g['xoffset'], y + g['yoffset']
            self.img.paste(self.fg, (gx, gy), mask)
            bb = mask.getbbox()
            if bb:
                x0 = min(x0, gx + bb[0]); y0 = min(y0, gy + bb[1])
                x1 = max(x1, gx + bb[2]); y1 = max(y1, gy + bb[3])
            x += g['xadvance']
        if x1 > x0:
            self.boxes.append((group or s, s, x0, y0, x1, y1))
        return w

    def bitmap(self, x, y, name, group=None):
        ic = Image.open(os.path.join(A, 'icons', name + '.png')).convert('RGBA')
        self.img.paste(ic, (x, y), ic.split()[3])
        bb = ic.split()[3].getbbox()
        self.boxes.append((group or name, 'icono ' + name, x + bb[0], y + bb[1], x + bb[2], y + bb[3]))

    def arc(self, cx, cy, r, start, end, clockwise):
        # Connect IQ: grados en sentido antihorario desde las 3; el trazo va centrado en el radio.
        if clockwise:
            a0, a1 = -start, -end
            while a1 < a0:
                a1 += 360
        else:
            a0, a1 = -end, -start
            if a1 < a0:
                a1 += 360
        h = self.pen // 2
        self.d.arc((cx - r - h, cy - r - h, cx + r + h, cy + r + h), a0, a1, fill=self.fg, width=self.pen)

    def circle(self, cx, cy, r):
        self.d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=self.fg)

    def polygon(self, pts):
        self.d.polygon(pts, fill=self.fg)

    def final(self, scale=2):
        m = Image.new('L', (240, 240), 0)
        ImageDraw.Draw(m).ellipse((0, 0, 239, 239), fill=255)
        bg = Image.new('RGB', (240, 240), (60, 60, 60))
        bg.paste(self.img, (0, 0), m)
        return bg.resize((240 * scale, 240 * scale), Image.NEAREST)


def moon_pts(cx, cy, r, phase):
    k = math.cos(phase * 2 * math.pi)
    sgn = 1 if phase < 0.5 else -1
    pts = []
    for i in range(17):
        a = math.pi / 2 - math.pi * i / 16
        pts.append((cx + sgn * r * math.cos(a), cy - r * math.sin(a)))
    for i in range(17):
        a = -math.pi / 2 + math.pi * i / 16
        pts.append((cx + sgn * k * r * math.cos(a), cy - r * math.sin(a)))
    return pts


def icon_text(dc, font, left, icon_y, text_y, icon, val, col, group):
    dc.bitmap(left, icon_y, icon, group)
    dc.color(col)
    dc.text(left + L['ICON_GAP'], text_y, font, val, 'l', group)


def render(st):
    T = BMFont('time'); M = BMFont('med'); S = BMFont('small'); X = BMFont('xs'); Z = BMFont('zod')
    dc = DC(); cx = 120
    # anillos: pasos a la izquierda (de abajo arriba), batería a la derecha
    r = L['RING_R']; dc.pen = L['RING_PEN']
    dc.color(0x000055); dc.arc(120, 120, r, 240, 120, True)
    dc.color(0x555500); dc.arc(120, 120, r, 300, 60, False)
    sp = min(1.0, st['steps'] / st['goal'])
    deg = int(120 * sp)
    if deg >= 2:
        dc.color(0x00FF55 if sp >= 1 else 0x00AAFF); dc.arc(120, 120, r, 240, 240 - deg, True)
    bdeg = int(120 * st['battery'] / 100.0)
    if bdeg >= 2:
        dc.color(0xFFAA00 if st['battery'] > 20 else 0xFF0000); dc.arc(120, 120, r, 300, (300 + bdeg) % 360, False)
    dc.pen = 1
    # luna + símbolo del signo por el que pasa (grupo centrado)
    my, mr = L['MOON_Y'], L['MOON_R']
    zch = chr(ord('a') + st['sign'])
    gw = 2 * mr + 1 + L['ZOD_GAP'] + Z.width(zch)
    mx = cx - gw // 2 + mr
    dc.color(0x555555); dc.circle(mx, my, mr)
    dc.color(0xFFFFAA); dc.polygon(moon_pts(mx, my, mr, st['phase']))
    dc.boxes.append(('luna', 'luna', mx - mr, my - mr, mx + mr + 1, my + mr + 1))
    dc.circles.append(('luna', mx, my, mr))
    dc.color(0xFFAA00 if st['sign'] == -1 else 0x55AAFF)
    dc.text(mx + mr + 1 + L['ZOD_GAP'], L['ZOD_Y'], Z, zch, 'l', 'signo')
    # fecha y hora
    dc.color(0xFFAA00); dc.text(cx, L['DATE_Y'], S, st['date'], 'c', 'fecha')
    dc.color(0xFFFFFF); dc.text(cx, L['TIME_Y'], T, st['time'], 'c', 'hora')
    # estado
    dc.color(st['status_color']); dc.text(cx, L['STATUS_Y'], S, st['status'], 'c', 'estado')
    # fila 1: pulso, pasos, calorías
    for x, icon, val in [(cx - L['ROW1_DX'], 'heart', st['hr']), (cx, 'steps', st['steps_txt']),
                         (cx + L['ROW1_DX'], 'flame', st['kcal'])]:
        dc.bitmap(x - 7, L['ROW1_ICON_Y'], icon, 'f1 ' + icon)
        dc.color(0xFFFFFF); dc.text(x, L['ROW1_Y'], M, val, 'c', 'f1 ' + icon)
    # fila 2: tiempo (icono + temperatura), minutos de intensidad (semana), notificaciones
    for x, icon, val, col in [(cx - L['ROW2_DX'], st['wx'], st['temp'], 0xFFFFFF),
                              (cx, 'bolt', st['energy'], st.get('energy_col', 0xFFFF55)),
                              (cx + L['ROW2_DX'], 'bell', st['notif'], 0xFFFFFF if st['bt'] else 0x555555)]:
        left = x - (L['ICON_GAP'] + X.width(val)) // 2
        icon_text(dc, X, left, L['ROW2_ICON_Y'], L['ROW2_Y'], icon, val, col, 'f2 ' + icon)
    # fila 3: salida y puesta de sol (grupo centrado)
    w1, w2 = X.width(st['sunrise']), X.width(st['sunset'])
    total = L['ICON_GAP'] + w1 + L['SUN_GAP'] + L['ICON_GAP'] + w2
    left = cx - total // 2
    icon_text(dc, X, left, L['ROW3_ICON_Y'], L['ROW3_Y'], 'sunup', st['sunrise'], 0xFFAA00, 'salida')
    left2 = left + L['ICON_GAP'] + w1 + L['SUN_GAP']
    icon_text(dc, X, left2, L['ROW3_ICON_Y'], L['ROW3_Y'], 'sundown', st['sunset'], 0xFFAA00, 'puesta')
    # fila 4: bluetooth + batería
    bt = f"{st['battery']}%"
    left = cx - (L['ICON_GAP'] + X.width(bt)) // 2
    if st['bt']:
        dc.bitmap(left, L['ROW4_ICON_Y'], 'bt', 'bateria')
    dc.color(0xFFAA00 if st['battery'] > 20 else 0xFF0000)
    dc.text(left + L['ICON_GAP'], L['ROW4_Y'], X, bt, 'l', 'bateria')
    # segundos (solo al levantar la muñeca): punto blanco que recorre el borde
    if st.get('sec') is not None:
        a = math.radians(90 - st['sec'] * 6)
        sx = 120 + L['SEC_R'] * math.cos(a); sy = 120 - L['SEC_R'] * math.sin(a)
        dc.color(0xFFFFFF); dc.circle(round(sx), round(sy), L['SEC_DOT'])
    return dc


def check(dc, name, limit=106, gap=2):
    """limit: distancia máxima al centro (el anillo empieza en 110); gap: aire mínimo entre grupos."""
    problems = []
    round_tags = {c[0] for c in dc.circles}
    for tag, ccx, ccy, r in dc.circles:
        worst = math.hypot(ccx - 119.5, ccy - 119.5) + r
        if worst > limit:
            problems.append(f'{name}: «{tag}» se acerca demasiado al anillo ({worst:.0f} px del centro)')
    for grp, tag, x0, y0, x1, y1 in dc.boxes:
        if tag in round_tags:
            continue
        worst = max(math.hypot(px - 119.5, py - 119.5) for px in (x0, x1 - 1) for py in (y0, y1 - 1))
        if worst > limit:
            problems.append(f'{name}: «{tag}» se acerca demasiado al anillo ({worst:.0f} px del centro)')
    for a, b in itertools.combinations(dc.boxes, 2):
        g = 0 if a[0] == b[0] else gap
        if a[2] - g < b[4] and b[2] - g < a[4] and a[3] - g < b[5] and b[3] - g < a[5]:
            problems.append(f'{name}: «{a[1]}» y «{b[1]}» se pisan o quedan pegados')
    for m in dc.missing:
        problems.append(f'{name}: falta el carácter {m[1]!r} en la fuente {m[0]} («{m[2]}»)')
    return problems


CASES = {}
base = dict(steps=8234, goal=10000, battery=76, phase=0.295, sign=11, date='MIÉ 18 NOV', time='15:44',
            hr='64', steps_txt='8.234', kcal='1.850', wx='wx_partly', temp='12°', energy='72', energy_col=0x55FF55, notif='3',
            sunrise='8:04', sunset='17:56', bt=True)
worst = dict(base, steps=23456, steps_txt='23.456', kcal='3.456', hr='188', temp='-12°', wx='wx_storm',
             energy='100', notif='99', battery=100, date='MIÉ 30 SEP', time='23:58', sign=5,
             sunrise='10:04', sunset='21:48')
CASES['manana'] = dict(base, time='9:12', status='NOCHE 51 · FRESCO', status_color=0x55FF55, wx='wx_sun', temp='7°')
CASES['tiempo'] = dict(base, status='15°/6° · LLUVIA 70%', status_color=0xFFFFFF, wx='wx_rain')
CASES['altitud'] = dict(base, status='ALTITUD 655 M', status_color=0xAAAAAA, sign=8)
CASES['tormenta'] = dict(base, status='¡TORMENTA! -5 HPA EN 3 H', status_color=0xFF0000, wx='wx_storm')
CASES['natal'] = dict(base, phase=0.12, sign=1, status='LUNA LLENA EN 11 DÍAS', status_color=0xFFFFAA)
CASES['energia'] = dict(base, status='ENERGÍA 37 DE 100', status_color=0xFFFF55, energy='37', energy_col=0xFFFF55)
CASES['intensidad'] = dict(base, status='INTENSIDAD 1250 MIN', status_color=0xFFFF55, energy='--', energy_col=0xAAAAAA)
CASES['muneca'] = dict(base, status='1016 HPA · BAJA 2', status_color=0x55AAFF, sec=42)
CASES['noche'] = dict(base, time='23:40', status='A LA CAMA EN 1:20', status_color=0xFFAA00,
                      steps=12850, steps_txt='12.850', battery=18, phase=0.5, wx='wx_moon', temp='4°')
CASES['madrugada'] = dict(base, time='3:12', status='HORA DE DORMIR', status_color=0xFF0000, bt=False,
                          phase=0.8, notif='0', wx='wx_fog', temp='2°')
CASES['peor_1'] = dict(worst, status='NOCHE 60 · MUY CARGADO', status_color=0xFF0000)
CASES['peor_2'] = dict(worst, status='ENERGÍA 100 · CARGADO', status_color=0xFFFF55, hr='--', sec=7)
CASES['peor_3'] = dict(worst, status='NOCHE 52 · BASE 1/3', status_color=0xAAAAAA, wx='wx_snow', temp='-5°')


def main():
    export_layout()
    out = os.path.join(HERE, 'preview')
    os.makedirs(out, exist_ok=True)
    allp = []
    for name, st in CASES.items():
        dc = render(st)
        dc.final().save(os.path.join(out, name + '.png'))
        allp += check(dc, name)
    print('\n'.join(allp) if allp else 'Sin problemas en %d escenarios' % len(CASES))
    return 1 if allp else 0


if __name__ == '__main__':
    sys.exit(main())
