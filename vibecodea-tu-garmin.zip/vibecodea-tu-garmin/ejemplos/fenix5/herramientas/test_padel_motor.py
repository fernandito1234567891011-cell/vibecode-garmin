from padel_motor import Padel
def juego(m, k):
    for _ in range(4): m.punto(k)
# punto de oro: 40-40 y el siguiente gana
m = Padel(modo=1); [m.punto(0) for _ in range(3)]; [m.punto(1) for _ in range(3)]
assert m.marcador() == ('40','40'); m.punto(1); assert m.g == [0,1], m.g
# ventaja: 40-40, AD, iguales, AD, juego
m = Padel(modo=0); [m.punto(0) for _ in range(3)]; [m.punto(1) for _ in range(3)]
m.punto(0); assert m.marcador() == ('AD','40'); m.punto(1); assert m.marcador() == ('40','40'); m.punto(1); assert m.marcador()==('40','AD'); m.punto(1); assert m.g == [0,1]
# star point: dos iguales con ventaja, al tercero punto decisivo
m = Padel(modo=2); [m.punto(0) for _ in range(3)]; [m.punto(1) for _ in range(3)]   # iguales 1
m.punto(0); m.punto(1)   # iguales 2
m.punto(0); m.punto(1)   # iguales 3 -> decisivo
assert m.marcador()==('40','40') and m.iguales == 3, (m.marcador(), m.iguales)
m.punto(0); assert m.g == [1,0], m.g
# set 6-4, cambio de lado en impares, saque alterno
m = Padel(); 
for i in range(10): juego(m, 0 if i % 2 == 0 or i < 2 else 1)
print('tras 10 juegos', m.sets, m.g)
# tie-break en 6-6 y saque
m = Padel(saca=0)
for i in range(12): juego(m, i % 2)
assert m.g == [6,6] and m.tb, (m.g, m.tb)
first = m.server; servers=[m.server]
for i in range(6):
    m.punto(0 if i%2==0 else 1); servers.append(m.server)
print('saque TB', first, servers)
assert servers[1] != first and servers[2] != first and servers[3] == first and servers[4] == first
for i in range(7): m.punto(0)
assert m.sets == [[7,6]], m.sets
assert m.server == 1-first
# súper tie-break en el tercero
m = Padel(super_tb=True)
for i in range(6): juego(m, 0)
for i in range(6): juego(m, 1)
assert m.tb and m.tb_meta == 10, (m.tb, m.tb_meta)
for i in range(9): m.punto(0)
for i in range(9): m.punto(1)
m.punto(0); assert not m.done; m.punto(0); assert m.done and m.ganador == 0 and m.sets[-1] == [1,0], m.sets
# deshacer
m = Padel(); m.punto(0); m.punto(0); m.undo(); assert m.p == [1,0]; m.undo(); assert m.p == [0,0] and m.tot == [0,0]
# partido a dos sets
m = Padel(); 
for i in range(12): juego(m, 0)
assert m.done and m.ganador == 0 and m.sets == [[6,0],[6,0]]
print('todas las pruebas OK')
