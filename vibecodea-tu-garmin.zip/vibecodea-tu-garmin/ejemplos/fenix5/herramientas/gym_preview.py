"""Vista previa y comprobación de las pantallas de «Gimnasio F5» (240x240, fenix 5).
Exporta las posiciones a proj/gym/source/GymLayout.mc para que reloj y vista previa coincidan."""
import os, sys, math
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'gym', 'source', 'GymLayout.mc')

LAYOUT = {
    'EX_Y': 34, 'SET_Y': 52, 'BIG_Y': 58, 'LBL_Y': 120,
    'ROW_Y': 140, 'ROW_ICON_Y': 145, 'TIMER_X': 82, 'HR_X': 140,
    'HINT_Y': 166, 'TOT_Y': 186,
    'REST_TITLE_Y': 34, 'REST_LAST_Y': 120, 'REST_EDIT_Y': 140, 'REST_ROW_Y': 158, 'REST_ICON_Y': 163,
    'REST_HINT_Y': 186,
    'RING_R': 113, 'RING_PEN': 6,
}
L = LAYOUT

EXERCISES = ["EJERCICIO", "PRESS BANCA", "PRESS INCLIN.", "SENTADILLA", "PESO MUERTO", "PRENSA", "REMO",
             "JALÓN", "DOMINADAS", "PRESS MILITAR", "ELEV. LATERAL", "CURL BÍCEPS", "TRÍCEPS", "FONDOS",
             "ZANCADAS", "HIP THRUST", "ABDOMINALES", "PECHO MÁQ.", "FEMORAL", "CUÁDRICEPS", "GEMELOS", "OTRO"]


def export():
    lines = ['// GENERADO por gym_preview.py: no editar a mano.', 'module GymLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def hr_row(dc, M, y_text, y_icon, timer, hr):
    dc.color(0xFFFFFF)
    if timer is not None:
        dc.text(L['TIMER_X'], y_text, M, timer, 'c', 'timer')
        x = L['HR_X']
    else:
        x = 120 - (16 + M.width(hr)) // 2
    dc.bitmap(x, y_icon, 'heart', 'pulso')
    dc.text(x + 16, y_text, M, hr, 'l', 'pulso')


def render_set(st):
    T = BMFont('time'); M = BMFont('med'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); cx = 120
    dc.color(0xFFAA00); dc.text(cx, L['EX_Y'], S, st['ex'], 'c', 'ejercicio')
    dc.color(0xFFFFFF); dc.text(cx, L['SET_Y'], S, 'SERIE %d' % st['set'], 'c', 'serie')
    dc.text(cx, L['BIG_Y'], T, str(st['reps']), 'c', 'repes')
    dc.color(0xAAAAAA); dc.text(cx, L['LBL_Y'], X, 'REPES', 'c', 'etiqueta')
    hr_row(dc, M, L['ROW_Y'], L['ROW_ICON_Y'], st['timer'], st['hr'])
    dc.color(0xAAAAAA); dc.text(cx, L['HINT_Y'], X, 'START: FIN DE SERIE', 'c', 'pista')
    dc.text(cx, L['TOT_Y'], X, 'TOTAL %d REPES' % st['total'], 'c', 'total')
    return dc


def render_rest(st):
    T = BMFont('time'); M = BMFont('med'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); cx = 120
    dc.pen = L['RING_PEN']
    dc.color(0x005500); dc.arc(120, 120, L['RING_R'], 90, 90, True) if False else None
    frac = st['left'] / st['rest']
    deg = int(360 * frac)
    if deg >= 2:
        dc.color(0x00FF55); dc.arc(120, 120, L['RING_R'], 90, (90 - deg) % 360, True)
    dc.pen = 1
    dc.color(0x55FF55); dc.text(cx, L['REST_TITLE_Y'], S, 'DESCANSO', 'c', 'titulo')
    dc.color(0xFFFFFF); dc.text(cx, L['BIG_Y'], T, '%d:%02d' % (st['left'] // 60, st['left'] % 60), 'c', 'cuenta')
    dc.text(cx, L['REST_LAST_Y'], S, 'SERIE %d: %d REPES' % (st['set'], st['reps']), 'c', 'ultima')
    dc.color(0xAAAAAA); dc.text(cx, L['REST_EDIT_Y'], X, 'FLECHAS: CORRIGE', 'c', 'corrige')
    hr_row(dc, M, L['REST_ROW_Y'], L['REST_ICON_Y'], None, st['hr'])
    dc.color(0xAAAAAA); dc.text(cx, L['REST_HINT_Y'], X, 'START: EMPEZAR', 'c', 'pista')
    return dc


def main():
    export()
    os.makedirs(os.path.join(HERE, 'preview'), exist_ok=True)
    probs = []
    shots = []
    for ex in EXERCISES:
        dc = render_set(dict(ex=ex, set=12, reps=88, timer='12:42', hr='188', total=1488))
        probs += check(dc, 'serie ' + ex)
    dc = render_set(dict(ex='PRESS BANCA', set=3, reps=8, timer='0:42', hr='128', total=48))
    shots.append(('serie', dc)); probs += check(dc, 'serie')
    dc = render_rest(dict(rest=90, left=75, set=3, reps=10, hr='112'))
    shots.append(('descanso', dc)); probs += check(dc, 'descanso')
    dc = render_rest(dict(rest=180, left=179, set=12, reps=88, hr='188'))
    probs += check(dc, 'descanso peor')
    from PIL import Image, ImageDraw
    sheet = Image.new('RGB', (480 * len(shots) + 10 * (len(shots) + 1), 500), (30, 30, 30))
    for i, (n, d) in enumerate(shots):
        sheet.paste(d.final(), (10 + i * 490, 10))
    sheet.save(os.path.join(HERE, 'preview', 'gym.png'))
    print('\n'.join(probs) if probs else 'Sin problemas')
    return 1 if probs else 0


if __name__ == '__main__':
    sys.exit(main())
