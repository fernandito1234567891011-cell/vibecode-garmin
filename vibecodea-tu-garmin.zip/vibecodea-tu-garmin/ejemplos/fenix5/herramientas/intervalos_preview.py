"""Vista previa y comprobación de «Intervalos F5» (240x240, fenix 5). Exporta IntLayout.mc."""
import os
from PIL import Image, ImageDraw, ImageFont
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'intervalos', 'source', 'IntLayout.mc')

LAYOUT = {
    'RING_R': 113, 'RING_PEN': 6,
    # en marcha
    'MODE_Y': 28, 'PHASE_Y': 46, 'TIME_Y': 60, 'ROUND_Y': 128, 'NEXT_Y': 150, 'EXTRA_Y': 168,
    'FOOT_Y': 187, 'FOOT_ICON_Y': 191,
    # preparado
    'R_TITLE_Y': 28, 'R_MODE_Y': 48, 'R_DESC_Y': 72, 'R_TOTAL_Y': 92, 'R_HINT1_Y': 120, 'R_START_Y': 142,
    'R_HINT2_Y': 166, 'DOTS_Y': 205, 'DOTS_DX': 10,
    # terminado
    'D_TITLE_Y': 40, 'D_ROUNDS_Y': 64, 'D_TIME_Y': 88, 'D_EXTRA_Y': 108, 'D_SAVED_Y': 136, 'D_HINT_Y': 166,
}
L = LAYOUT
GOLD, WHITE, GRAY, DARK, GREEN, BLUE, YELLOW = 0xFFAA00, 0xFFFFFF, 0xAAAAAA, 0x555555, 0x55FF55, 0x55AAFF, 0xFFFF55


def export():
    lines = ['// GENERADO por intervalos_preview.py: no editar a mano.', 'module IntLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def render(st):
    T = BMFont('time'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); c = 120
    k = st['kind']
    if k == 'ready':
        dc.color(GOLD); dc.text(c, L['R_TITLE_Y'], X, 'INTERVALOS')
        dc.color(WHITE); dc.text(c, L['R_MODE_Y'], S, st['mode'])
        dc.text(c, L['R_DESC_Y'], X, st['desc'])
        dc.color(GRAY); dc.text(c, L['R_TOTAL_Y'], X, st['total'])
        dc.text(c, L['R_HINT1_Y'], X, 'ARRIBA/ABAJO: MODO')
        dc.color(GREEN); dc.text(c, L['R_START_Y'], S, 'START: EMPEZAR')
        dc.color(GRAY); dc.text(c, L['R_HINT2_Y'], X, 'ATRÁS: AJUSTES')
        for i in range(6):
            x = 120 + int((i - 2.5) * L['DOTS_DX']); r = 3 if i == st['idx'] else 2
            dc.color(WHITE if i == st['idx'] else DARK); dc.circle(x, L['DOTS_Y'], r)
            dc.circles.append((f'punto {i}', x, L['DOTS_Y'], r))
        return dc
    if k == 'done':
        dc.color(st['title_col']); dc.text(c, L['D_TITLE_Y'], S, st['title'])
        dc.color(WHITE); dc.text(c, L['D_ROUNDS_Y'], S, st['rounds'])
        dc.color(GRAY); dc.text(c, L['D_TIME_Y'], X, st['time'])
        if st.get('extra'):
            dc.color(WHITE); dc.text(c, L['D_EXTRA_Y'], X, st['extra'])
        dc.color(st['saved_col']); dc.text(c, L['D_SAVED_Y'], S, st['saved'])
        dc.color(GRAY); dc.text(c, L['D_HINT_Y'], X, 'ATRÁS: SALIR')
        return dc
    # en marcha: anillo de lo que queda de la fase
    dc.pen = L['RING_PEN']
    dc.color(DARK); dc.arc(120, 120, L['RING_R'], 0, 360, False)
    dc.color(st['col']); dc.arc(120, 120, L['RING_R'], 90, 90 - 360 * st['left'], True)
    dc.color(GOLD); dc.text(c, L['MODE_Y'], X, st['mode'])
    dc.color(st['col']); dc.text(c, L['PHASE_Y'], S, st['phase'])
    dc.color(WHITE); dc.text(c, L['TIME_Y'], T, st['clock'])
    dc.text(c, L['ROUND_Y'], S, st['round'])
    dc.color(GRAY); dc.text(c, L['NEXT_Y'], X, st['next'])
    if st.get('extra'):
        dc.color(st.get('extra_col', WHITE)); dc.text(c, L['EXTRA_Y'], X, st['extra'])
    tot, hr = st['total'], st['hr']
    w = X.width(tot) + 10 + 16 + X.width(hr)
    left = 120 - w // 2
    dc.color(GRAY); dc.text(left, L['FOOT_Y'], X, tot, 'l', 'pie')
    dc.bitmap(left + X.width(tot) + 10, L['FOOT_ICON_Y'], 'heart', 'pie')
    dc.color(WHITE); dc.text(left + X.width(tot) + 26, L['FOOT_Y'], X, hr, 'l', 'pie')
    return dc


CASES = {
    'listo_tabata': dict(kind='ready', mode='TABATA', desc='8 RONDAS · 20 S / 10 S', total='4:10 EN TOTAL', idx=0),
    'listo_boxeo': dict(kind='ready', mode='BOXEO', desc='12 RONDAS · 3:00 / 1:00', total='47:10 EN TOTAL', idx=3),
    'listo_rutina': dict(kind='ready', mode='MI RUTINA', desc='50 RONDAS · 4:00 / 2:00', total='299:10 EN TOTAL', idx=5),
    'prepara': dict(kind='run', mode='TABATA', phase='PREPÁRATE', col=YELLOW, clock='0:07', left=0.7,
                    round='RONDA 1 DE 8', next='LUEGO TRABAJO 0:20', total='0:03', hr='88'),
    'trabajo': dict(kind='run', mode='HIIT 40/20', phase='TRABAJO', col=GREEN, clock='0:27', left=0.68,
                    round='RONDA 3 DE 10', next='LUEGO DESCANSO 0:20', total='2:13', hr='164'),
    'descanso': dict(kind='run', mode='BOXEO', phase='DESCANSO', col=BLUE, clock='0:45', left=0.75,
                     round='RONDA 11 DE 12', next='LUEGO TRABAJO 3:00', total='43:15', hr='131'),
    'comba': dict(kind='run', mode='COMBA', phase='TRABAJO', col=GREEN, clock='0:38', left=0.63,
                  round='RONDA 4 DE 10', next='LUEGO DESCANSO 0:30', extra='1.312 SALTOS', total='5:22', hr='171'),
    'pausa': dict(kind='run', mode='MI RUTINA', phase='PAUSA', col=WHITE, clock='10:00', left=0.99,
                  round='RONDA 50 DE 50', next='START: SEGUIR', extra='ATRÁS: MENÚ', extra_col=GRAY,
                  total='299:59', hr='--'),
    'emom': dict(kind='run', mode='EMOM', phase='MINUTO 7', col=GREEN, clock='0:12', left=0.2,
                 round='RONDA 7 DE 10', next='LUEGO MINUTO 8', total='6:48', hr='152'),
    'hecho': dict(kind='done', title='¡HECHO!', title_col=GREEN, rounds='8 DE 8 RONDAS', time='4:12 EN TOTAL',
                  saved='GUARDADO', saved_col=GREEN),
    'hecho_comba': dict(kind='done', title='TERMINADO', title_col=WHITE, rounds='7 DE 10 RONDAS',
                        time='11:40 EN TOTAL', extra='1.312 SALTOS', saved='DESCARTADO', saved_col=GRAY),
}


def main():
    probs = []
    imgs = []
    for name, st in CASES.items():
        dc = render(st)
        probs += check(dc, name)
        imgs.append((name, dc))
    cols = 4
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new('RGB', (490 * cols + 10, 530 * rows + 10), (30, 30, 30))
    d = ImageDraw.Draw(sheet); f = ImageFont.load_default()
    for i, (n, dc) in enumerate(imgs):
        x, y = 10 + (i % cols) * 490, 10 + (i // cols) * 530
        sheet.paste(dc.final(), (x, y + 30)); d.text((x + 5, y + 2), n, fill=(220, 220, 220), font=f)
    sheet.save(os.path.join(HERE, 'preview', 'intervalos.png'))
    export()
    print('\n'.join(probs) if probs else 'Sin problemas')


if __name__ == '__main__':
    main()
