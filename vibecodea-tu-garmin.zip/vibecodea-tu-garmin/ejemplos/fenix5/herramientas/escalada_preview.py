"""Vista previa y comprobación de «Escalada F5» (240x240, fenix 5). Exporta EscLayout.mc."""
import os
from PIL import Image, ImageDraw, ImageFont
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'escalada', 'source', 'EscLayout.mc')

LAYOUT = {
    'RING_R': 113, 'RING_PEN': 6,
    # descanso y escalando
    'TOP_Y': 28, 'STATE_Y': 46, 'TIME_Y': 60, 'L1_Y': 130, 'L2_Y': 149, 'HINT_Y': 168,
    'FOOT_Y': 187, 'FOOT_ICON_Y': 191,
    # grado
    'G_TITLE_Y': 34, 'G_SUB_Y': 55, 'G_GRADE_Y': 66, 'G_HINT1_Y': 136, 'G_HINT2_Y': 156,
    # preparado
    'R_TITLE_Y': 34, 'R_TYPE_Y': 56, 'R_GRADE_Y': 80, 'R_HINT1_Y': 112, 'R_START_Y': 136, 'R_HINT2_Y': 162,
    # terminado
    'D_TITLE_Y': 40, 'D_L1_Y': 64, 'D_L2_Y': 84, 'D_L3_Y': 102, 'D_L4_Y': 120, 'D_L5_Y': 140, 'D_HINT_Y': 166,
}
L = LAYOUT
GOLD, WHITE, GRAY, DARK, GREEN, BLUE = 0xFFAA00, 0xFFFFFF, 0xAAAAAA, 0x555555, 0x55FF55, 0x55AAFF


def export():
    lines = ['// GENERADO por escalada_preview.py: no editar a mano.', 'module EscLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def foot(dc, X, tot, hr):
    w = X.width(tot) + 10 + 16 + X.width(hr)
    left = 120 - w // 2
    dc.color(GRAY); dc.text(left, L['FOOT_Y'], X, tot, 'l', 'pie')
    dc.bitmap(left + X.width(tot) + 10, L['FOOT_ICON_Y'], 'heart', 'pie')
    dc.color(WHITE); dc.text(left + X.width(tot) + 26, L['FOOT_Y'], X, hr, 'l', 'pie')


def render(st):
    T = BMFont('time'); G = BMFont('grade'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); c = 120
    k = st['kind']
    if k == 'ready':
        dc.color(GOLD); dc.text(c, L['R_TITLE_Y'], X, 'ESCALADA')
        dc.color(WHITE); dc.text(c, L['R_TYPE_Y'], S, st['type'])
        dc.color(GRAY); dc.text(c, L['R_GRADE_Y'], X, st['grade'])
        dc.text(c, L['R_HINT1_Y'], X, 'ARRIBA/ABAJO: CAMBIA')
        dc.color(GREEN); dc.text(c, L['R_START_Y'], S, 'START: EMPEZAR')
        dc.color(GRAY); dc.text(c, L['R_HINT2_Y'], X, 'ATRÁS: SALIR')
        return dc
    if k == 'grade':
        dc.color(GOLD); dc.text(c, L['G_TITLE_Y'], X, '¿QUÉ GRADO?')
        dc.color(GRAY); dc.text(c, L['G_SUB_Y'], X, st['sub'])
        dc.color(WHITE); dc.text(c, L['G_GRADE_Y'], G, st['grade'])
        dc.color(GRAY); dc.text(c, L['G_HINT1_Y'], X, 'ARRIBA/ABAJO: CAMBIA')
        dc.color(GREEN); dc.text(c, L['G_HINT2_Y'], S, 'START: SIGUIENTE')
        return dc
    if k == 'done':
        dc.color(st['title_col']); dc.text(c, L['D_TITLE_Y'], S, st['title'])
        dc.color(WHITE); dc.text(c, L['D_L1_Y'], X, st['l1'])
        dc.text(c, L['D_L2_Y'], X, st['l2'])
        dc.color(GOLD)
        if st.get('l3'):
            dc.text(c, L['D_L3_Y'], X, st['l3'])
        if st.get('l4'):
            dc.text(c, L['D_L4_Y'], X, st['l4'])
        dc.color(GRAY); dc.text(c, L['D_L5_Y'], X, st['l5'])
        dc.text(c, L['D_HINT_Y'], X, 'ATRÁS: SALIR')
        return dc
    dc.pen = L['RING_PEN']
    dc.color(DARK); dc.arc(120, 120, L['RING_R'], 0, 360, False)
    dc.color(st['col']); dc.arc(120, 120, L['RING_R'], 90, 90 - 360 * st['ring'], True)
    dc.color(GOLD); dc.text(c, L['TOP_Y'], X, st['top'])
    dc.color(st['col']); dc.text(c, L['STATE_Y'], S, st['state'])
    dc.color(WHITE); dc.text(c, L['TIME_Y'], T, st['clock'])
    dc.text(c, L['L1_Y'], X, st['l1'])
    dc.color(GRAY); dc.text(c, L['L2_Y'], X, st['l2'])
    dc.color(GREEN); dc.text(c, L['HINT_Y'], X, st['hint'])
    foot(dc, X, st['total'], st['hr'])
    return dc


CASES = {
    'listo_via': dict(kind='ready', type='VÍA', grade='ÚLTIMO GRADO 6a+'),
    'listo_bloque': dict(kind='ready', type='BLOQUE', grade='ÚLTIMO GRADO 6C+'),
    'calentando': dict(kind='run', top='VÍAS: 0', state='CALENTANDO', col=BLUE, ring=0.3, clock='4:12',
                       l1='0 ENCADENES', l2='', hint='START: A ESCALAR', total='4:12', hr='92'),
    'descanso': dict(kind='run', top='VÍAS: 5', state='DESCANSO', col=BLUE, ring=0.66, clock='1:58',
                     l1='3 ENCADENES', l2='6b+ · CON CAÍDAS', hint='START: A ESCALAR', total='48:20', hr='104'),
    'listo_ya': dict(kind='run', top='BLOQUES: 12', state='¡A POR OTRO!', col=GREEN, ring=1.0, clock='10:05',
                     l1='7 ENCADENES', l2='7A+ · SIN ACABAR', hint='START: A ESCALAR', total='1:32:10', hr='88'),
    'escalando': dict(kind='run', top='VÍA 6', state='ESCALANDO', col=GREEN, ring=1.0, clock='2:31',
                      l1='ALTURA +14 M', l2='MÁXIMO HOY 6c', hint='START: TERMINAR', total='51:02', hr='158'),
    'escalando_b': dict(kind='run', top='BLOQUE 13', state='ESCALANDO', col=GREEN, ring=1.0, clock='0:45',
                        l1='', l2='MÁXIMO HOY 7A+', hint='START: TERMINAR', total='1:33:40', hr='171'),
    'grado': dict(kind='grade', sub='VÍA 6 · 2:31', grade='6b+'),
    'grado_bloque': dict(kind='grade', sub='BLOQUE 12 · 0:45', grade='7C+'),
    'hecho': dict(kind='done', title='GUARDADO', title_col=GREEN, l1='8 VÍAS · 12 BLOQUES', l2='11 ENCADENES',
                  l3='MÁXIMO VÍA 6c+', l4='MÁXIMO BLOQUE 6A+', l5='1:32:10 EN TOTAL'),
}


def main():
    probs = []
    imgs = []
    for name, st in CASES.items():
        dc = render(st)
        probs += check(dc, name)
        imgs.append((name, dc))
    cols = 5
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new('RGB', (490 * cols + 10, 530 * rows + 10), (30, 30, 30))
    d = ImageDraw.Draw(sheet); f = ImageFont.load_default()
    for i, (n, dc) in enumerate(imgs):
        x, y = 10 + (i % cols) * 490, 10 + (i // cols) * 530
        sheet.paste(dc.final(), (x, y + 30)); d.text((x + 5, y + 2), n, fill=(220, 220, 220), font=f)
    sheet.save(os.path.join(HERE, 'preview', 'escalada.png'))
    export()
    print('\n'.join(probs) if probs else 'Sin problemas')


if __name__ == '__main__':
    main()
