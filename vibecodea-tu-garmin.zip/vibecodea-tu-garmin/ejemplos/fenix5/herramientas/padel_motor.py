"""Motor de puntuación de pádel (gemelo en Python del de Monkey C, para probar las reglas).

Modos de iguales (40-40): 0 = ventaja, 1 = punto de oro, 2 = star point (ventaja en los dos
primeros iguales y punto decisivo en el tercero). Mejor de 3 sets a 6 juegos con tie-break a 7
en 6-6; el tercer set puede ser súper tie-break a 10.
"""
class Padel:
    def __init__(s, modo=1, super_tb=True, saca=0):
        s.modo, s.super_tb = modo, super_tb
        s.sets = []            # [[nos, ellos], ...] terminados
        s.g = [0, 0]           # juegos del set en curso
        s.p = [0, 0]           # puntos del juego o del tie-break
        s.tb = False           # tie-break (o súper tie-break) en curso
        s.tb_meta = 7
        s.tb_first = 0
        s.server = saca
        s.iguales = 0          # veces que se ha llegado a 40-40 en este juego
        s.done = False
        s.ganador = -1
        s.tot = [0, 0]
        s.hist = []
        s.evento = ''          # 'juego', 'set', 'partido', 'lado'

    def snap(s):
        return (list(map(list, s.sets)), list(s.g), list(s.p), s.tb, s.tb_meta, s.tb_first, s.server,
                s.iguales, s.done, s.ganador, list(s.tot))

    def undo(s):
        if s.hist:
            (sets, g, p, s.tb, s.tb_meta, s.tb_first, s.server, s.iguales, s.done, s.ganador, tot) = s.hist.pop()
            s.sets, s.g, s.p, s.tot = sets, g, p, tot

    def sets_ganados(s, k):
        return sum(1 for a in s.sets if a[k] > a[1 - k])

    def punto(s, k):
        if s.done:
            return
        s.hist.append(s.snap())
        s.evento = ''
        s.tot[k] += 1
        o = 1 - k
        if s.tb:
            s.p[k] += 1
            n = s.p[0] + s.p[1]
            if s.p[k] >= s.tb_meta and s.p[k] - s.p[o] >= 2:
                s.g[k] += 1
                s._fin_set(k, tb_inicio=s.tb_first)
                return
            # saque en tie-break: el primero saca 1 punto, luego cada 2
            s.server = s.tb_first if ((n - 1) // 2) % 2 == 1 else 1 - s.tb_first
            if n % 6 == 0:
                s.evento = 'lado'
            return
        s.p[k] += 1
        a, b = s.p[k], s.p[o]
        if a >= 3 and b >= 3:
            if a == b:
                s.iguales += 1
                return
            decisivo = (s.modo == 1) or (s.modo == 2 and s.iguales >= 3)
            if a - b >= 2 or decisivo:
                s._fin_juego(k)
            return
        if a >= 4 and a - b >= 2:
            s._fin_juego(k)

    def _fin_juego(s, k):
        s.g[k] += 1
        s.p = [0, 0]
        s.iguales = 0
        s.server = 1 - s.server
        s.evento = 'juego'
        a, b = s.g[k], s.g[1 - k]
        if a >= 6 and a - b >= 2:
            s._fin_set(k)
            return
        if s.g[0] == 6 and s.g[1] == 6:
            s._empieza_tb(7)
            return
        if (s.g[0] + s.g[1]) % 2 == 1:
            s.evento = 'lado'

    def _empieza_tb(s, meta):
        s.tb = True
        s.tb_meta = meta
        s.tb_first = s.server
        s.p = [0, 0]

    def _fin_set(s, k, tb_inicio=None):
        s.sets.append(list(s.g))
        s.g = [0, 0]
        s.p = [0, 0]
        s.iguales = 0
        if tb_inicio is not None:
            s.server = 1 - tb_inicio
        s.tb = False
        s.evento = 'set'
        if s.sets_ganados(k) == 2:
            s.done = True
            s.ganador = k
            s.evento = 'partido'
            return
        if len(s.sets) == 2 and s.super_tb:
            s._empieza_tb(10)

    def marcador(s):
        """Texto de los puntos de cada equipo como en el reloj."""
        if s.tb:
            return str(s.p[0]), str(s.p[1])
        n = ['0', '15', '30', '40']
        a, b = s.p
        if a >= 3 and b >= 3:
            if a == b:
                return '40', '40'
            return ('AD', '40') if a > b else ('40', 'AD')
        return n[min(a, 3)], n[min(b, 3)]
