"""Vista previa y comprobación de «Volver F5» (240x240, fenix 5). Exporta VolverLayout.mc."""
import os, math
from PIL import Image, ImageDraw, ImageFont
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'volver', 'source', 'VolverLayout.mc')

LAYOUT = {
    # navegando
    'TITLE_Y': 26, 'ARROW_X': 120, 'ARROW_Y': 90, 'ARROW_L': 38, 'ARROW_W': 26,
    'DIST_Y': 122, 'UNIT_DY': 33, 'UNIT_GAP': 4, 'FOOT_Y': 184,
    # guardar
    'S_TITLE_Y': 34, 'S_LABEL_Y': 62, 'S_HINT_Y': 88, 'S_GPS_Y': 116, 'S_START_Y': 142, 'S_BACK_Y': 170,
}
L = LAYOUT
GOLD, WHITE, GRAY, GREEN, YELLOW, RED = 0xFFAA00, 0xFFFFFF, 0xAAAAAA, 0x55FF55, 0xFFFF55, 0xFF5555


def export():
    lines = ['// GENERADO por volver_preview.py: no editar a mano.', 'module VolverLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def arrow_pts(deg):
    """Flecha que apunta en «deg» grados (0 = arriba, sentido horario)."""
    a = math.radians(deg)
    cx, cy, l, w = L['ARROW_X'], L['ARROW_Y'], L['ARROW_L'], L['ARROW_W']
    base = [(0, -l), (w, l * 0.75), (0, l * 0.35), (-w, l * 0.75)]
    return [(cx + x * math.cos(a) - y * math.sin(a), cy + x * math.sin(a) + y * math.cos(a)) for x, y in base]


def render(st):
    A = BMFont('alt'); M = BMFont('med'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); c = 120
    if st['kind'] == 'save':
        dc.color(WHITE); dc.text(c, L['S_TITLE_Y'], X, 'GUARDAR SITIO')
        dc.color(GOLD); dc.text(c, L['S_LABEL_Y'], S, st['label'])
        dc.color(GRAY); dc.text(c, L['S_HINT_Y'], X, 'ARRIBA/ABAJO: CAMBIA')
        dc.color(st['gps_col']); dc.text(c, L['S_GPS_Y'], S, st['gps'])
        dc.color(GREEN); dc.text(c, L['S_START_Y'], S, 'START: GUARDAR AQUÍ')
        dc.color(GRAY); dc.text(c, L['S_BACK_Y'], X, 'ATRÁS: SALIR')
        return dc
    dc.color(GOLD); dc.text(c, L['TITLE_Y'], X, st['title'])
    if st.get('arrow') is not None:
        pts = arrow_pts(st['arrow'])
        dc.color(st.get('arrow_col', WHITE)); dc.polygon(pts)
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        dc.boxes.append(('flecha', 'flecha', min(xs), min(ys), max(xs), max(ys)))
    else:
        dc.color(GREEN); dc.text(c, L['ARROW_Y'] - 10, S, st['center'])
    d, u = st['dist'], st['unit']
    wd, wu = A.width(d), M.width(u)
    left = c - (wd + L['UNIT_GAP'] + wu) // 2
    dc.color(WHITE); dc.text(left, L['DIST_Y'], A, d, 'l', 'dist')
    dc.text(left + wd + L['UNIT_GAP'], L['DIST_Y'] + L['UNIT_DY'], M, u, 'l', 'dist')
    dc.color(st['foot_col']); dc.text(c, L['FOOT_Y'], X, st['foot'])
    return dc


CASES = {
    'guardar': dict(kind='save', label='COCHE', gps='GPS LISTO', gps_col=GREEN),
    'buscando': dict(kind='save', label='TIENDA', gps='BUSCANDO GPS...', gps_col=YELLOW),
    'lejos': dict(kind='nav', title='COCHE · 18:20', arrow=35, dist='1,2', unit='KM', foot='GPS BIEN', foot_col=GREEN),
    'cerca': dict(kind='nav', title='TIENDA · 23:05', arrow=200, dist='350', unit='M', foot='GPS FLOJO', foot_col=YELLOW),
    'peor': dict(kind='nav', title='SITIO · 23:05', arrow=90, dist='9999', unit='KM', foot='SIN GPS', foot_col=RED),
    'llegado': dict(kind='nav', title='COCHE · 18:20', arrow=None, center='¡AQUÍ ESTÁ!', dist='8', unit='M',
                    foot='START: OPCIONES', foot_col=GRAY),
}


def main():
    probs = []
    imgs = []
    for name, st in CASES.items():
        dc = render(st)
        probs += check(dc, name)
        imgs.append((name, dc))
    cols = 3
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new('RGB', (490 * cols + 10, 530 * rows + 10), (30, 30, 30))
    d = ImageDraw.Draw(sheet); f = ImageFont.load_default()
    for i, (n, dc) in enumerate(imgs):
        x, y = 10 + (i % cols) * 490, 10 + (i // cols) * 530
        sheet.paste(dc.final(), (x, y + 30)); d.text((x + 5, y + 2), n, fill=(220, 220, 220), font=f)
    sheet.save(os.path.join(HERE, 'preview', 'volver.png'))
    export()
    print('\n'.join(probs) if probs else 'Sin problemas')


if __name__ == '__main__':
    main()
