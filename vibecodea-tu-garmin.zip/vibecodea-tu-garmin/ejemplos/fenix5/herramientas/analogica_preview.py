"""Vista previa y comprobación de la esfera «F5 Analógica» (240x240, fenix 5). Exporta AnaLayout.mc."""
import os, math
from PIL import Image, ImageDraw, ImageFont
from preview import BMFont, DC, check, moon_pts

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'analogica', 'source', 'AnaLayout.mc')

LAYOUT = {
    'TICK_OUT': 118, 'TICK_IN': 106, 'TICK_MAIN_IN': 100, 'TICK_MIN_IN': 114, 'TICK_PEN': 3, 'TICK_MAIN_PEN': 5,
    'MOON_Y': 31, 'MOON_R': 7, 'ZOD_Y': 23, 'ZOD_GAP': 4,
    'DATE_Y': 42,
    'SUB_L_X': 64, 'SUB_R_X': 176, 'SUB_Y': 120, 'SUB_R': 22, 'SUB_PEN': 3, 'SUB_NUM_Y': 107, 'SUB_ICON_Y': 132,
    'STATUS_Y': 148, 'STATUS_MAXW': 190, 'ROW_Y': 167, 'ROW_ICON_Y': 171, 'BOT_Y': 186, 'BOT_ICON_Y': 190, 'ICON_GAP': 16, 'PAIR_GAP': 12,
    'HOUR_LEN': 58, 'HOUR_W': 5, 'MIN_LEN': 90, 'MIN_W': 4, 'HAND_TAIL': 12, 'SEC_LEN': 102, 'SEC_TAIL': 20, 'CAP_R': 5,
}
L = LAYOUT
GOLD, WHITE, GRAY, DARK, GREEN, YELLOW, RED, BLUE, SKY, ORANGE = (0xFFAA00, 0xFFFFFF, 0xAAAAAA, 0x555555, 0x55FF55,
                                                               0xFFFF55, 0xFF0000, 0x00AAFF, 0x55AAFF, 0xFF5500)


def export():
    lines = ['// GENERADO por analogica_preview.py: no editar a mano.', 'module AnaLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def polar(r, deg_from_12):
    a = math.radians(deg_from_12)
    return 120 + r * math.sin(a), 120 - r * math.cos(a)


def hand_pts(deg, length, w, tail):
    a = math.radians(deg)
    dx, dy = math.sin(a), -math.cos(a)
    px, py = math.cos(a), math.sin(a)
    c = 120
    return [(c + w * px - tail * dx, c + w * py - tail * dy),
            (c + 0.7 * w * px + (length - 8) * dx, c + 0.7 * w * py + (length - 8) * dy),
            (c + length * dx, c + length * dy),
            (c - 0.7 * w * px + (length - 8) * dx, c - 0.7 * w * py + (length - 8) * dy),
            (c - w * px - tail * dx, c - w * py - tail * dy)]


def subdial(dc, M, cx, frac, col, num, num_col, icon, tag):
    dc.pen = L['SUB_PEN']
    dc.color(DARK); dc.arc(cx, L['SUB_Y'], L['SUB_R'], 225, -45, True)
    deg = int(270 * max(0.0, min(1.0, frac)))
    if deg >= 2:
        dc.color(col); dc.arc(cx, L['SUB_Y'], L['SUB_R'], 225, 225 - deg, True)
    dc.pen = 1
    dc.color(num_col); dc.text(cx, L['SUB_NUM_Y'], M, num, 'c', tag)
    dc.bitmap(cx - 7, L['SUB_ICON_Y'], icon, tag + ' icono')


def pair(dc, X, y, icon_y, items):
    """items: [(icono o None, texto, color)] centrados en una fila."""
    widths = [(L['ICON_GAP'] if ic else 0) + X.width(t) for ic, t, _ in items]
    total = sum(widths) + L['PAIR_GAP'] * (len(items) - 1)
    x = 120 - total // 2
    for (ic, t, col), w in zip(items, widths):
        if ic:
            dc.bitmap(x, icon_y, ic, f'fila {y}')
        dc.color(col); dc.text(x + (L['ICON_GAP'] if ic else 0), y, X, t, 'l', f'fila {y}')
        x += w + L['PAIR_GAP']


def render(st):
    M = BMFont('med'); S = BMFont('small'); X = BMFont('xs'); Z = BMFont('zod')
    dc = DC()
    # índices: minutos (puntos finos) y horas (12, 3, 6 y 9 más largos y oro el de las 12)
    for i in range(60):
        deg = i * 6
        if i % 5 == 0:
            main = i % 15 == 0
            dc.pen = L['TICK_MAIN_PEN'] if main else L['TICK_PEN']
            dc.color(GOLD if i == 0 else WHITE)
            p0 = polar(L['TICK_MAIN_IN'] if main else L['TICK_IN'], deg); p1 = polar(L['TICK_OUT'], deg)
        else:
            dc.pen = 1; dc.color(DARK)
            p0 = polar(L['TICK_MIN_IN'], deg); p1 = polar(L['TICK_OUT'], deg)
        dc.d.line([p0, p1], fill=dc.fg, width=dc.pen)
    dc.pen = 1
    # luna + signo, fecha
    my, mr = L['MOON_Y'], L['MOON_R']
    zch = chr(ord('a') + st['sign'])
    gw = 2 * mr + 1 + L['ZOD_GAP'] + Z.width(zch)
    mx = 120 - gw // 2 + mr
    dc.color(DARK); dc.circle(mx, my, mr)
    dc.color(0xFFFFAA); dc.polygon(moon_pts(mx, my, mr, st['phase']))
    dc.boxes.append(('luna', 'luna', mx - mr, my - mr, mx + mr + 1, my + mr + 1)); dc.circles.append(('luna', mx, my, mr))
    dc.color(GOLD if st['sign'] == -1 else SKY); dc.text(mx + mr + 1 + L['ZOD_GAP'], L['ZOD_Y'], Z, zch, 'l', 'signo')
    dc.color(GOLD); dc.text(120, L['DATE_Y'], S, st['date'])
    # subesferas: energía (izquierda) y pasos (derecha)
    subdial(dc, M, L['SUB_L_X'], st['energy_frac'], st['energy_col'], st['energy'], st['energy_col'], 'bolt', 'energía')
    subdial(dc, M, L['SUB_R_X'], st['steps_frac'], GREEN if st['steps_frac'] >= 1 else BLUE, st['steps'], WHITE,
            'steps', 'pasos')
    # estado, tiempo y pulso, móvil y batería
    status = st['status']
    if X.width(status) > L['STATUS_MAXW']:
        status = status.replace(' · ', ' ')
    dc.color(st['status_col']); dc.text(120, L['STATUS_Y'], X, status)
    pair(dc, X, L['ROW_Y'], L['ROW_ICON_Y'], [(st['wx'], st['temp'], WHITE), ('heart', st['hr'], WHITE)])
    pair(dc, X, L['BOT_Y'], L['BOT_ICON_Y'], [('bt' if st['bt'] else None, st['battery'], GOLD if st['bat_ok'] else RED),
                                             ('bell', st['notif'], WHITE if st['bt'] else DARK)])
    # agujas (encima de todo): sombra negra y blanco
    h, m, s = st['hms']
    for deg, length, w in [((h % 12) * 30 + m * 0.5, L['HOUR_LEN'], L['HOUR_W']), (m * 6 + (s or 0) * 0.1, L['MIN_LEN'], L['MIN_W'])]:
        dc.color(0x000000); dc.polygon(hand_pts(deg, length + 1, w + 1, L['HAND_TAIL'] + 1))
        dc.color(WHITE); dc.polygon(hand_pts(deg, length, w, L['HAND_TAIL']))
    if s is not None:
        a = math.radians(s * 6)
        dx, dy = math.sin(a), -math.cos(a)
        dc.color(ORANGE)
        dc.d.line([(120 - L['SEC_TAIL'] * dx, 120 - L['SEC_TAIL'] * dy), (120 + L['SEC_LEN'] * dx, 120 + L['SEC_LEN'] * dy)],
                  fill=dc.fg, width=2)
    dc.color(ORANGE if s is not None else GOLD); dc.circle(120, 120, L['CAP_R'])
    dc.color(0x000000); dc.circle(120, 120, 1)
    return dc


base = dict(sign=8, phase=0.295, date='MIÉ 18 NOV', energy='72', energy_frac=0.72, energy_col=GREEN, steps='8.2K',
            steps_frac=0.82, status='ENERGÍA 72 DE 100', status_col=GREEN, wx='wx_partly', temp='12°', hr='64',
            battery='76%', bat_ok=True, bt=True, notif='3', hms=(10, 10, None))
CASES = {
    'diez_y_diez': dict(base),
    'muneca': dict(base, hms=(15, 44, 25), status='15°/6° · LLUVIA 70%', status_col=WHITE, wx='wx_rain'),
    'seis_y_media': dict(base, hms=(6, 32, None), status='NOCHE 60 · MUY CARGADO', status_col=RED, sign=1),
    'tormenta': dict(base, hms=(21, 5, 50), status='¡TORMENTA! -5 HPA/3 H', status_col=RED, wx='wx_storm',
                     energy='37', energy_frac=0.37, energy_col=YELLOW),
    'peor': dict(base, hms=(23, 58, None), energy='--', energy_frac=0, energy_col=GRAY, steps='23K', steps_frac=1.0,
                 status='LUNA LLENA EN 11 DÍAS', status_col=0xFFFFAA, wx='wx_snow', temp='-12°', hr='188',
                 battery='9%', bat_ok=False, bt=False, notif='99', date='MIÉ 30 SEP'),
    'manana': dict(base, hms=(8, 5, 12), status='NOCHE 51 · FRESCO', status_col=GREEN, energy='100', energy_frac=1.0,
                   steps='850', steps_frac=0.08, temp='7°', wx='wx_sun', hr='--'),
}


def main():
    probs = []
    imgs = []
    for name, st in CASES.items():
        dc = render(st)
        probs += check(dc, name)
        imgs.append((name, dc))
    cols = 3
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new('RGB', (490 * cols + 10, 530 * rows + 10), (30, 30, 30))
    d = ImageDraw.Draw(sheet); f = ImageFont.load_default()
    for i, (n, dc) in enumerate(imgs):
        x, y = 10 + (i % cols) * 490, 10 + (i // cols) * 530
        sheet.paste(dc.final(), (x, y + 30)); d.text((x + 5, y + 2), n, fill=(220, 220, 220), font=f)
    sheet.save(os.path.join(HERE, 'preview', 'analogica.png'))
    export()
    print('\n'.join(probs) if probs else 'Sin problemas')


if __name__ == '__main__':
    main()
