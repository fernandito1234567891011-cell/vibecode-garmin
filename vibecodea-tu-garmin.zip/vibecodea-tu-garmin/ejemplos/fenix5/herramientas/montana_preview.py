"""Vista previa y comprobación del widget «Montaña F5» (240x240, fenix 5).
Páginas: 0 resumen, 1 presión, 2 altitud, 3 temperatura, 4 sol y luna. Exporta CumbreLayout.mc."""
import os, math
from PIL import Image, ImageDraw, ImageFont
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'montana', 'source', 'CumbreLayout.mc')

LAYOUT = {
    # resumen
    'ALT_LBL_Y': 22, 'ALT_Y': 34, 'ALT_M_DY': 33, 'ALT_M_GAP': 4,
    'CLIMB_Y': 94, 'PRES_Y': 114, 'SUN_Y': 136, 'MOON_Y': 156, 'HINT_Y': 184,
    # gráficos
    'G_TITLE_Y': 28, 'G_VAL_Y': 44, 'G_X0': 38, 'G_X1': 202, 'G_TOP': 72, 'G_BOT': 124,
    'G_AXIS_Y': 127, 'G_L1_Y': 147, 'G_L2_Y': 167,
    # sol y luna
    'S_TITLE_Y': 28, 'S_ROW_Y': 46, 'S_ROW_DY': 18, 'S_LX': 46, 'S_RX': 194,
    'S_LEFT_Y': 122, 'S_MOON_Y': 144, 'S_NEXT_Y': 163,
    # puntos de página
    'DOTS_Y': 205, 'DOTS_DX': 10,
}
L = LAYOUT

GOLD, WHITE, GRAY, BLUE, GREEN, YELLOW, RED = 0xFFAA00, 0xFFFFFF, 0xAAAAAA, 0x55AAFF, 0x55FF55, 0xFFFF55, 0xFF5555


def export():
    lines = ['// GENERADO por cumbre_preview.py: no editar a mano.', 'module CumbreLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def dots(dc, page):
    for i in range(5):
        x = 120 + (i - 2) * L['DOTS_DX']
        r = 3 if i == page else 2
        dc.color(WHITE if i == page else 0x555555)
        dc.circle(x, L['DOTS_Y'], r)
        dc.circles.append((f'punto {i}', x, L['DOTS_Y'], r))


def graph(dc, vals, line_col, fill_col, min_range):
    x0, x1, top, bot = L['G_X0'], L['G_X1'], L['G_TOP'], L['G_BOT']
    lo, hi = min(vals), max(vals)
    if hi - lo < min_range:
        mid = (hi + lo) / 2; lo, hi = mid - min_range / 2, mid + min_range / 2
    n = len(vals)
    pts = [(x0 + round(i * (x1 - x0) / (n - 1)), bot - round((v - lo) * (bot - top) / (hi - lo))) for i, v in enumerate(vals)]
    dc.color(fill_col); dc.polygon(pts + [(x1, bot), (x0, bot)])
    dc.color(line_col); dc.d.line(pts, fill=dc.fg, width=2)
    dc.circle(pts[-1][0], pts[-1][1], 3)
    dc.color(0x555555); dc.d.line([(x0, bot), (x1, bot)], fill=dc.fg, width=1)
    dc.boxes.append(('gráfico', 'gráfico', x0, top - 3, x1 + 3, bot + 1))


def render(st):
    B = BMFont('alt'); M = BMFont('med'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); c = 120
    p = st['page']
    if p == 0:
        dc.color(GRAY); dc.text(c, L['ALT_LBL_Y'], X, 'ALTITUD')
        alt = st['alt']; wa = B.width(alt); wm = M.width('M')
        left = c - (wa + L['ALT_M_GAP'] + wm) // 2
        dc.color(WHITE); dc.text(left, L['ALT_Y'], B, alt, 'l', 'alt')
        dc.text(left + wa + L['ALT_M_GAP'], L['ALT_Y'] + L['ALT_M_DY'], M, 'M', 'l', 'alt')
        dc.color(GRAY); dc.text(c, L['CLIMB_Y'], X, st['climb'])
        dc.color(st['pres_col']); dc.text(c, L['PRES_Y'], S, st['pres'])
        dc.color(st.get('sun_col', GOLD)); dc.text(c, L['SUN_Y'], X, st['sun'])
        dc.color(WHITE); dc.text(c, L['MOON_Y'], X, st['moon'])
        dc.color(GRAY); dc.text(c, L['HINT_Y'], X, 'START: MÁS')
        return dc
    if p in (1, 2, 3):
        dc.color(st.get('title_col', GOLD)); dc.text(c, L['G_TITLE_Y'], X, st['title'])
        dc.color(WHITE); dc.text(c, L['G_VAL_Y'], M, st['val'])
        if st.get('vals'):
            graph(dc, st['vals'], st['line'], st['fill'], st['min_range'])
            dc.color(GRAY); dc.text(L['G_X0'], L['G_AXIS_Y'], X, '-4 H', 'l')
            dc.text(L['G_X1'], L['G_AXIS_Y'], X, 'AHORA', 'r')
        else:
            dc.color(GRAY); dc.text(c, (L['G_TOP'] + L['G_BOT']) // 2 - 8, X, 'SIN DATOS TODAVÍA')
        dc.color(WHITE); dc.text(c, L['G_L1_Y'], X, st['l1'])
        dc.color(st['l2_col']); dc.text(c, L['G_L2_Y'], S, st['l2'])
        dots(dc, p)
        return dc
    dc.color(GOLD); dc.text(c, L['S_TITLE_Y'], X, st['title'])
    for i, (lab, val) in enumerate(st['rows']):
        y = L['S_ROW_Y'] + i * L['S_ROW_DY']
        dc.color(GRAY); dc.text(L['S_LX'], y, X, lab, 'l', f'fila{i}l')
        dc.color(WHITE); dc.text(L['S_RX'], y, X, val, 'r', f'fila{i}v')
    dc.color(st['left_col']); dc.text(c, L['S_LEFT_Y'], S, st['left'])
    dc.color(WHITE); dc.text(c, L['S_MOON_Y'], X, st['moon'])
    dc.color(GRAY); dc.text(c, L['S_NEXT_Y'], X, st['next'])
    dots(dc, 4)
    return dc


def wave(n, a, b, k=1.0):
    return [a + (b - a) * (i / (n - 1)) + 0.6 * math.sin(i / 3 * k) for i in range(n)]


CASES = {
    'resumen': dict(page=0, alt='2350', climb='+640 M · -120 M EN 4 H', pres='1013 HPA · ESTABLE', pres_col=BLUE,
                    sun='PUESTA 18:02 · EN 2:05', moon='9° AIRE · LUNA 78 %'),
    'tormenta': dict(page=0, alt='4807', climb='+1850 M · -1850 M EN 4 H', pres='¡TORMENTA! -5 HPA/3 H', pres_col=RED,
                     sun='AMANECE 10:04 · EN 11:59', sun_col=BLUE, moon='-25° AIRE · LUNA 100 %'),
    'sin_datos': dict(page=0, alt='--', climb='SIN HISTORIAL TODAVÍA', pres='SIN DATOS DE PRESIÓN', pres_col=GRAY,
                      sun='ÚLTIMA LUZ EN 0:12', sun_col=0xFF5500, moon='LUNA 3 %'),
    'bajo_cero': dict(page=0, alt='-412', climb='+0 M · -3 M EN 4 H', pres='1031 HPA · BAJA 2,5', pres_col=YELLOW,
                      sun='SALE EL SOL EN 0:15', moon='LUNA 50 %'),
    'presion': dict(page=1, title='¡TORMENTA!', title_col=RED, val='1009 HPA', vals=wave(43, 1014.2, 1009.1), line=BLUE,
                    fill=0x0055AA, min_range=4, l1='MÍN 1009 · MÁX 1015', l2='-4,4 HPA EN 3 H', l2_col=RED),
    'altitud': dict(page=2, title='ALTITUD', val='2350 M', vals=[1710 + 15 * i for i in range(43)], line=WHITE,
                    fill=0x555555, min_range=20, l1='+640 M · -120 M', l2='SUBES 350 M/H', l2_col=GREEN),
    'temperatura': dict(page=3, title='TEMPERATURA', val='-12,5°', vals=wave(43, 29, -12.5, 2), line=0xFFAA55,
                        fill=0xAA5500, min_range=3, l1='MÍN -13° · MÁX 29°', l2='MIDE EL AIRE', l2_col=GREEN),
    'temp_muneca': dict(page=3, title='TEMPERATURA', val='29,5°', vals=wave(43, 28, 30), line=0xFFAA55,
                        fill=0xAA5500, min_range=3, l1='QUÍTATELO 20 MIN', l2='MIDE TU MUÑECA', l2_col=YELLOW),
    'sin_hist': dict(page=1, title='PRESIÓN', val='--', vals=None, l1='EL RELOJ GUARDA 4 H', l2='ESPERA UN POCO', l2_col=GRAY),
    'sol_dia': dict(page=4, title='SOL HOY', rows=[('PRIMERA LUZ', '7:31'), ('SALIDA', '7:59'), ('PUESTA', '18:02'),
                    ('ÚLTIMA LUZ', '18:30')], left='QUEDAN 2:05 DE SOL', left_col=GOLD, moon='LUNA 78 % · CRECIENTE',
                    next='LLENA EN 3 DÍAS'),
    'sol_noche': dict(page=4, title='SOL MAÑANA', rows=[('PRIMERA LUZ', '10:04'), ('SALIDA', '10:38'),
                      ('PUESTA', '21:48'), ('ÚLTIMA LUZ', '22:21')], left='AMANECE EN 11:59', left_col=BLUE,
                      moon='LUNA 100 % · MENGUANTE', next='NUEVA EN 14 DÍAS'),
}


def main():
    probs = []
    imgs = []
    for name, st in CASES.items():
        dc = render(st)
        probs += check(dc, name)
        imgs.append((name, dc))
    cols = 5
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new('RGB', (490 * cols + 10, 530 * rows + 10), (30, 30, 30))
    d = ImageDraw.Draw(sheet)
    f = ImageFont.load_default()
    for i, (n, dc) in enumerate(imgs):
        x, y = 10 + (i % cols) * 490, 10 + (i // cols) * 530
        sheet.paste(dc.final(), (x, y + 30)); d.text((x + 5, y + 2), n, fill=(220, 220, 220), font=f)
    os.makedirs(os.path.join(HERE, 'preview'), exist_ok=True)
    sheet.save(os.path.join(HERE, 'preview', 'cumbre.png'))
    export()
    print('\n'.join(probs) if probs else 'Sin problemas')


if __name__ == '__main__':
    main()
