"""Vista previa y comprobación de «Pádel F5» (240x240, fenix 5).
Arriba NOSOTROS (botón ARRIBA), abajo ELLOS (botón ABAJO). Exporta PadelLayout.mc."""
import os, sys, math
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'padel', 'source', 'PadelLayout.mc')

LAYOUT = {
    'NOS_LBL_Y': 24, 'NOS_PTS_Y': 26, 'NOS_G_Y': 47, 'NOS_BALL_Y': 63,
    'MID_Y': 98,
    'ELL_PTS_Y': 105, 'ELL_G_Y': 126, 'ELL_BALL_Y': 142, 'ELL_LBL_Y': 169,
    'FOOT_Y': 189, 'FOOT_ICON_Y': 193,
    'G_X': 50, 'BALL_X': 190, 'BALL_R': 6,
}
L = LAYOUT


def export():
    lines = ['// GENERADO por padel_preview.py: no editar a mano.', 'module PadelLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def render(st):
    B = BMFont('big'); M = BMFont('med'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); cx = 120
    dc.color(0x55FF55); dc.text(cx, L['NOS_LBL_Y'], X, 'NOSOTROS', 'c', 'lbl_nos')
    dc.color(0xFFFFFF); dc.text(cx, L['NOS_PTS_Y'], B, st['p_nos'], 'c', 'pts_nos')
    dc.color(0xAAAAAA); dc.text(L['G_X'], L['NOS_G_Y'], M, st['g_nos'], 'c', 'g_nos')
    dc.color(st['mid_col']); dc.text(cx, L['MID_Y'], S, st['mid'], 'c', 'medio')
    dc.color(0xFFFFFF); dc.text(cx, L['ELL_PTS_Y'], B, st['p_ell'], 'c', 'pts_ell')
    dc.color(0xAAAAAA); dc.text(L['G_X'], L['ELL_G_Y'], M, st['g_ell'], 'c', 'g_ell')
    dc.color(0xFF5555); dc.text(cx, L['ELL_LBL_Y'], X, 'ELLOS', 'c', 'lbl_ell')
    by = L['NOS_BALL_Y'] if st['saca'] == 0 else L['ELL_BALL_Y']
    dc.color(0xFFFF00); dc.circle(L['BALL_X'], by, L['BALL_R'])
    dc.circles.append(('bola', L['BALL_X'], by, L['BALL_R']))
    dc.boxes.append(('bola', 'bola', L['BALL_X'] - L['BALL_R'], by - L['BALL_R'], L['BALL_X'] + L['BALL_R'] + 1, by + L['BALL_R'] + 1))
    # pie: tiempo y pulso
    t = st['tiempo']; hr = st['hr']
    w = X.width(t) + 10 + 16 + X.width(hr)
    left = cx - w // 2
    dc.color(0xAAAAAA); dc.text(left, L['FOOT_Y'], X, t, 'l', 'tiempo')
    hx = left + X.width(t) + 10
    dc.bitmap(hx, L['FOOT_ICON_Y'], 'heart', 'pulso')
    dc.color(0xFFFFFF); dc.text(hx + 16, L['FOOT_Y'], X, hr, 'l', 'pulso')
    return dc


def main():
    export()
    probs = []
    shots = []
    cases = {
        'inicio': dict(p_nos='0', p_ell='0', g_nos='0', g_ell='0', mid='SET 1', mid_col=0xAAAAAA, saca=0, tiempo='0:00', hr='92'),
        'ventaja': dict(p_nos='AD', p_ell='40', g_nos='5', g_ell='4', mid='SET 2 · 6-4', mid_col=0xAAAAAA, saca=1, tiempo='48:12', hr='156'),
        'oro': dict(p_nos='40', p_ell='40', g_nos='3', g_ell='3', mid='PUNTO DE ORO', mid_col=0xFFAA00, saca=0, tiempo='1:02:40', hr='171'),
        'tiebreak': dict(p_nos='12', p_ell='11', g_nos='6', g_ell='6', mid='TIE-BREAK', mid_col=0x00AAFF, saca=1, tiempo='1:30:05', hr='188'),
        'lado': dict(p_nos='0', p_ell='0', g_nos='3', g_ell='2', mid='CAMBIO DE LADO', mid_col=0xFFFF55, saca=0, tiempo='22:10', hr='140'),
        'fin': dict(p_nos='6-4', p_ell='3-6', g_nos='', g_ell='', mid='¡PARTIDO GANADO!', mid_col=0x55FF55, saca=0, tiempo='1:45:00', hr='120'),
        'super': dict(p_nos='10', p_ell='8', g_nos='1', g_ell='1', mid='SÚPER TIE-BREAK', mid_col=0x00AAFF, saca=0, tiempo='1:55:00', hr='99'),
    }
    for name, st in cases.items():
        dc = render(st)
        probs += check(dc, name)
        shots.append((name, dc))
    from PIL import Image, ImageDraw, ImageFont
    f = ImageFont.truetype('/usr/share/fonts/opentype/inter/Inter-SemiBold.otf', 22)
    sel = shots[:6]
    sheet = Image.new('RGB', (490 * 3 + 10, 530 * 2 + 10), (30, 30, 30))
    d = ImageDraw.Draw(sheet)
    for i, (n, dc) in enumerate(sel):
        x = 10 + (i % 3) * 490; y = 10 + (i // 3) * 530
        sheet.paste(dc.final(), (x, y + 30)); d.text((x + 5, y + 2), n, fill=(220, 220, 220), font=f)
    sheet.save(os.path.join(HERE, 'preview', 'padel.png'))
    print('\n'.join(probs) if probs else 'Sin problemas')
    return 1 if probs else 0


if __name__ == '__main__':
    sys.exit(main())
