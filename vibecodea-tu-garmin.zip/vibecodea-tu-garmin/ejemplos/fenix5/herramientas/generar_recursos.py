"""Genera las fuentes (BMFont) y los iconos de la esfera F5+ v2 para el fenix 5.

Todo sin antialias: la pantalla del fenix 5 es MIP de 64 colores y no mezcla alfa.
Salida: assets/fonts/*.fnt + *.png, assets/icons/*.png
"""
import os
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join(os.path.dirname(__file__), 'assets')
INTER = '/usr/share/fonts/opentype/inter/InterDisplay-Bold.otf'
INTER_SB = '/usr/share/fonts/opentype/inter/InterDisplay-SemiBold.otf'

UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑÜ'
DIGITS = '0123456789'
PUNCT = ' .,:%+-/()·!¡?¿°'

FONTS = {
    # id: (ttf, px, charset)
    'time': (INTER, 62, DIGITS + ':'),
    'big': (INTER, 62, DIGITS + 'AD-'),
    'alt': (INTER, 54, DIGITS + '-,'),
    'grade': (INTER, 58, DIGITS + 'ABCabc+'),
    'med': (INTER, 20, DIGITS + '.:%+-/ ,°' + 'KMHPAL'),
    'small': (INTER, 16, UPPER + DIGITS + PUNCT + 'abc'),
    'xs': (INTER, 15, UPPER + DIGITS + PUNCT + 'abc'),
}


def make_font(fid, path, px, chars, remap=None):
    font = ImageFont.truetype(path, px)
    ascent, descent = font.getmetrics()
    line_h = ascent + descent
    glyphs = []
    for ch in chars:
        src = remap.get(ch, ch) if remap else ch
        x0, y0, x1, y1 = font.getbbox(src, anchor='ls')
        w, h = max(1, x1 - x0), max(1, y1 - y0)
        img = Image.new('1', (w, h), 0)
        d = ImageDraw.Draw(img)
        d.fontmode = '1'
        d.text((-x0, -y0), src, font=font, fill=1, anchor='ls')
        if ch == ' ':
            img = Image.new('1', (1, 1), 0)
            w, h, x0, y0 = 1, 1, 0, 0
        adv = int(round(font.getlength(src)))
        glyphs.append((ch, img, x0, ascent + y0, adv))
    # atlas en una fila (con 1 px de separación)
    W = sum(g[1].width + 1 for g in glyphs) + 1
    H = max(g[1].height for g in glyphs) + 2
    atlas = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    lines = []
    x = 1
    for ch, img, xo, yo, adv in glyphs:
        rgba = Image.new('RGBA', img.size, (0, 0, 0, 0))
        rgba.paste((255, 255, 255, 255), (0, 0), img)
        atlas.paste(rgba, (x, 1))
        lines.append(
            f'char id={ord(ch)} x={x} y=1 width={img.width} height={img.height} '
            f'xoffset={xo} yoffset={yo} xadvance={adv} page=0 chnl=15')
        x += img.width + 1
    os.makedirs(os.path.join(OUT, 'fonts'), exist_ok=True)
    atlas.save(os.path.join(OUT, 'fonts', f'{fid}.png'))
    with open(os.path.join(OUT, 'fonts', f'{fid}.fnt'), 'w', encoding='utf-8') as f:
        f.write(f'info face="{os.path.basename(path)}" size={px} bold=1 italic=0 charset="" '
                f'unicode=1 stretchH=100 smooth=0 aa=1 padding=0,0,0,0 spacing=1,1\n')
        f.write(f'common lineHeight={line_h} base={ascent} scaleW={W} scaleH={H} pages=1 packed=0\n')
        f.write(f'page id=0 file="{fid}.png"\n')
        f.write(f'chars count={len(lines)}\n')
        f.write('\n'.join(lines) + '\n')
    return line_h


# Iconos en pixel art (14x14). Letras = colores de la paleta del fenix 5.
PAL = {
    'R': (255, 0, 0), 'r': (255, 85, 85), 'B': (0, 170, 255), 'b': (0, 85, 255),
    'G': (255, 170, 0), 'Y': (255, 255, 0), 'O': (255, 85, 0), 'W': (255, 255, 255),
    'L': (170, 170, 170), 'D': (85, 85, 85), 'g': (0, 255, 0),
}
ICONS = {
    'heart': [
        '..............',
        '..RRR....RRR..',
        '.RRRRR..RRRRR.',
        'RRRRRRRRRRRRRR',
        'RRRRRRRRRRRRRR',
        'RRRRRRRRRRRRRR',
        'RRRRRRRRRRRRRR',
        '.RRRRRRRRRRRR.',
        '..RRRRRRRRRR..',
        '...RRRRRRRR...',
        '....RRRRRR....',
        '.....RRRR.....',
        '......RR......',
        '..............',
    ],
    'steps': [
        '..BBB.........',
        '.BBBBB........',
        '.BBBBB...BBB..',
        '.BBBBB..BBBBB.',
        '.BBBBB..BBBBB.',
        '..BBB...BBBBB.',
        '........BBBBB.',
        '..BB.....BBB..',
        '.BBBB.........',
        '.BBBB....BB...',
        '..BB....BBBB..',
        '........BBBB..',
        '.........BB...',
        '..............',
    ],
    'flame': [
        '......O.......',
        '......OO......',
        '.....OOO......',
        '.....OOOO.....',
        '....OOOOO..O..',
        '...OOOOOOO.O..',
        '..OOOOGOOOOO..',
        '..OOOGGOOOOO..',
        '.OOOGGGGOOOOO.',
        '.OOOGGYGGOOOO.',
        '.OOGGYYYGGOOO.',
        '..OGGYYYYGOO..',
        '...OGGYYGGO...',
        '....OOOOOO....',
    ],
    'stairs': [
        '..............',
        '..........LLL.',
        '..........L...',
        '.......LLLL...',
        '.......L......',
        '....LLLL......',
        '....L.........',
        '.LLLL.........',
        '.L............',
        '.L............',
        '..............',
        '..............',
        '..............',
        '..............',
    ],
    'bolt': [
        '........YY....',
        '.......YY.....',
        '......YYY.....',
        '.....YYY......',
        '....YYY.......',
        '...YYYYYYY....',
        '.......YYY....',
        '......YYY.....',
        '.....YYY......',
        '....YYY.......',
        '...YY.........',
        '..YY..........',
        '..............',
        '..............',
    ],
    'bell': [
        '......WW......',
        '.....WWWW.....',
        '....WWWWWW....',
        '...WWWWWWWW...',
        '...WWWWWWWW...',
        '...WWWWWWWW...',
        '..WWWWWWWWWW..',
        '..WWWWWWWWWW..',
        '.WWWWWWWWWWWW.',
        '..............',
        '.....WWWW.....',
        '......WW......',
        '..............',
        '..............',
    ],
    'bt': [
        '......B.......',
        '......BB......',
        '......B.B.....',
        '..B...B..B....',
        '...B..B.B.....',
        '....B.BB......',
        '.....BB.......',
        '....B.BB......',
        '...B..B.B.....',
        '..B...B..B....',
        '......B.B.....',
        '......BB......',
        '......B.......',
        '..............',
    ],
    'sunup': [
        '......G.......',
        '.....GGG......',
        '....GGGGG.....',
        '......G.......',
        '..............',
        '.G...GGG...G..',
        '..G.GGGGG.G...',
        '...GGGGGGG....',
        'GG.GGGGGGG.GG.',
        '..............',
        'GGGGGGGGGGGGG.',
        '..............',
        '..............',
        '..............',
    ],
    'sundown': [
        '......G.......',
        '......G.......',
        '....GGGGG.....',
        '.....GGG......',
        '......G.......',
        '.G...GGG...G..',
        '..G.GGGGG.G...',
        '...GGGGGGG....',
        'GG.GGGGGGG.GG.',
        '..............',
        'GGGGGGGGGGGGG.',
        '..............',
        '..............',
        '..............',
    ],
    'bed': [
        '..............',
        '..............',
        'G.............',
        'G.............',
        'G.GG..........',
        'G.GG.GGGGGGG..',
        'G.GGGGGGGGGGG.',
        'GGGGGGGGGGGGG.',
        'GGGGGGGGGGGGG.',
        'G...........G.',
        'G...........G.',
        '..............',
        '..............',
        '..............',
    ],
}


def _shape_icon(name, layers):
    """layers: lista de (color, función(x, y) -> bool) en coordenadas del centro de cada píxel."""
    img = Image.new('RGBA', (14, 14), (0, 0, 0, 0))
    for color, inside in layers:
        for y in range(14):
            for x in range(14):
                if inside(x + 0.5, y + 0.5):
                    img.putpixel((x, y), color + (255,))
    img.save(os.path.join(OUT, 'icons', f'{name}.png'))


def _disk(cx, cy, r):
    return lambda x, y: (x - cx) ** 2 + (y - cy) ** 2 <= r * r


def _rays(cx, cy, r0, r1, n=8, w=0.55):
    import math
    def f(x, y):
        dx, dy = x - cx, y - cy
        d = math.hypot(dx, dy)
        if d < r0 or d > r1:
            return False
        for k in range(n):
            a = 2 * math.pi * k / n
            # distancia del punto a la recta del rayo
            if abs(-math.sin(a) * dx + math.cos(a) * dy) <= w and (math.cos(a) * dx + math.sin(a) * dy) > 0:
                return True
        return False
    return f


def _cloud(ox=0, oy=0, s=1.0):
    parts = [_disk(4.6 * s + ox, 8.6 * s + oy, 2.6 * s), _disk(8.2 * s + ox, 6.6 * s + oy, 3.4 * s),
             _disk(11.0 * s + ox, 9.0 * s + oy, 2.2 * s)]
    rect = lambda x, y: 4.6 * s + ox <= x <= 11.0 * s + ox and 8.0 * s + oy <= y <= 11.2 * s + oy
    return lambda x, y: any(p(x, y) for p in parts) or rect(x, y)


def _poly(pts):
    def inside(x, y):
        c = False
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]; x2, y2 = pts[(i + 1) % n]
            if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
                c = not c
        return c
    return inside


def make_weather_icons():
    Y, y_, W, L, D, B = (255, 255, 0), (255, 255, 170), (255, 255, 255), (170, 170, 170), (85, 85, 85), (0, 170, 255)
    os.makedirs(os.path.join(OUT, 'icons'), exist_ok=True)
    _shape_icon('wx_sun', [(Y, _disk(7, 7, 3.3)), (Y, _rays(7, 7, 4.6, 6.9))])
    moon = _disk(7, 7, 5.6); bite = _disk(9.8, 5.2, 4.6)
    _shape_icon('wx_moon', [(y_, lambda x, y: moon(x, y) and not bite(x, y))])
    _shape_icon('wx_partly', [(Y, _disk(5, 5, 2.6)), (Y, _rays(5, 5, 3.6, 5.2)), (W, _cloud(1.2, 1.4, 0.9))])
    _shape_icon('wx_cloud', [(W, _cloud(0, 0.5))])
    fog = lambda x, y: (3 <= y <= 4 and 1 <= x <= 11) or (6.5 <= y <= 7.5 and 3 <= x <= 13) or (10 <= y <= 11 and 1 <= x <= 12)
    _shape_icon('wx_fog', [(L, fog)])
    drops = lambda x, y: any(abs((x - x0) + (y - 10.5) * 0.45) <= 0.55 and 9.5 <= y <= 13 for x0 in (4.5, 7.5, 10.5))
    _shape_icon('wx_rain', [(W, _cloud(0, -2.2)), (B, drops)])
    flakes = lambda x, y: any((abs(x - fx) <= 1.5 and abs(y - fy) <= 0.5) or (abs(x - fx) <= 0.5 and abs(y - fy) <= 1.5)
                              for fx, fy in ((3.5, 11.5), (7.5, 12.5), (11.5, 11.5)))
    _shape_icon('wx_snow', [(W, _cloud(0, -2.2)), (W, flakes)])
    bolt = _poly([(8.6, 7.6), (5.0, 11.2), (7.4, 11.2), (6.0, 14.2), (10.4, 9.6), (8.0, 9.6), (9.8, 7.6)])
    _shape_icon('wx_storm', [(L, _cloud(0, -2.2)), (Y, bolt)])


def make_icons():
    os.makedirs(os.path.join(OUT, 'icons'), exist_ok=True)
    for name, rows in ICONS.items():
        img = Image.new('RGBA', (14, 14), (0, 0, 0, 0))
        for y, row in enumerate(rows):
            for x, c in enumerate(row):
                if c != '.':
                    img.putpixel((x, y), PAL[c] + (255,))
        img.save(os.path.join(OUT, 'icons', f'{name}.png'))


ZODIAC = {chr(ord('a') + i): chr(0x2648 + i) for i in range(12)}   # a = Aries ... l = Piscis


if __name__ == '__main__':
    for fid, (path, px, chars) in FONTS.items():
        print(fid, 'lineHeight', make_font(fid, path, px, chars))
    print('zod', 'lineHeight', make_font('zod', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 16,
                                         ''.join(ZODIAC), ZODIAC))
    make_weather_icons()
    make_icons()
    print('iconos', len(ICONS))
