"""Vista previa y comprobación del widget «Hoy F5» (pendientes). Exporta HoyLayout.mc."""
import os
from PIL import Image, ImageDraw, ImageFont
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'hoy', 'source', 'HoyLayout.mc')

LAYOUT = {
    'TITLE_Y': 30, 'ROW_Y': 54, 'ROW_DY': 24, 'ROWS': 4, 'ROW_MAXW': 170, 'TIME_GAP': 8,
    'MORE_Y': 150, 'EMPTY_Y': 96, 'HINT_Y': 168, 'FOOT_Y': 186,
}
L = LAYOUT
GOLD, WHITE, GRAY, GREEN, YELLOW = 0xFFAA00, 0xFFFFFF, 0xAAAAAA, 0x55FF55, 0xFFFF55


def export():
    lines = ['// GENERADO por hoy_preview.py: no editar a mano.', 'module HoyLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def fit(X, s, maxw):
    while X.width(s) > maxw and len(s) > 1:
        s = s[:-1]
    return s.rstrip()


def render(st):
    S = BMFont('small'); X = BMFont('xs')
    dc = DC(); c = 120
    dc.color(GOLD); dc.text(c, L['TITLE_Y'], X, 'PENDIENTES')
    items = st['items']
    if not items:
        dc.color(GREEN); dc.text(c, L['EMPTY_Y'], S, 'NADA PENDIENTE')
    for i, (hora, txt, old) in enumerate(items[:L['ROWS']]):
        y = L['ROW_Y'] + i * L['ROW_DY']
        th = hora or ''
        wt = X.width(th) + (L['TIME_GAP'] if th else 0)
        body = fit(X, txt, L['ROW_MAXW'] - wt)
        w = wt + X.width(body)
        x = c - w // 2
        if th:
            dc.color(GOLD); dc.text(x, y, X, th, 'l', f'fila {i}')
        dc.color(GRAY if old else WHITE); dc.text(x + wt, y, X, body, 'l', f'fila {i}')
    if len(items) > L['ROWS']:
        dc.color(GRAY); dc.text(c, L['MORE_Y'], X, f'+{len(items) - L["ROWS"]} MÁS')
    if items:
        dc.color(GREEN); dc.text(c, L['HINT_Y'], X, 'START: TACHAR')
    dc.color(st.get('foot_col', GRAY)); dc.text(c, L['FOOT_Y'], X, st['foot'])
    return dc


CASES = {
    'normal': dict(items=[('11:00', 'EMPEZAR EL PROYECTO', False), ('14:30', 'LLAMAR AL DENTISTA', False),
                          (None, 'COMPRAR PILAS', False)], foot='AL DÍA · 18:20'),
    'lleno': dict(items=[('9:00', 'WWWWWWWWWWWWWWWWWWWW', False), ('10:00', 'REUNIÓN CON EL EQUIPO', False),
                         ('12:00', 'REVISAR EL CORREO', False), (None, 'DE AYER: PAGAR EL GIMNASIO', True),
                         ('20:00', 'PÁDEL', False), ('21:00', 'CENA', False)], foot='SIN MÓVIL · 18:20', foot_col=YELLOW),
    'vacio': dict(items=[], foot='AL DÍA · 18:20'),
}


def main():
    probs = []
    imgs = []
    for name, st in CASES.items():
        dc = render(st)
        probs += check(dc, name)
        imgs.append((name, dc))
    sheet = Image.new('RGB', (490 * 3 + 10, 540), (30, 30, 30))
    d = ImageDraw.Draw(sheet); f = ImageFont.load_default()
    for i, (n, dc) in enumerate(imgs):
        x = 10 + i * 490
        sheet.paste(dc.final(), (x, 40)); d.text((x + 5, 12), n, fill=(220, 220, 220), font=f)
    sheet.save(os.path.join(HERE, 'preview', 'hoy.png'))
    export()
    print('\n'.join(probs) if probs else 'Sin problemas')


if __name__ == '__main__':
    main()
