"""Vista previa y comprobación del widget «Agua F5» (240x240, fenix 5). Exporta AguaLayout.mc."""
import os
from PIL import Image, ImageDraw, ImageFont
from preview import BMFont, DC, check

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_MC = os.path.join(HERE, '..', 'agua', 'source', 'AguaLayout.mc')

LAYOUT = {
    'RING_R': 113, 'RING_PEN': 6,
    'TITLE_Y': 30, 'BIG_Y': 44, 'L_DY': 33, 'L_GAP': 4, 'GOAL_Y': 108,
    'BOT_Y': 134, 'BOT_W': 14, 'BOT_H': 26, 'BOT_GAP': 6, 'BOT_NECK': 5,
    'MSG_Y': 163, 'HINT_Y': 166, 'HINT2_Y': 186,
}
L = LAYOUT
GOLD, WHITE, GRAY, DARK, GREEN, BLUE, NAVY = 0xFFAA00, 0xFFFFFF, 0xAAAAAA, 0x555555, 0x55FF55, 0x00AAFF, 0x0055AA


def export():
    lines = ['// GENERADO por agua_preview.py: no editar a mano.', 'module AguaLayout {']
    lines += [f'    const {k} = {v};' for k, v in LAYOUT.items()]
    lines.append('}')
    os.makedirs(os.path.dirname(OUT_MC), exist_ok=True)
    with open(OUT_MC, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def bottles(dc, n_full, n_total):
    w, h, g, neck = L['BOT_W'], L['BOT_H'], L['BOT_GAP'], L['BOT_NECK']
    total_w = n_total * w + (n_total - 1) * g
    x = 120 - total_w // 2
    y = L['BOT_Y']
    for i in range(n_total):
        col = BLUE if i < n_full else DARK
        dc.color(col)
        dc.d.rounded_rectangle((x, y + neck, x + w - 1, y + h - 1), radius=3, fill=dc.fg)
        dc.d.rectangle((x + w // 2 - 3, y, x + w // 2 + 2, y + neck), fill=dc.fg)
        x += w + g
    dc.boxes.append(('botellas', 'botellas', 120 - total_w // 2, y, 120 + total_w // 2, y + h))


def render(st):
    A = BMFont('alt'); M = BMFont('med'); S = BMFont('small'); X = BMFont('xs')
    dc = DC(); c = 120
    dc.pen = L['RING_PEN']
    dc.color(DARK); dc.arc(120, 120, L['RING_R'], 0, 360, False)
    frac = min(1.0, st['ml'] / st['goal'])
    if frac > 0.003:
        dc.color(GREEN if frac >= 1 else BLUE); dc.arc(120, 120, L['RING_R'], 90, 90 - 360 * frac, True)
    dc.pen = 1
    dc.color(GOLD); dc.text(c, L['TITLE_Y'], X, 'AGUA HOY')
    big = st['big']
    wa = A.width(big); wl = M.width('L')
    left = c - (wa + L['L_GAP'] + wl) // 2
    dc.color(WHITE); dc.text(left, L['BIG_Y'], A, big, 'l', 'litros')
    dc.text(left + wa + L['L_GAP'], L['BIG_Y'] + L['L_DY'], M, 'L', 'l', 'litros')
    dc.color(GRAY); dc.text(c, L['GOAL_Y'], S, st['goal_txt'])
    if st['n_total'] <= 8:
        bottles(dc, st['n_full'], st['n_total'])
    else:
        dc.color(BLUE); dc.text(c, L['BOT_Y'] + 4, S, st['count_txt'])
    if st.get('msg'):
        dc.color(GREEN); dc.text(c, L['MSG_Y'], S, st['msg'])
    else:
        dc.color(GREEN); dc.text(c, L['HINT_Y'], X, 'START: +1 BOTELLA')
    dc.color(GRAY); dc.text(c, L['HINT2_Y'], X, 'MENÚ: AJUSTES')
    return dc


CASES = {
    'vacio': dict(ml=0, goal=2000, big='0', goal_txt='DE 2 L · BOTELLA 0,5', n_full=0, n_total=4),
    'medio': dict(ml=1000, goal=2000, big='1', goal_txt='DE 2 L · BOTELLA 0,5', n_full=2, n_total=4),
    'anadido': dict(ml=1500, goal=2000, big='1,5', goal_txt='DE 2 L · BOTELLA 0,5', n_full=3, n_total=4,
                    msg='+0,5 L'),
    'lleno': dict(ml=2500, goal=2000, big='2,5', goal_txt='¡OBJETIVO CUMPLIDO!', n_full=4, n_total=4),
    'pequenas': dict(ml=990, goal=3500, big='1', goal_txt='DE 3,5 L · BOTELLA 0,33', n_full=3, n_total=11,
                     count_txt='3 DE 11 BOTELLAS'),
    'grandes': dict(ml=3000, goal=3500, big='3', goal_txt='DE 3,5 L · BOTELLA 0,75', n_full=4, n_total=5),
}


def main():
    probs = []
    imgs = []
    for name, st in CASES.items():
        dc = render(st)
        probs += check(dc, name)
        imgs.append((name, dc))
    cols = 3
    rows = (len(imgs) + cols - 1) // cols
    sheet = Image.new('RGB', (490 * cols + 10, 530 * rows + 10), (30, 30, 30))
    d = ImageDraw.Draw(sheet); f = ImageFont.load_default()
    for i, (n, dc) in enumerate(imgs):
        x, y = 10 + (i % cols) * 490, 10 + (i // cols) * 530
        sheet.paste(dc.final(), (x, y + 30)); d.text((x + 5, y + 2), n, fill=(220, 220, 220), font=f)
    sheet.save(os.path.join(HERE, 'preview', 'agua.png'))
    export()
    print('\n'.join(probs) if probs else 'Sin problemas')


if __name__ == '__main__':
    main()
