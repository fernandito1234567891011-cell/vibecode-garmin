# Compila un proyecto de Connect IQ para un reloj (Windows, PowerShell).
#
# Uso:   .\compilar.ps1 <carpeta-del-proyecto> <id-del-reloj> [salida.prg]
# Ej.:   .\compilar.ps1 esfera fr265 salida\ESFERA.prg
#
# Variables opcionales: $env:CIQ_SDK (carpeta del SDK) y $env:CIQ_KEY (ruta a developer_key.der).
param(
    [Parameter(Mandatory = $true)][string]$Proyecto,
    [Parameter(Mandatory = $true)][string]$Reloj,
    [string]$Salida
)
$ErrorActionPreference = "Stop"

if (-not $Salida) {
    $nombre = ((Split-Path $Proyecto -Leaf).ToUpper() -replace '[^A-Z0-9]', '')
    if ($nombre.Length -gt 8) { $nombre = $nombre.Substring(0, 8) }
    $Salida = Join-Path "salida" "$nombre.prg"
}

$sdk = $env:CIQ_SDK
if (-not $sdk) {
    $base = Join-Path $env:APPDATA "Garmin\ConnectIQ\Sdks"
    if (Test-Path $base) {
        $sdk = (Get-ChildItem $base -Directory | Sort-Object Name | Select-Object -Last 1).FullName
    }
}
$jar = Join-Path $sdk "bin\monkeybrains.jar"
if (-not (Test-Path $jar)) { throw "No encuentro el SDK. Instálalo con el SDK Manager o define CIQ_SDK." }

$key = $env:CIQ_KEY
if (-not $key) { $key = Join-Path $HOME ".garmin\developer_key.der" }
if (-not (Test-Path $key)) { throw "No encuentro la clave en $key. Créala o define CIQ_KEY." }

if (-not (Select-String -Path (Join-Path $Proyecto "manifest.xml") -Pattern "id=`"$Reloj`"" -Quiet)) {
    Write-Warning "$Reloj no está en los productos de manifest.xml; añade <iq:product id=`"$Reloj`"/>."
}

New-Item -ItemType Directory -Force -Path (Split-Path $Salida) | Out-Null
java -Xms1g "-Dfile.encoding=UTF-8" -jar $jar -o $Salida -f (Join-Path $Proyecto "monkey.jungle") -y $key -d $Reloj -r -w
if ($LASTEXITCODE -ne 0) { throw "La compilación ha fallado." }
Write-Host "Listo: $Salida"
