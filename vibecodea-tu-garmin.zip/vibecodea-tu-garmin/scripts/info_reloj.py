#!/usr/bin/env python3
"""Resume la ficha técnica de un reloj Garmin a partir de los archivos del SDK de Connect IQ.

Uso:
    python3 info_reloj.py --lista              # ids de los relojes descargados en el SDK Manager
    python3 info_reloj.py fr265                # ficha de un modelo
    python3 info_reloj.py fr265 --devices RUTA # si la carpeta Devices está en otro sitio
    python3 info_reloj.py fr265 --todo         # además, todas las claves de los JSON

Lee Devices/<id>/compiler.json y simulator.json. Si una versión del SDK cambia algún nombre,
el dato sale como «?» en lugar de inventarse; con --todo puedes buscarlo a mano.
"""
import argparse
import json
import os
import re
import sys

# Qué permite cada versión de Connect IQ (fuente: documentación de la API, «Since: API Level»).
# Que la versión lo permita no garantiza que el reloj tenga el dato: compruébalo con `has`.
FUNCIONES = [
    ((2, 1, 0), "Historial de pulso, altitud, presión y temperatura; minutos de intensidad y pisos"),
    ((3, 0, 0), "Mapa dentro de una app (WatchUi.MapView), si el reloj tiene mapas"),
    ((3, 2, 0), "El tiempo de Garmin (Toybox.Weather); historial de pulsioximetría"),
    ((3, 3, 0), "Historial de Body Battery y estrés; respiración, horas de recuperación y VO2 máx."),
    ((4, 2, 0), "Complicaciones: la esfera lee Body Battery, estrés, recuperación, sueño, estado de entrenamiento…"),
    ((5, 0, 0), "Estrés del momento (ActivityMonitor.Info.stressScore)"),
]


def num_version(texto):
    partes = [int(x) for x in re.findall(r"\d+", str(texto))[:3]]
    return tuple(partes + [0] * (3 - len(partes))) if partes else None


def carpetas_devices():
    home = os.path.expanduser("~")
    posibles = [
        os.environ.get("CIQ_DEVICES", ""),
        os.path.join(home, "Library", "Application Support", "Garmin", "ConnectIQ", "Devices"),
        os.path.join(os.environ.get("APPDATA", ""), "Garmin", "ConnectIQ", "Devices"),
        os.path.join(home, ".Garmin", "ConnectIQ", "Devices"),
    ]
    return [p for p in posibles if p and os.path.isdir(p)]


def leer_json(ruta):
    try:
        with open(ruta, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def lista(devs):
    for d in devs:
        print(f"# {d}")
        for ident in sorted(os.listdir(d)):
            comp = leer_json(os.path.join(d, ident, "compiler.json"))
            if comp:
                print(f"{ident:24} {comp.get('displayName', '')}")


def version_ciq(comp):
    vs = {p.get("connectIQVersion") for p in comp.get("partNumbers", []) if isinstance(p, dict)}
    vs = sorted(v for v in vs if v)
    return ", ".join(vs) if vs else "?"


def ficha(devs, ident, todo=False):
    base = next((os.path.join(d, ident) for d in devs if os.path.isdir(os.path.join(d, ident))), None)
    if base is None:
        print(f"No encuentro el reloj «{ident}». Descárgalo en el SDK Manager o usa --lista.")
        return 1
    comp = leer_json(os.path.join(base, "compiler.json"))
    sim = leer_json(os.path.join(base, "simulator.json"))
    disp = sim.get("display", {}) if isinstance(sim.get("display"), dict) else {}
    res = comp.get("resolution", {})

    print(f"Reloj: {comp.get('displayName', '?')}  (id: {ident})")
    print(f"Pantalla: {res.get('width', '?')}×{res.get('height', '?')}, forma {disp.get('shape', '?')}, "
          f"{str(comp.get('displayType', '?')).upper()}, {comp.get('bitsPerPixel', '?')} bits por píxel, "
          f"táctil: {'sí' if disp.get('isTouch') else 'no' if 'isTouch' in disp else '?'}")
    print(f"Familia: {comp.get('deviceFamily', '?')}")
    print(f"Connect IQ: {version_ciq(comp)}")
    if "screenProtectionSupport" in sim:
        print(f"Protección de pantalla (AMOLED): {sim.get('screenProtectionSupport')}")

    tipos = comp.get("appTypes", [])
    if tipos:
        print("Memoria por tipo de app:")
        for t in tipos:
            if isinstance(t, dict) and "type" in t:
                lim = t.get("memoryLimit")
                kb = f"{int(lim) // 1024} KB" if isinstance(lim, (int, float)) else str(lim)
                print(f"   {t['type']:22} {kb}")

    teclas = sim.get("keys", [])
    if teclas:
        print("Botones (id: función):")
        for k in teclas:
            if isinstance(k, dict):
                print(f"   {k.get('id', '?'):10} {k.get('behavior', '')}")

    hist = sim.get("sensorHistory")
    if isinstance(hist, list) and hist:
        tipos_hist = sorted({str(h.get("type")) for h in hist if isinstance(h, dict) and h.get("type")})
        print(f"Historiales de sensores: {', '.join(tipos_hist)}")

    versiones = [num_version(p.get("connectIQVersion")) for p in comp.get("partNumbers", [])
                 if isinstance(p, dict) and p.get("connectIQVersion")]
    versiones = [v for v in versiones if v]
    if versiones:
        base = min(versiones)
        print(f"Lo que permite su versión de Connect IQ ({'.'.join(map(str, base))}):")
        for desde, que in FUNCIONES:
            marca = "sí" if base >= desde else "no"
            print(f"   [{marca:2}] desde {'.'.join(map(str, desde))}: {que}")
        print("   Que la versión lo permita no garantiza que este reloj tenga el dato: compruébalo con `has`.")

    if todo:
        print("\ncompiler.json:", ", ".join(sorted(comp.keys())))
        print("simulator.json:", ", ".join(sorted(sim.keys())))
    return 0


def main():
    ap = argparse.ArgumentParser(description="Ficha técnica de un reloj Garmin (SDK de Connect IQ)")
    ap.add_argument("id", nargs="?", help="id del reloj, por ejemplo fr265 o fenix7pro")
    ap.add_argument("--lista", action="store_true", help="lista los relojes descargados")
    ap.add_argument("--devices", help="ruta a la carpeta Devices del SDK")
    ap.add_argument("--todo", action="store_true", help="enseña también todas las claves de los JSON")
    a = ap.parse_args()
    devs = [a.devices] if a.devices else carpetas_devices()
    if not devs:
        print("No encuentro la carpeta Devices del SDK. Instala el SDK Manager, descarga el reloj "
              "o indica la ruta con --devices.")
        return 1
    if a.lista or not a.id:
        lista(devs)
        return 0
    return ficha(devs, a.id, a.todo)


if __name__ == "__main__":
    sys.exit(main())
