#!/usr/bin/env bash
# Compila un proyecto de Connect IQ para un reloj.
#
# Uso:   compilar.sh <carpeta-del-proyecto> <id-del-reloj> [salida.prg]
# Ej.:   compilar.sh esfera fr265 salida/ESFERA.prg
#
# Variables opcionales:
#   CIQ_SDK  carpeta del SDK (la que contiene bin/monkeybrains.jar). Si no está, usa el más reciente.
#   CIQ_KEY  ruta a developer_key.der. Por defecto ~/.garmin/developer_key.der
set -euo pipefail

PROY="${1:?Falta la carpeta del proyecto}"
DEV="${2:?Falta el id del reloj (por ejemplo fr265)}"
NOMBRE="$(basename "$PROY" | tr '[:lower:]' '[:upper:]' | tr -cd 'A-Z0-9' | cut -c1-8)"
OUT="${3:-salida/${NOMBRE}.prg}"

if [ -z "${CIQ_SDK:-}" ]; then
  for base in "$HOME/Library/Application Support/Garmin/ConnectIQ/Sdks" "$HOME/.Garmin/ConnectIQ/Sdks"; do
    if [ -d "$base" ]; then
      CIQ_SDK="$(ls -d "$base"/*/ 2>/dev/null | sort -V | tail -1)"
      [ -n "$CIQ_SDK" ] && break
    fi
  done
fi
JAR="${CIQ_SDK%/}/bin/monkeybrains.jar"
if [ ! -f "$JAR" ]; then
  echo "No encuentro el SDK. Instálalo con el SDK Manager o indica CIQ_SDK=/ruta/al/sdk" >&2
  exit 1
fi

KEY="${CIQ_KEY:-$HOME/.garmin/developer_key.der}"
if [ ! -f "$KEY" ]; then
  echo "No encuentro la clave de desarrollador en $KEY. Créala con nueva_clave.sh o indica CIQ_KEY." >&2
  exit 1
fi

if ! grep -q "id=\"$DEV\"" "$PROY/manifest.xml"; then
  echo "Aviso: $DEV no está en los productos de $PROY/manifest.xml; añade <iq:product id=\"$DEV\"/>." >&2
fi

mkdir -p "$(dirname "$OUT")"
java -Xms1g -Dfile.encoding=UTF-8 -jar "$JAR" \
  -o "$OUT" -f "$PROY/monkey.jungle" -y "$KEY" -d "$DEV" -r -w
echo "Listo: $OUT"
