#!/usr/bin/env bash
# Crea la clave de desarrollador de Connect IQ (RSA de 4096 bits en formato DER).
#
# Uso: nueva_clave.sh [carpeta]     (por defecto ~/.garmin)
#
# La clave firma tus apps. Guárdala con copia de seguridad y no la subas nunca a un repositorio
# ni la pegues en un chat: si se pierde no se puede recuperar.
set -euo pipefail

DIR="${1:-$HOME/.garmin}"
DER="$DIR/developer_key.der"
if [ -f "$DER" ]; then
  echo "Ya existe $DER; no la sobrescribo." >&2
  exit 0
fi
mkdir -p "$DIR"
chmod 700 "$DIR"
TMP="$(mktemp)"
openssl genrsa -out "$TMP" 4096 2>/dev/null
openssl pkcs8 -topk8 -inform PEM -outform DER -in "$TMP" -out "$DER" -nocrypt
rm -f "$TMP"
chmod 600 "$DER"
echo "Clave creada en $DER. Haz una copia de seguridad en un sitio privado."
