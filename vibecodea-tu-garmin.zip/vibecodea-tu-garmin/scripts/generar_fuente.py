#!/usr/bin/env python3
"""Genera una fuente BMFont (.fnt + .png) para Connect IQ a partir de un TTF u OTF libre.

Uso:
    python3 generar_fuente.py --ttf Inter-Bold.otf --px 62 --chars "0123456789:" --nombre hora \
        --salida mi-esfera/resources/fonts
    python3 generar_fuente.py --ttf DejaVuSans-Bold.ttf --px 16 --texto-completo --nombre pequena \
        --salida mi-esfera/resources/fonts

Opciones:
    --chars TEXTO        caracteres exactos a incluir (cuantos menos, menos memoria)
    --texto-completo     mayúsculas y minúsculas españolas, números y signos habituales
    --suavizado          bordes suavizados (para AMOLED). Sin esta opción, píxeles puros (MIP)

Al terminar imprime la línea que hay que añadir a resources/fonts/fonts.xml.
Necesita Pillow (pip install pillow).
"""
import argparse
import os

from PIL import Image, ImageDraw, ImageFont

MAYUS = "ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑÜ"
MINUS = "abcdefghijklmnopqrstuvwxyzáéíóúñü"
DIGITOS = "0123456789"
SIGNOS = " .,:;%+-/()·!¡?¿°'\"#&*=<>"


def generar(ttf, px, chars, nombre, salida, suavizado=False):
    font = ImageFont.truetype(ttf, px)
    ascent, descent = font.getmetrics()
    line_h = ascent + descent
    modo = "L" if suavizado else "1"
    glifos = []
    for ch in dict.fromkeys(chars):  # sin repetidos, en orden
        if ch == " ":
            glifos.append((ch, Image.new(modo, (1, 1), 0), 0, 0, int(round(font.getlength(" ")))))
            continue
        x0, y0, x1, y1 = font.getbbox(ch, anchor="ls")
        w, h = max(1, x1 - x0), max(1, y1 - y0)
        img = Image.new(modo, (w, h), 0)
        d = ImageDraw.Draw(img)
        d.fontmode = "L" if suavizado else "1"
        d.text((-x0, -y0), ch, font=font, fill=255 if suavizado else 1, anchor="ls")
        glifos.append((ch, img, x0, ascent + y0, int(round(font.getlength(ch)))))

    ancho = sum(g[1].width + 1 for g in glifos) + 1
    alto = max(g[1].height for g in glifos) + 2
    atlas = Image.new("RGBA", (ancho, alto), (0, 0, 0, 0))
    lineas = []
    x = 1
    for ch, img, xo, yo, adv in glifos:
        mascara = img if suavizado else img.convert("L").point(lambda v: 255 if v else 0)
        capa = Image.new("RGBA", img.size, (255, 255, 255, 255))
        atlas.paste(capa, (x, 1), mascara)
        lineas.append(f"char id={ord(ch)} x={x} y=1 width={img.width} height={img.height} "
                      f"xoffset={xo} yoffset={yo} xadvance={adv} page=0 chnl=15")
        x += img.width + 1

    os.makedirs(salida, exist_ok=True)
    atlas.save(os.path.join(salida, f"{nombre}.png"))
    with open(os.path.join(salida, f"{nombre}.fnt"), "w", encoding="utf-8") as f:
        f.write(f'info face="{os.path.basename(ttf)}" size={px} bold=0 italic=0 charset="" unicode=1 '
                f'stretchH=100 smooth={1 if suavizado else 0} aa=1 padding=0,0,0,0 spacing=1,1\n')
        f.write(f"common lineHeight={line_h} base={ascent} scaleW={ancho} scaleH={alto} pages=1 packed=0\n")
        f.write(f'page id=0 file="{nombre}.png"\n')
        f.write(f"chars count={len(lineas)}\n")
        f.write("\n".join(lineas) + "\n")
    aa = "true" if suavizado else "false"
    print(f"{nombre}: {len(lineas)} caracteres, alto de línea {line_h} px")
    print(f'Añade a fonts.xml:  <font id="{nombre.capitalize()}" filename="{nombre}.fnt" antialias="{aa}"/>')


def main():
    ap = argparse.ArgumentParser(description="Fuente BMFont para Connect IQ")
    ap.add_argument("--ttf", required=True, help="archivo TTF u OTF")
    ap.add_argument("--px", type=int, required=True, help="tamaño en píxeles")
    ap.add_argument("--nombre", required=True, help="nombre del archivo, sin extensión")
    ap.add_argument("--salida", default=".", help="carpeta de salida (resources/fonts)")
    ap.add_argument("--chars", help="caracteres a incluir")
    ap.add_argument("--texto-completo", action="store_true", help="letras, números y signos")
    ap.add_argument("--suavizado", action="store_true", help="bordes suavizados (AMOLED)")
    a = ap.parse_args()
    chars = a.chars or ""
    if a.texto_completo:
        chars += MAYUS + MINUS + DIGITOS + SIGNOS
    if not chars:
        ap.error("indica --chars o --texto-completo")
    generar(a.ttf, a.px, chars, a.nombre, a.salida, a.suavizado)


if __name__ == "__main__":
    main()
